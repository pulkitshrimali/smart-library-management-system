1. have Java 17
2. Need to have Extension Pack for Java by Mircosoft
3. Need to have Spring Boot Extension Pack by VMware
