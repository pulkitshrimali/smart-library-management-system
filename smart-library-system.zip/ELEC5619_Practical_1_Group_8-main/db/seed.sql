SET search_path = libraryhub, public;

-- Genres
INSERT INTO genre (name) VALUES
  ('Fiction'), ('Non-Fiction'), ('Computer Science'), ('Fantasy')
ON CONFLICT DO NOTHING;

-- Authors
INSERT INTO authors (name) VALUES
  ('Robert C. Martin'), ('J.K. Rowling'), ('George R.R. Martin'), ('Andrew Hunt')
ON CONFLICT DO NOTHING;

INSERT INTO users (email, name, role, phone_number, password)
VALUES
 ('alice@example.com', 'Alice', 'USER', '0400 000 001',
  '$2a$12$uTCHxYIrPrPEODtSS7UAGeKbrLpH3FARy9KuGW6iZ0hV1RM0pI5zS'),  -- pass1234
 ('admin@example.com', 'Admin', 'ADMIN', '0400 000 002',
  '$2a$12$e6EnF8.IoGBoD5o8AEEDkeGxkZPOuhh8xqQpIX8OmtJdsvciLfLCO')   -- admin123
ON CONFLICT (email) DO NOTHING;

-- Books
INSERT INTO books (genre_id, title, isbn, blurb, publication_date, publisher, cover_image_url, total_copies, available_copies)
VALUES
((SELECT genre_id FROM genre WHERE name='Computer Science'), 'Clean Code','9780132350884','A Handbook of Agile Software Craftsmanship','2008-08-01','Prentice Hall',NULL,3,3),
((SELECT genre_id FROM genre WHERE name='Computer Science'), 'The Pragmatic Programmer','9780201616224','Journey to Mastery','1999-10-20','Addison-Wesley',NULL,2,2),
((SELECT genre_id FROM genre WHERE name='Fantasy'), 'A Game of Thrones','9780553573404','Epic fantasy novel','1996-08-06','Bantam Spectra',NULL,5,5)
ON CONFLICT DO NOTHING;

-- BookAuthors
INSERT INTO bookauthors (book_id, author_id)
SELECT b.book_id, a.author_id FROM books b JOIN authors a
ON b.title='Clean Code' AND a.name='Robert C. Martin'
ON CONFLICT DO NOTHING;

INSERT INTO bookauthors (book_id, author_id)
SELECT b.book_id, a.author_id FROM books b JOIN authors a
ON b.title='The Pragmatic Programmer' AND a.name='Andrew Hunt'
ON CONFLICT DO NOTHING;

-- One library & one copy
INSERT INTO libraries (name, address, phone_number, email)
VALUES ('City Library','123 Library St','123-456-789','info@citylib.example')
ON CONFLICT DO NOTHING;

INSERT INTO bookcopies (book_id, library_id, status)
SELECT (SELECT book_id FROM books WHERE title='Clean Code'),
       (SELECT library_id FROM libraries WHERE name='City Library'),
       'AVAILABLE'
ON CONFLICT DO NOTHING;

-- Example review (updates book/user uniqueness)
INSERT INTO reviews (user_id, book_id, rating, review_text)
VALUES (
  (SELECT user_id FROM users WHERE email='test@demo.com'),
  (SELECT book_id FROM books WHERE title='Clean Code'),
  5, 'Great!'
)
ON CONFLICT DO NOTHING;

-- Example waitlist row (trigger assigns position)
INSERT INTO waitlist (user_id, book_id, library_id, position)
VALUES (
  (SELECT user_id FROM users WHERE email='test@demo.com'),
  (SELECT book_id FROM books WHERE title='A Game of Thrones'),
  (SELECT library_id FROM libraries WHERE name='City Library'),
  0
)
ON CONFLICT DO NOTHING;
