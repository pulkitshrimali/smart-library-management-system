-- =====================================================================
-- LibraryHub — Database Schema (no notification_preferences)
-- =====================================================================

DROP SCHEMA IF EXISTS libraryhub CASCADE;
CREATE SCHEMA libraryhub;
SET search_path = libraryhub, public;

-- ===== Extensions =====
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS btree_gin;

-- ===== Enums =====
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname='user_role') THEN
    CREATE TYPE user_role AS ENUM ('USER','ADMIN');
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname='copy_status') THEN
    CREATE TYPE copy_status AS ENUM ('AVAILABLE','RESERVED','CHECKED_OUT');
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname='review_status') THEN
    CREATE TYPE review_status AS ENUM ('PUBLISHED','HIDDEN','PENDING_REVIEW');
  END IF;
END $$;

-- ===== Tables =====

CREATE TABLE users (
  user_id      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name         VARCHAR(255),
  birth_date   DATE,
  email        VARCHAR(255) NOT NULL,
  password     TEXT,
  role         user_role NOT NULL DEFAULT 'USER',
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  phone_number VARCHAR(30)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_users_email_ci ON users ((LOWER(email)));

CREATE TABLE genre (
  genre_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name     VARCHAR(255) NOT NULL
);

CREATE TABLE authors (
  author_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name      VARCHAR(255) NOT NULL
);

CREATE TABLE books (
  book_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  genre_id         UUID REFERENCES genre(genre_id) ON DELETE SET NULL,
  title            VARCHAR(255) NOT NULL,
  isbn             VARCHAR(20),
  blurb            TEXT,
  publication_date DATE,
  publisher        VARCHAR(255),
  cover_image_url  TEXT,
  total_copies     INT NOT NULL DEFAULT 0 CHECK (total_copies >= 0),
  available_copies INT NOT NULL DEFAULT 0 CHECK (available_copies >= 0 AND available_copies <= total_copies)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_books_isbn_not_null
  ON books(isbn) WHERE isbn IS NOT NULL;

CREATE TABLE bookauthors (
  book_id   UUID NOT NULL REFERENCES books(book_id)     ON DELETE CASCADE,
  author_id UUID NOT NULL REFERENCES authors(author_id) ON DELETE CASCADE,
  PRIMARY KEY (book_id, author_id)
);

CREATE TABLE libraries (
  library_id   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name         VARCHAR(255) NOT NULL,
  address      VARCHAR(255),
  phone_number VARCHAR(20),
  email        VARCHAR(255),
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE bookcopies (
  copy_id    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  library_id UUID NOT NULL REFERENCES libraries(library_id) ON DELETE CASCADE,
  book_id    UUID NOT NULL REFERENCES books(book_id)         ON DELETE CASCADE,
  status     copy_status NOT NULL DEFAULT 'AVAILABLE'
);

CREATE TABLE reservation (
  reservation_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        UUID NOT NULL REFERENCES users(user_id)       ON DELETE CASCADE,
  copy_id        UUID NOT NULL REFERENCES bookcopies(copy_id)  ON DELETE CASCADE,
  start_date     DATE NOT NULL,
  end_date       DATE NOT NULL,
  status         reservation_status NOT NULL DEFAULT 'PENDING',
  reserved_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  hold_expiry    TIMESTAMP NULL,
  CONSTRAINT chk_resv_dates CHECK (end_date >= start_date)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_reservation_active_copy
  ON reservation(copy_id) WHERE status IN ('PENDING','CONFIRMED');

CREATE TABLE reviews (
  review_id   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  book_id     UUID NOT NULL REFERENCES books(book_id) ON DELETE CASCADE,
  rating      INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  review_text TEXT,
  status      review_status NOT NULL DEFAULT 'PUBLISHED',
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (user_id, book_id)
);

CREATE TABLE review_likes (
  user_id   UUID NOT NULL REFERENCES users(user_id)     ON DELETE CASCADE,
  review_id UUID NOT NULL REFERENCES reviews(review_id) ON DELETE CASCADE,
  type      review_reaction NOT NULL,
  PRIMARY KEY (user_id, review_id)
);

CREATE TABLE reviewcomments (
  comment_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  review_id  UUID NOT NULL REFERENCES reviews(review_id) ON DELETE CASCADE,
  user_id    UUID NOT NULL REFERENCES users(user_id)     ON DELETE CASCADE,
  parent_id  UUID REFERENCES reviewcomments(comment_id)  ON DELETE CASCADE,
  message    TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE waitlist (
  waitlist_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES users(user_id)         ON DELETE CASCADE,
  book_id     UUID NOT NULL REFERENCES books(book_id)         ON DELETE CASCADE,
  library_id  UUID NOT NULL REFERENCES libraries(library_id)  ON DELETE CASCADE,
  position    INT NOT NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notifications (
  notification_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  type            notif_type NOT NULL,
  message         VARCHAR(255),
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ===== Triggers =====
CREATE OR REPLACE FUNCTION wl_assign_position() RETURNS trigger AS $$
DECLARE maxpos INT;
BEGIN
  SELECT COALESCE(MAX(position),0) INTO maxpos
  FROM libraryhub.waitlist
  WHERE book_id = NEW.book_id AND library_id = NEW.library_id;
  NEW.position := maxpos + 1;
  RETURN NEW;
END $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_waitlist_assign ON waitlist;
CREATE TRIGGER trg_waitlist_assign
BEFORE INSERT ON waitlist
FOR EACH ROW EXECUTE PROCEDURE wl_assign_position();

CREATE OR REPLACE FUNCTION wl_compact_positions() RETURNS trigger AS $$
BEGIN
  UPDATE libraryhub.waitlist
  SET position = position - 1
  WHERE book_id = OLD.book_id
    AND library_id = OLD.library_id
    AND position > OLD.position;
  RETURN NULL;
END $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_waitlist_compact ON waitlist;
CREATE TRIGGER trg_waitlist_compact
AFTER DELETE ON waitlist
FOR EACH ROW EXECUTE PROCEDURE wl_compact_positions();

CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_reviewcomments_updated ON reviewcomments;
CREATE TRIGGER trg_reviewcomments_updated
BEFORE UPDATE ON reviewcomments
FOR EACH ROW EXECUTE PROCEDURE set_updated_at();

CREATE OR REPLACE FUNCTION promote_waitlist_on_available() RETURNS trigger AS $$
DECLARE
  next_waitlist_user RECORD;
  new_reservation_id UUID;
BEGIN
  IF OLD.status <> 'AVAILABLE' AND NEW.status = 'AVAILABLE' THEN
    SELECT w.*
    INTO next_waitlist_user
    FROM libraryhub.waitlist w
    WHERE w.book_id = NEW.book_id
      AND w.library_id = NEW.library_id
    ORDER BY w.position ASC
    LIMIT 1;

    IF FOUND THEN
      new_reservation_id := gen_random_uuid();
      INSERT INTO libraryhub.reservation (
        reservation_id, user_id, copy_id, start_date, end_date,
        status, reserved_at, hold_expiry
      ) VALUES (
        new_reservation_id,
        next_waitlist_user.user_id,
        NEW.copy_id,
        CURRENT_DATE,
        CURRENT_DATE + INTERVAL '14 days',
        'PENDING',
        CURRENT_TIMESTAMP,
        CURRENT_TIMESTAMP + INTERVAL '5 days'
      );
      NEW.status := 'RESERVED';
      UPDATE libraryhub.books
      SET available_copies = GREATEST(available_copies - 1, 0)
      WHERE book_id = NEW.book_id;
      DELETE FROM libraryhub.waitlist
      WHERE waitlist_id = next_waitlist_user.waitlist_id;
    END IF;
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_promote_waitlist ON bookcopies;
CREATE TRIGGER trg_promote_waitlist
BEFORE UPDATE ON bookcopies
FOR EACH ROW EXECUTE PROCEDURE promote_waitlist_on_available();

CREATE INDEX IF NOT EXISTS idx_books_title_trgm   ON books USING GIN (title gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_authors_name_trgm  ON authors USING GIN (name gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_reviews_book       ON reviews(book_id);
CREATE INDEX IF NOT EXISTS idx_reviews_user       ON reviews(user_id);
CREATE INDEX IF NOT EXISTS idx_waitlist_book_lib  ON waitlist(book_id, library_id, position);
