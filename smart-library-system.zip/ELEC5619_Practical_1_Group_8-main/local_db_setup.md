# Local DB Setup (PostgreSQL + schema/seed)

## Prereqs (macOS)
```bash
brew install postgresql@14
brew services start postgresql@14
psql --version   # should show 14.x
