# Library Reservation & Review Hub

## Problem Statement

Many libraries still rely on separate systems or manual steps to handle book reservations, waiting lists, and community reviews. This creates confusion for readers who cannot quickly determine whether a book is available, how long they may need to wait, or when they can collect a reserved item. It also creates extra workflow for staff who must track the waitlist, send reminders, and manage pick-ups across different tools. Reviews are spread across multiple platforms and lack consistent moderation. As a result, readers struggle to find reliable feedback, and staff cannot easily keep comments respectful and on-topic.

Lack of a single workflow causes unnecessary issues like simultaneous bookings in times of high demand, unfair queue order, and late or missing notifications. Libraries also have limited means to implement practices such as pick-up windows and penalties for repeated no-shows. From a governance perspective, current systems rarely provide an auditable trail or configurable rules. Finally, users expect modern web standards: quick responses, clear status updates, accessible interfaces, and strong protection of personal information.

---

## Objective

Build a full-stack web application that allows book reservations, waiting lists, and community reviews into one reliable and easy-to-use system. The application will give readers a clear view of availability, a fair and transparent queue, and timely notifications when items are ready or due. It will give librarians a simple way to manage inventory, set basic reservation rules such as pick-up windows, and moderate reviews. The solution will be delivered as a modern frontend connected to a secure Spring Boot API with a persistent database, following the course’s Scrum structure across four sprints. The emphasis is on usability, reliability, data privacy, and clear auditability of important actions.

---

## Project Description

The **Library Reservation & Review Hub** is a complete web solution designed for real users to interact with during the semester. Readers can browse through the catalogue, place or cancel reservations, join or leave a waitlist, and see their position and next steps at any time. When a reserved item becomes available, the system holds it for a defined window and notifies the next reader by email and in-app alerts. Readers can also post ratings and short reviews on item pages. Librarians sign in to manage books, configure simple policies like maximum active reservations and pick-up windows, and review or remove inappropriate reviews.

The back end is implemented in Spring Boot with clear REST endpoints, input validation, and audit logging for key events such as reservation creation, queue promotion, and moderation actions. Data is stored in a relational database to ensure consistency for concurrent reservations. The front end is built with a modern framework to provide responsive pages, clear status messages, and accessible forms. The team will plan and deliver the work using Scrum, iterating through sprints to ship a functional website that demonstrates the core reservation flow, simple policy controls, review moderation, and basic admin reporting.

# Library Reservation & Review Hub — README (Assessment Section)

## 1) Libraries & Versions

> Versions resolved via Spring Boot **3.5.5**.

### Direct application dependencies

| Library                      | Version    |
| ---------------------------- | ---------- |
| spring-boot-starter-web      | **3.5.5**  |
| spring-boot-starter-data-jpa | **3.5.5**  |
| spring-boot-starter-mail     | **3.5.5**  |
| spring-security-crypto       | **6.5.3**  |
| postgresql (JDBC driver)     | **42.7.7** |
| spring-boot-devtools         | **3.5.5**  |

### Test dependencies

| Library                                  | Version    |
| ---------------------------------------- | ---------- |
| spring-boot-starter-test                 | **3.5.5**  |
| JUnit Jupiter (api/params/engine)        | **5.12.2** |
| JUnit Platform (engine/launcher/commons) | **1.12.2** |
| Mockito (core, junit-jupiter)            | **5.17.0** |
| AssertJ                                  | **3.27.4** |
| Awaitility                               | **4.2.2**  |
| JsonPath                                 | **2.9.0**  |
| JSON-Smart                               | **2.5.2**  |
| XMLUnit Core                             | **2.10.3** |
| Hamcrest                                 | **3.0**    |

---

## 2) Working Functionalities

- **Global Search** for books (title/author/ISBN).
- **Filter books** based on availability, library, date, genre.
- **Sort books** by book title (A-Z) and publication date.
- **Book Details** page (title, authors, blurb, cover via `coverImageUrl`).
- **Reservations** for available copies (reserve/cancel).
- **Waitlist** auto-enrolment when no copies are available (leave waitlist).
- **Reviews & Ratings** with basic moderation.
- **Comments & Replies** on reviews.
- **Admin Workspace** to manage **Books**, **Copies**, **Reservations**, **Waitlists**, and review moderation.
- **Email notifications** (optional; when SMTP is configured).

---

## 3) Quick Guide to Run

### Run Command

./gradlew clean bootRun

- Open http://localhost:8080

### Prerequisites

- **Java 17**
- **PostgreSQL** database (Neon Cloud)

# Neon Postgres
**Connecting to cloud hosted database:** (also found in application.properties in codebase)
SPRING_DATASOURCE_URL=jdbc:postgresql://ep-jolly-wind-a7wrae1r.ap-southeast-2.aws.neon.tech/neondb?sslmode=require&channelBinding=require
SPRING_DATASOURCE_USERNAME=neondb_owner
SPRING_DATASOURCE_PASSWORD= <REPLACE_ME>
DB_DEFAULT_SCHEMA=libraryhub
JPA_DDL_AUTO=update
SQL_INIT_MODE=never

# Mail (Mailtrap sandbox)

SPRING_MAIL_HOST=sandbox.smtp.mailtrap.io
SPRING_MAIL_PORT=2525
SPRING_MAIL_USERNAME= <REPLACE_ME>  
SPRING_MAIL_PASSWORD= <REPLACE_ME>  
SPRING_MAIL_FROM=LibraryHub <noreply@libraryhub.com>
SPRING_MAIL_SMTP_AUTH=true
SPRING_MAIL_STARTTLS=true
SPRING_MAIL_DEBUG=false

## 4) Test Login Credentials (For Tutor Access)

To make it easy for tutors to explore both user and admin functionality, two pre-created accounts are provided.

| **Role**           | **Email / Username** |  **Password**   |
| ------------------ | ---------------------| --------------- |
| Regular User       | kiara26@gmail.com    | astrophile@123  |
| Admin / Librarian  | charlie@gmail.com    | charlie@1234    |

---

## Features of Website

### 1. Search

- Search books by title, author, ISBN, or genre
- Filter by availability, category, rating, popularity, or publication date
- Sort results (by rating, popularity, etc.)

### 2. Book Details & Community

- Book details: blurb, availability, cover image, ratings, reviews
- Write comments/reviews, like/unlike feedback
- Report inappropriate reviews for moderation
- Display average rating per book

### 3. Book Reservations & Waitlist

- Reserve books online with start/end dates
- Automatic conflict prevention (no double booking)
- Cancel or modify reservations
- Join waitlists for unavailable books
- Automatic notifications when books become available
- Priority-based allocation (first-come, first-served)

### 4. Personal Dashboard

- Manage current reservations and waitlist status
- Track due dates and pickup deadlines
- View reading, review, and reservation history

### 5. User Profile

- Secure signup/login with email & password
- Role-based access (user vs librarian/admin)
- Manage personal information
- Password reset

### 6. Admin Panel & Librarian Tools

- Add, edit, remove books from the catalog
- Monitor reservations, waitlists, and overdue books
- Moderate/remove inappropriate reviews

### 7. Notifications

- Email notifications for:
  - Reservation confirmation
  - Book availability
  - Upcoming due dates
  - Waitlist updates

### 8. System & Technical

- Responsive UI (HTML/CSS/JS) served by Spring Boot MVC
- Secure backend (Spring Boot) with authentication & authorization
- Persistent data layer PostgreSQL (Neon)
- Mailtrap sandbox for notification testing.
- Audit & logging of user actions
- Real-time updates for book availability

---

## High-Level Goals

1. **Streamline Book Reservation**

   - Allow users to easily reserve and borrow books online
   - Keep users informed via instant alerts

2. **Enhance User Engagement Through Community Interaction**

   - Reviews, ratings, recommendations
   - Support for community events and author talks
   - Promote reading culture and highlight trending titles

3. **Improve Resource Management for Librarians**

   - Tools to manage inventory, reservations, and users efficiently

4. **Increase Accessibility of Library Services**

   - Accessible and mobile-friendly interface
   - Scalable infrastructure for future growth (e.g., eBooks)

5. **Ensure Security and Privacy**
   - Protect user data and reservation records
   - Secure authentication and authorization

---

## Team Roles & Responsibilities

### Purva – Backend Developer, Database Specialist, Scrum Master

- Designs and implements backend logic and REST APIs
- Manages database schema and integrations
- Facilitates stand-ups, sprint planning, removes blockers
- Manages Jira board and sprint progress
- Conducts backend testing (unit, API, database validation)

### Gayatri – Backend Developer, Database Specialist

- Designs and implements backend logic and REST APIs
- Handles database operations (security & efficiency)
- Collaborates with frontend team for integrations
- Conducts backend testing (unit, API, database validation)

### Ananya – Frontend Developer, Product Owner

- Leads UI/UX design and implementation
- Builds responsive UI components integrated with APIs
- Maintains product backlog, prioritises features, shares vision
- Conducts database validation/testing (ensures that the data displayed in the frontend matches the database state and correct CRUD operations)

### Pulkit – Frontend Developer, Database Specialist

- Develops and styles frontend pages according to design specifications
- Integrates frontend components with backend APIs (handling data fetching and error states)
- Setup and manage SQL database schema
- Conducts database validation/testing (ensures that the data displayed in the frontend matches the database state and correct CRUD operations)

### Ray – Frontend Developer

- Develops and styles frontend pages according to design specifications
- Integrates frontend components with backend APIs (handling data fetching and error states)
- Setup and manage SQL database schema
