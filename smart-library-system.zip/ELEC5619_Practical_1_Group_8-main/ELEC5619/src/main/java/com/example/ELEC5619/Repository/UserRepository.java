// src/main/java/com/example/ELEC5619/repository/UserRepository.java
package com.example.ELEC5619.Repository;

import com.example.ELEC5619.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface UserRepository extends JpaRepository<User, UUID> {
    Optional<User> findByEmailIgnoreCase(String email);
    boolean existsByEmailIgnoreCase(String email);
}
