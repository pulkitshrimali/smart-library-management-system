package com.example.ELEC5619.Model;

import jakarta.persistence.*;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "books")
public class Book {

    @Id
    @GeneratedValue
    private UUID bookId;

    @Column(nullable = false)
    private String title;

    @Column(nullable = false, unique = true)
    private String isbn;

    @Column(length = 2000)
    private String blurb;

    @Column(name = "publication_date")
    private LocalDate publicationDate;

    private String publisher;

    @Column(name = "total_copies")
    private Integer totalCopies;

    @Column(name = "available_copies")
    private Integer availableCopies;

    @Column(name = "cover_image_url")
    private String coverImageUrl;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
        name = "bookauthors",
        joinColumns = @JoinColumn(name = "book_id"),
        inverseJoinColumns = @JoinColumn(name = "author_id")
    )
    @Fetch(FetchMode.JOIN)
    private List<com.example.ELEC5619.Model.Author> authors;

    @ManyToOne
    @JoinColumn(name = "genre_id")
    private com.example.ELEC5619.Model.Genre genre;

    // getters/setters

    public UUID getBookId() { return bookId; }
    public void setBookId(UUID bookId) { this.bookId = bookId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }

    public String getBlurb() { return blurb; }
    public void setBlurb(String blurb) { this.blurb = blurb; }

    public LocalDate getPublicationDate() { return publicationDate; }
    public void setPublicationDate(LocalDate publicationDate) { this.publicationDate = publicationDate; }

    public String getPublisher() { return publisher; }
    public void setPublisher(String publisher) { this.publisher = publisher; }

    public Integer getTotalCopies() { return totalCopies; }
    public void setTotalCopies(Integer totalCopies) { this.totalCopies = totalCopies; }

    public Integer getAvailableCopies() { return availableCopies; }
    public void setAvailableCopies(Integer availableCopies) { this.availableCopies = availableCopies; }

    public String getCoverImageUrl() { return coverImageUrl; }
    public void setCoverImageUrl(String coverImageUrl) { this.coverImageUrl = coverImageUrl; }

    public List<com.example.ELEC5619.Model.Author> getAuthors() { return authors; }
    public void setAuthors(List<com.example.ELEC5619.Model.Author> authors) { this.authors = authors; }

    public com.example.ELEC5619.Model.Genre getGenre() { return genre; }
    public void setGenre(com.example.ELEC5619.Model.Genre genre) { this.genre = genre; }
}
