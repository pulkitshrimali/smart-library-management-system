package com.example.ELEC5619.Controller;

import com.example.ELEC5619.Service.LibraryStatsService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/stats")
public class LibraryStatsController {

    private final LibraryStatsService statsService;

    public LibraryStatsController(LibraryStatsService statsService) {
        this.statsService = statsService;
    }

    @GetMapping
    public LibraryStatsService.LibraryStats getStats() {
        return statsService.getStats();
    }
}
