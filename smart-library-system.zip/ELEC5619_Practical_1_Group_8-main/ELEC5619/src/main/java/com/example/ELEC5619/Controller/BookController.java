package com.example.ELEC5619.Controller;

import com.example.ELEC5619.Model.Book;
import com.example.ELEC5619.Service.BookService;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("/books")
@CrossOrigin
public class BookController {

    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping
    public Map<String, Object> searchBooks(
            @RequestParam(value = "q", required = false) String query,
            @RequestParam(value = "availability", required = false) String availability,
            @RequestParam(value = "genre", required = false) String genre,
            @RequestParam(value = "library", required = false) String library,
            @RequestParam(value = "year", required = false) String year
    ) {
        List<Book> results = bookService.searchBooks(query, availability, genre, library, year);
        Map<String, Object> response = new HashMap<>();
        response.put("total", results.size());
        response.put("items", results);
        return response;
    }

    @GetMapping("/random")
    public Book getRandomBook() {
        return bookService.getRandomBook()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "No books available"));
    }
}
