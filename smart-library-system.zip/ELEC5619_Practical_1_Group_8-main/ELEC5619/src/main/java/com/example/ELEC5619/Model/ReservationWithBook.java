package com.example.ELEC5619.Model;

import java.time.LocalDate;
import java.util.UUID;

public class ReservationWithBook {
    private UUID reservationId;
    private UUID userId;
    private UUID copyId;
    private LocalDate startDate;
    private LocalDate endDate;
    private String status;
    
    // Book details
    private String title;
    private String author;
    private String coverImageUrl;
    private String isbn;
    private Integer publicationYear;
    private LocalDate reservedAt;
    private LocalDate holdExpiry;
    private String libraryName;
    private String userName; // For admin view
    
    // Constructors
    public ReservationWithBook() {}
    
    // Getters and Setters
    public UUID getReservationId() { return reservationId; }
    public void setReservationId(UUID reservationId) { this.reservationId = reservationId; }
    
    public UUID getUserId() { return userId; }
    public void setUserId(UUID userId) { this.userId = userId; }
    
    public UUID getCopyId() { return copyId; }
    public void setCopyId(UUID copyId) { this.copyId = copyId; }
    
    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    
    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    
    public String getCoverImageUrl() { return coverImageUrl; }
    public void setCoverImageUrl(String coverImageUrl) { this.coverImageUrl = coverImageUrl; }
    
    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }
    
    public Integer getPublicationYear() { return publicationYear; }
    public void setPublicationYear(Integer publicationYear) { this.publicationYear = publicationYear; }
    
    public LocalDate getReservedAt() { return reservedAt; }
    public void setReservedAt(LocalDate reservedAt) { this.reservedAt = reservedAt; }
    
    public LocalDate getHoldExpiry() { return holdExpiry; }
    public void setHoldExpiry(LocalDate holdExpiry) { this.holdExpiry = holdExpiry; }
    
    public String getLibraryName() { return libraryName; }
    public void setLibraryName(String libraryName) { this.libraryName = libraryName; }
    
    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }
}