package com.example.ELEC5619.Repository;

import com.example.ELEC5619.Model.Library;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface LibraryRepository extends JpaRepository<Library, UUID> {

    @Query(value = "SELECT * FROM libraryhub.libraries LIMIT 1", nativeQuery = true)
    Optional<Library> findFirst();
}