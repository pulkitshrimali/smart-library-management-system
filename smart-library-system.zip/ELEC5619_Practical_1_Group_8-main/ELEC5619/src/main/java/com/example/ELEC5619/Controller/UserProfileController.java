package com.example.ELEC5619.Controller;


import com.example.ELEC5619.Model.User;
import com.example.ELEC5619.Repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletResponse;
import java.time.LocalDate;
import java.util.Map;
import java.util.LinkedHashMap;

/**
 * Controller that manages user profile retrieval and updates.
 * <p>
 * Provides endpoints for authenticated users to view and update their profile details.
 * Uses cookies for user identification and interacts with the {@link UserRepository}
 * to persist profile information.
 */
@RestController
@RequestMapping("/profile")
public class UserProfileController {

    /** Repository used to access user records in the database. */
    private final UserRepository users;

    /**
     * Constructs a {@code UserProfileController} with a given user repository.
     *
     * @param users the {@link UserRepository} for managing user entities
     */
    public UserProfileController(UserRepository users) {
        this.users = users;
    }

    /**
     * Retrieves the profile information of a user identified by a cookie value.
     * <p>
     * The cookie named {@code userEmail} is expected to contain the user’s email.
     * Returns the user’s details such as name, birth date, role, and preferences.
     *
     * @param email the email value from the {@code userEmail} cookie (may be {@code null})
     * @return a map containing the user profile data or an error response if the user is not found
     */
    @GetMapping
    public Map<String, Object> getProfile(
            @CookieValue(value = "userEmail", required = false) String email) {

        if (email == null || email.isBlank()) {
            return error(401, "Not logged in");
        }

        User u = users.findByEmailIgnoreCase(email).orElse(null);
        if (u == null) return error(404, "User not found");

        // Build JSON response manually to include nullable fields
        Map<String, Object> user = new LinkedHashMap<>();
        user.put("userId", u.getUserId());
        user.put("name", u.getName());
        user.put("email", u.getEmail());
        user.put("birthDate", u.getBirthDate());
        user.put("role", u.getRole());

        user.put("phone", u.getPhoneNumber()); // may be null
        user.put("createdAt", u.getCreatedAt());

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("status", "ok");
        resp.put("user", user);
        return resp;
    }

    /**
     * Builds a standard error response map.
     *
     * @param code    the HTTP-like status code
     * @param message the associated error message
     * @return a structured map representing the error response
     */
    private Map<String, Object> error(int code, String message) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("status", "error");
        m.put("code", code);
        m.put("message", message);
        return m;
    }

    /**
     * Updates user profile details such as phone number and birth date.
     * <p>
     * Validates the provided email, phone number, and birth date before applying updates.
     * Returns {@code 400 Bad Request} for invalid input and {@code 404 Not Found} if the user does not exist.
     *
     * @param body     a map containing user input fields (email, phone, birth)
     * @param response the HTTP response object
     * @return a {@link ResponseEntity} containing a success or error message
     */
    @PutMapping
    public ResponseEntity<?> updateProfile(
            @RequestBody Map<String, Object> body,
            HttpServletResponse response
    ) {
        String email = (String) body.get("email");
        String phone = (String) body.get("phone");
        String birth = (String) body.get("birth");

        if (email == null || !email.matches("^\\S+@\\S+\\.\\S+$"))
            return ResponseEntity.badRequest().body("Invalid email");
        if (phone == null || !phone.matches("^0\\d{9}$"))
            return ResponseEntity.badRequest().body("Invalid phone number");

        LocalDate birthDate;
        try {
            birthDate = LocalDate.parse(birth);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Invalid birth date");
        }

        User u = users.findByEmailIgnoreCase(email).orElse(null);
        if (u == null) return ResponseEntity.status(404).body("User not found");

        u.setPhoneNumber(phone);
        u.setBirthDate(birthDate);
        users.save(u);

        return ResponseEntity.ok(Map.of("message", "Profile updated successfully"));
    }
}
