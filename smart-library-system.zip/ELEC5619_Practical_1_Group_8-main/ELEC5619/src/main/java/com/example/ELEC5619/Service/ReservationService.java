package com.example.ELEC5619.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.ELEC5619.Model.BookCopy;
import com.example.ELEC5619.Model.Reservation;
import com.example.ELEC5619.Model.ReservationStatus;
import com.example.ELEC5619.Model.ReservationWithBook;
import com.example.ELEC5619.Model.Waitlist;
import com.example.ELEC5619.Repository.BookCopyRepository;
import com.example.ELEC5619.Repository.BookRepository;
import com.example.ELEC5619.Repository.ReservationRepository;
import com.example.ELEC5619.Repository.UserRepository;
import com.example.ELEC5619.Service.WaitlistService;

import java.util.ArrayList;


@Service
public class ReservationService {
    
    private final ReservationRepository reservationRepository;
    private final BookCopyRepository bookCopyRepository;
    private final BookRepository bookRepository;
    private final EmailService emailService;
    private final WaitlistService waitlistService;
    private final UserRepository userRepository;
    
    public ReservationService(ReservationRepository reservationRepository, 
                            BookCopyRepository bookCopyRepository,
                            BookRepository bookRepository,
                            EmailService emailService,
                            WaitlistService waitlistService,
                            UserRepository userRepository) {
        this.reservationRepository = reservationRepository;
        this.bookCopyRepository = bookCopyRepository;
        this.bookRepository = bookRepository;
        this.emailService = emailService;
        this.waitlistService = waitlistService;
        this.userRepository = userRepository;
    }
    
    @Transactional
    public Reservation createReservation(UUID userId, UUID bookId, String userEmail) {
        // Check if user already has active reservation for this book
        if (reservationRepository.hasActiveReservationForBook(userId, bookId)) {
            throw new RuntimeException("You already have an active reservation for this book");
        }
        
        // Find available copy
        Optional<BookCopy> availableCopy = bookCopyRepository.findFirstAvailableCopyByBookId(bookId);
        if (availableCopy.isEmpty()) {
            throw new RuntimeException("No copies available for reservation");
        }
        
        BookCopy copy = availableCopy.get();
        
        // Update copy status to reserved
        bookCopyRepository.updateCopyStatusWithCast(copy.getCopyId(), "RESERVED");
        
        // Decrease available_copies count in books table
        bookRepository.decrementAvailableCopies(bookId);
        
        // Create reservation
        Reservation reservation = new Reservation();
        reservation.setUserId(userId);
        reservation.setCopyId(copy.getCopyId());
        reservation.setStartDate(LocalDate.now());
        reservation.setEndDate(LocalDate.now().plusDays(14)); // 2 week loan period
        reservation.setStatus(ReservationStatus.PENDING);
        
        // Use custom insert method to handle enum casting
        UUID reservationId = UUID.randomUUID();
        reservation.setReservationId(reservationId);
        reservationRepository.insertReservationWithCast(
            reservationId,
            userId,
            copy.getCopyId(),
            LocalDate.now(),
            LocalDate.now().plusDays(14),
            "PENDING",
            LocalDate.now(),
            LocalDate.now().plusDays(5)
        );
        
        // Send confirmation email
        try {
            String bookTitle = bookRepository.findById(bookId)
                .map(book -> book.getTitle())
                .orElse("Unknown Book");
            
            emailService.send(
                userEmail,
                "Book Reservation Confirmed",
                String.format("Your reservation for '%s' has been confirmed. Please pick up your book within 5 days.", bookTitle)
            );
        } catch (Exception e) {
            // Log error but don't fail the reservation
            System.err.println("Failed to send reservation email: " + e.getMessage());
        }
        
        return reservation;
    }
    
    public List<Reservation> getUserReservations(UUID userId) {
        return reservationRepository.findByUserId(userId);
    }
    
    public List<ReservationWithBook> getUserReservationsWithBooks(UUID userId) {
        List<Object[]> results = reservationRepository.findReservationsWithBooksByUserId(userId);
        List<ReservationWithBook> reservations = new ArrayList<>();
        
        for (Object[] row : results) {
            ReservationWithBook reservation = new ReservationWithBook();
            reservation.setReservationId((UUID) row[0]);
            reservation.setUserId((UUID) row[1]);
            reservation.setCopyId((UUID) row[2]);
            reservation.setStartDate(((java.sql.Date) row[3]).toLocalDate());
            reservation.setEndDate(((java.sql.Date) row[4]).toLocalDate());
            reservation.setStatus((String) row[5]);
            reservation.setTitle((String) row[6]);
            reservation.setIsbn((String) row[7]);
            reservation.setCoverImageUrl((String) row[8]);
            if (row[9] != null) {
                reservation.setPublicationYear(((Number) row[9]).intValue());
            }
            reservation.setAuthor((String) row[10]);
            if (row[11] != null) {
                reservation.setReservedAt(((java.sql.Date) row[11]).toLocalDate());
            }
            if (row[12] != null) {
                reservation.setHoldExpiry(((java.sql.Date) row[12]).toLocalDate());
            }
            reservation.setLibraryName((String) row[13]);
            
            reservations.add(reservation);
        }
        
        return reservations;
    }
    
    @Transactional
    public void cancelReservation(UUID reservationId, String userEmail) {
        Reservation reservation = reservationRepository.findById(reservationId)
            .orElseThrow(() -> new RuntimeException("Reservation not found"));
        
        ReservationStatus status = reservation.getStatus();
        if (status != ReservationStatus.PENDING && status != ReservationStatus.CONFIRMED) {
            throw new RuntimeException("Only pending or confirmed reservations can be cancelled. Current status: " + status);
        }
        
        // Update reservation status to cancelled
        reservationRepository.updateReservationStatusWithCast(reservationId, "CANCELLED");
        
        // Update copy status back to available
        bookCopyRepository.updateCopyStatusWithCast(reservation.getCopyId(), "AVAILABLE");
        
        // Get book ID from the copy and increment available_copies count
        BookCopy copy = bookCopyRepository.findById(reservation.getCopyId())
            .orElseThrow(() -> new RuntimeException("Book copy not found"));
        bookRepository.incrementAvailableCopies(copy.getBookId());
        
        // Note: Waitlist promotion is handled automatically by database trigger
        
        // Send cancellation email
        try {
            // Get book title from reservation
            String bookTitle = reservationRepository.findReservationsWithBooksByUserId(reservation.getUserId())
                .stream()
                .filter(row -> row[0].equals(reservationId))
                .findFirst()
                .map(row -> (String) row[6])
                .orElse("Unknown Book");
            
            emailService.send(
                userEmail,
                "Book Reservation Cancelled",
                String.format("Your reservation for '%s' has been cancelled successfully.", bookTitle)
            );
        } catch (Exception e) {
            // Log error but don't fail the cancellation
            System.err.println("Failed to send cancellation email: " + e.getMessage());
        }
    }
    
    public boolean canReserveBook(UUID userId, UUID bookId) {
        // Check if user already has reservation for this book
        if (reservationRepository.hasActiveReservationForBook(userId, bookId)) {
            return false;
        }
        
        // Check if copies are available using books.available_copies
        return bookRepository.findById(bookId)
            .map(book -> book.getAvailableCopies() > 0)
            .orElse(false);
    }
    
    public boolean hasActiveReservationForBook(UUID userId, UUID bookId) {
        return reservationRepository.hasActiveReservationForBook(userId, bookId);
    }
    
    // Admin-only methods
    public List<ReservationWithBook> getAllPendingPickups() {
        List<Object[]> results = reservationRepository.findAllPendingPickups();
        List<ReservationWithBook> reservations = new ArrayList<>();
        
        for (Object[] row : results) {
            ReservationWithBook reservation = new ReservationWithBook();
            reservation.setReservationId((UUID) row[0]);
            reservation.setUserId((UUID) row[1]);
            reservation.setCopyId((UUID) row[2]);
            reservation.setStartDate(((java.sql.Date) row[3]).toLocalDate());
            reservation.setEndDate(((java.sql.Date) row[4]).toLocalDate());
            reservation.setStatus((String) row[5]);
            reservation.setTitle((String) row[6]);
            reservation.setIsbn((String) row[7]);
            reservation.setCoverImageUrl((String) row[8]);
            if (row[9] != null) {
                reservation.setPublicationYear(((Number) row[9]).intValue());
            }
            reservation.setAuthor((String) row[10]);
            if (row[11] != null) {
                reservation.setReservedAt(((java.sql.Date) row[11]).toLocalDate());
            }
            if (row[12] != null) {
                reservation.setHoldExpiry(((java.sql.Date) row[12]).toLocalDate());
            }
            reservation.setLibraryName((String) row[13]);
            reservation.setUserName((String) row[14]);
            
            reservations.add(reservation);
        }
        
        return reservations;
    }
    
    public List<ReservationWithBook> getAllCheckedOutBooks() {
        List<Object[]> results = reservationRepository.findAllCheckedOutBooks();
        List<ReservationWithBook> reservations = new ArrayList<>();
        
        for (Object[] row : results) {
            ReservationWithBook reservation = new ReservationWithBook();
            reservation.setReservationId((UUID) row[0]);
            reservation.setUserId((UUID) row[1]);
            reservation.setCopyId((UUID) row[2]);
            reservation.setStartDate(((java.sql.Date) row[3]).toLocalDate());
            reservation.setEndDate(((java.sql.Date) row[4]).toLocalDate());
            reservation.setStatus((String) row[5]);
            reservation.setTitle((String) row[6]);
            reservation.setIsbn((String) row[7]);
            reservation.setCoverImageUrl((String) row[8]);
            if (row[9] != null) {
                reservation.setPublicationYear(((Number) row[9]).intValue());
            }
            reservation.setAuthor((String) row[10]);
            if (row[11] != null) {
                reservation.setReservedAt(((java.sql.Date) row[11]).toLocalDate());
            }
            if (row[12] != null) {
                reservation.setHoldExpiry(((java.sql.Date) row[12]).toLocalDate());
            }
            reservation.setLibraryName((String) row[13]);
            reservation.setUserName((String) row[14]); // User name for admin view
            
            reservations.add(reservation);
        }
        
        return reservations;
    }
    
    @Transactional
    public void markAsPickedUp(UUID reservationId) {
        Reservation reservation = reservationRepository.findById(reservationId)
            .orElseThrow(() -> new RuntimeException("Reservation not found"));
        
        if (reservation.getStatus() != ReservationStatus.PENDING) {
            throw new RuntimeException("Only pending reservations can be marked as picked up");
        }
        
        reservationRepository.updateReservationStatusWithCast(reservationId, "CONFIRMED");
        
        // Send pickup confirmation email
        try {
            String userEmail = userRepository.findById(reservation.getUserId())
                .map(user -> user.getEmail())
                .orElse(null);
            String bookTitle = bookRepository.findById(
                bookCopyRepository.findById(reservation.getCopyId())
                    .map(copy -> copy.getBookId())
                    .orElse(null)
            ).map(book -> book.getTitle()).orElse("Unknown Book");
            
            if (userEmail != null) {
                emailService.send(
                    userEmail,
                    "Book Pickup Confirmed",
                    String.format("You have successfully picked up '%s' from the library. Please return it by %s.", 
                        bookTitle, reservation.getEndDate())
                );
            }
        } catch (Exception e) {
            System.err.println("Failed to send pickup confirmation email: " + e.getMessage());
        }
    }
    
    @Transactional
    public void markAsReturned(UUID reservationId) {
        Reservation reservation = reservationRepository.findById(reservationId)
            .orElseThrow(() -> new RuntimeException("Reservation not found"));
        
        if (reservation.getStatus() != ReservationStatus.CONFIRMED) {
            throw new RuntimeException("Only confirmed reservations can be marked as returned");
        }
        
        // Get book copy info before updating status
        BookCopy copy = bookCopyRepository.findById(reservation.getCopyId())
            .orElseThrow(() -> new RuntimeException("Book copy not found"));
        
        // Update reservation status to completed
        reservationRepository.updateReservationStatusWithCast(reservationId, "COMPLETED");
        
        // Update copy status to available - this should trigger waitlist promotion
        bookCopyRepository.updateCopyStatusWithCast(reservation.getCopyId(), "AVAILABLE");
        
        // Increment available_copies count in books table
        bookRepository.incrementAvailableCopies(copy.getBookId());
        
        // Send return confirmation email
        try {
            String userEmail = userRepository.findById(reservation.getUserId())
                .map(user -> user.getEmail())
                .orElse(null);
            String bookTitle = bookRepository.findById(copy.getBookId())
                .map(book -> book.getTitle())
                .orElse("Unknown Book");
            
            if (userEmail != null) {
                emailService.send(
                    userEmail,
                    "Book Return Confirmed",
                    String.format("Thank you for returning '%s'. The book has been successfully returned to the library.", bookTitle)
                );
            }
        } catch (Exception e) {
            System.err.println("Failed to send return confirmation email: " + e.getMessage());
        }
    }

}