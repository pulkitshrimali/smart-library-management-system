package com.example.ELEC5619.Service;

import com.example.ELEC5619.Model.Book;
import com.example.ELEC5619.Repository.BookRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class BookService {

    private final BookRepository bookRepository;

    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    public List<Book> searchBooks(String query, String availability, String genre, String library, String year) {
        LocalDate startDate = null;
        LocalDate endDate = null;

        if (year != null) {
            switch (year) {
                case "<=1950" -> endDate = LocalDate.of(1950, 12, 31);
                case "1951-2000" -> {
                    startDate = LocalDate.of(1951, 1, 1);
                    endDate = LocalDate.of(2000, 12, 31);
                }
                case ">2000" -> startDate = LocalDate.of(2001, 1, 1);
            }
        }

        String searchPattern = (query == null || query.isBlank()) ? null : "%" + query.toLowerCase() + "%";

        return bookRepository.searchBooks(searchPattern, availability, genre, library, startDate, endDate);
    }

    public Optional<Book> getRandomBook() {
        return bookRepository.findRandomBook();
    }
}
