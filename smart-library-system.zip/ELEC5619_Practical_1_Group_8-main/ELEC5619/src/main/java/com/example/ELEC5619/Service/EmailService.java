package com.example.ELEC5619.Service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;


/**
 * Service class responsible for sending plain text email notifications.
 * <p>
 * This class uses Spring's {@link JavaMailSender} to construct and send
 * simple mail messages. The default sender address is configured via
 * the {@code spring.mail.from} property in the application settings.
 */
@Service
public class EmailService {

    /** Spring's mail sender component used to send emails. */
    private final JavaMailSender mailSender;

    /**
     * Default sender email address, injected from the application configuration.
     * If not provided, a fallback value {@code Library.hub@example.com} is used.
     */
    @Value("${spring.mail.from:}")
    private String from;

    /**
     * Constructs an {@code EmailService} with the provided mail sender dependency.
     *
     * @param mailSender the {@link JavaMailSender} instance used to send emails
     */
    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    /**
     * Sends a simple text-based email to a single recipient.
     * <p>
     * The method constructs a {@link SimpleMailMessage} using the provided parameters
     * and delegates sending to the configured {@link JavaMailSender}. If the configured
     * {@code from} address is blank, a default value is used.
     *
     * @param to      the recipient email address
     * @param subject the subject line of the email
     * @param text    the body text of the email
     */
    public void send(String to, String subject, String text) {
        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setFrom(from == null || from.isBlank() ? "Library.hub@example.com" : from);
        msg.setTo(to);
        msg.setSubject(subject);
        msg.setText(text);
        mailSender.send(msg);
    }
}
