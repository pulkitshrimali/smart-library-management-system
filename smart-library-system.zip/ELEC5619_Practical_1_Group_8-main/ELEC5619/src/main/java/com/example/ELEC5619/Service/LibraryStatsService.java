package com.example.ELEC5619.Service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class LibraryStatsService {

    private final JdbcTemplate jdbcTemplate;

    public LibraryStatsService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public LibraryStats getStats() {
        int titlesCatalogued = queryForInt(
                "SELECT COALESCE(COUNT(*), 0) FROM libraryhub.books"
        );

        int booksAvailable = queryForInt(
                "SELECT COALESCE(SUM(available_copies), 0) FROM libraryhub.books"
        );

        int activeReaders = queryForInt(
                """
                SELECT COUNT(*) FROM (
                    SELECT user_id FROM libraryhub.reservation
                    UNION
                    SELECT user_id FROM libraryhub.favourites
                    UNION
                    SELECT user_id FROM libraryhub.reviews
                ) AS active_users
                """
        );

        int totalGenres = queryForInt(
                "SELECT COALESCE(COUNT(*), 0) FROM libraryhub.genre"
        );

        return new LibraryStats(titlesCatalogued, booksAvailable, activeReaders, totalGenres);
    }

    private int queryForInt(String sql) {
        Integer result = jdbcTemplate.queryForObject(sql, Integer.class);
        return result != null ? result : 0;
    }

    public record LibraryStats(int titlesCatalogued, int booksAvailable, int activeReaders, int totalGenres) {}
}
