package com.example.ELEC5619.Model;

import jakarta.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "authors")
public class Author {
    @Id
    private UUID authorId;

    @Column(nullable = false)
    private String name;

    public UUID getAuthorId() { return authorId; }
    public void setAuthorId(UUID authorId) { this.authorId = authorId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
}
