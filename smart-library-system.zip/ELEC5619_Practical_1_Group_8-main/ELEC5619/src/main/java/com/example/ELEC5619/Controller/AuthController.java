package com.example.ELEC5619.Controller;

import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.ELEC5619.Model.PasswordResetToken;
import com.example.ELEC5619.Model.User;
import com.example.ELEC5619.Repository.PasswordResetTokenRepository;
import com.example.ELEC5619.Repository.UserRepository;
import com.example.ELEC5619.Service.EmailService;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Controller responsible for handling user authentication, registration,
 * password reset, and session management.
 */
@RestController
@RequestMapping("/auth")
public class AuthController {
    private static final Logger log = LoggerFactory.getLogger(AuthController.class);

    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final PasswordResetTokenRepository resetTokens;
    private final EmailService emailService;

    @Value("${app.url:http://localhost:8080}")
    private String appUrl;

    @Value("${app.reset.token.ttl.minutes:30}")
    private int resetTtlMinutes;

    public AuthController(UserRepository users,
                          PasswordEncoder encoder,
                          PasswordResetTokenRepository resetTokens,
                          EmailService emailService) {
        this.users = users;
        this.encoder = encoder;
        this.resetTokens = resetTokens;
        this.emailService = emailService;
        log.info("AuthController initialized");
    }

    /** Registers a new user account */
    @PostMapping("/signup")
    public ResponseEntity<Map<String, Object>> signup(@RequestBody Map<String, Object> body,
                                                      HttpServletResponse response) {
        String name = str(body.get("name"));
        String email = str(body.get("email"));
        String phone = str(body.get("phoneNumber"));
        String pass = str(body.get("password"));

        if (email == null || email.isBlank() || pass == null || pass.isBlank()) {
            return ResponseEntity.badRequest().body(error(400, "Email and password are required"));
        }
        if (users.existsByEmailIgnoreCase(email)) {
            return ResponseEntity.status(409).body(error(409, "Email already registered"));
        }

        if (phone != null && !phone.isBlank() && !phone.matches("^0\\d{9}$")) {
            return ResponseEntity.badRequest().body(error(400, "Phone must be 10 digits starting with 0."));
        }

        User u = new User();
        u.setUserId(UUID.randomUUID());
        u.setName(name != null && !name.isBlank() ? name : "User");
        u.setEmail(email.trim().toLowerCase());
        u.setPassword(encoder.encode(pass));
        u.setRole(optOrDefault(str(body.get("role")), "USER"));
        u.setPhoneNumber(phone);
        u.setCreatedAt(OffsetDateTime.now());

        String birthDateStr = str(body.get("birthDate"));
        if (birthDateStr != null && !birthDateStr.isBlank()) {
            u.setBirthDate(LocalDate.parse(birthDateStr));
        }

        u = users.save(u);

        Cookie cookie = new Cookie("userEmail", u.getEmail());
        cookie.setHttpOnly(true);
        cookie.setSecure(false);
        cookie.setPath("/");
        cookie.setMaxAge(24 * 60 * 60);
        response.addCookie(cookie);

        return ResponseEntity.ok(okUser(u));
    }

    /** Authenticates a user */
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, Object> body,
                                                     HttpServletResponse response) {
        String email = str(body.get("email"));
        String pass = str(body.get("password"));
 

        if (email == null || pass == null)
            return ResponseEntity.badRequest().body(error(400, "Email and password are required"));

        User u = users.findByEmailIgnoreCase(email).orElse(null);
        if (u == null || !encoder.matches(pass, u.getPassword()))
            return ResponseEntity.status(401).body(error(401, "Invalid credentials"));

        Cookie cookie = new Cookie("userEmail", u.getEmail());
        cookie.setHttpOnly(true);
        cookie.setSecure(false);
        cookie.setPath("/");
        cookie.setMaxAge(24 * 60 * 60);
        response.addCookie(cookie);

        return ResponseEntity.ok(okUser(u));
    }

    /** Retrieves the current logged-in user */
    @GetMapping("/me")
    public Map<String, Object> whoAmI(@CookieValue(value = "userEmail", required = false) String email) {
        if (email == null) return error(401, "Not logged in");
        User u = users.findByEmailIgnoreCase(email).orElse(null);
        if (u == null) return error(404, "User not found");
        return okUser(u);
    }

    /** Fetches a user by UUID */
    @GetMapping("/users/{id}")
    public Map<String, Object> getById(@PathVariable UUID id) {
        return users.findById(id).map(this::okUser).orElseGet(() -> error(404, "User not found"));
    }

    /** Fetches a user by email */
    @GetMapping("/users/by-email")
    public Map<String, Object> getByEmail(@RequestParam String email) {
        return users.findByEmailIgnoreCase(email).map(this::okUser).orElseGet(() -> error(404, "User not found"));
    }

    /** Sends password reset link */
    @PostMapping("/forgot")
    public ResponseEntity<?> forgotPassword(@RequestBody Map<String, Object> body) {
        String email = str(body.get("email"));
        if (email == null || email.isBlank()) {
            return ResponseEntity.badRequest().body(error(400, "Email is required"));
        }

        var userOpt = users.findByEmailIgnoreCase(email);
        if (userOpt.isPresent()) {
            var u = userOpt.get();
            resetTokens.deleteByUserId(u.getUserId());

            String token = generateToken();
            var prt = new PasswordResetToken();
            prt.setUserId(u.getUserId());
            prt.setToken(token);
            prt.setExpiresAt(OffsetDateTime.now().plus(resetTtlMinutes, ChronoUnit.MINUTES));
            resetTokens.save(prt);

            String link = appUrl + "/reset.html?token=" + token;
            String bodyText = """
                    You requested a password reset for your account.

                    Click the link below to reset your password (expires in %d minutes):
                    %s

                    If you did not request this, please ignore this email.
                    """.formatted(resetTtlMinutes, link);

            emailService.send(u.getEmail(), "Password Reset", bodyText);
        }

        return ResponseEntity.ok(Map.of("status", "ok"));
    }

    /** Resets password using token */
    @PostMapping("/reset")
    public ResponseEntity<?> resetPassword(@RequestBody Map<String, Object> body,
                                           HttpServletResponse response) {
        String token = str(body.get("token"));
        String newPass = str(body.get("newPassword"));

        if (token == null || token.isBlank() || newPass == null || newPass.isBlank()) {
            return ResponseEntity.badRequest().body(error(400, "Token and newPassword are required"));
        }

        var opt = resetTokens.findByToken(token);
        if (opt.isEmpty()) return ResponseEntity.status(400).body(error(400, "Invalid token"));

        var t = opt.get();
        if (t.isUsed() || t.getExpiresAt().isBefore(OffsetDateTime.now())) {
            return ResponseEntity.status(400).body(error(400, "Token expired or used"));
        }

        var userOpt = users.findById(t.getUserId());
        if (userOpt.isEmpty()) return ResponseEntity.status(404).body(error(404, "User not found"));

        var u = userOpt.get();
        u.setPassword(encoder.encode(newPass));
        users.save(u);

        t.setUsed(true);
        resetTokens.save(t);

        Cookie cookie = new Cookie("userEmail", u.getEmail());
        cookie.setHttpOnly(true);
        cookie.setSecure(false);
        cookie.setPath("/");
        cookie.setMaxAge(24 * 60 * 60);
        response.addCookie(cookie);

        return ResponseEntity.ok(Map.of("status", "ok"));
    }

    /** Logs user out */
    @PostMapping("/logout")
    public ResponseEntity<Map<String, Object>> logout(HttpServletResponse response) {
        Cookie cookie = new Cookie("userEmail", "");
        cookie.setHttpOnly(true);
        cookie.setSecure(false);
        cookie.setPath("/");
        cookie.setMaxAge(0);
        response.addCookie(cookie);

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("status", "ok");
        resp.put("message", "Logged out successfully");
        return ResponseEntity.ok(resp);
    }

    /* ===== Helper Methods ===== */

    private String str(Object o) { return o == null ? null : String.valueOf(o); }

    private String optOrDefault(String v, String def) { return v == null || v.isBlank() ? def : v; }

    private String generateToken() {
        byte[] bytes = new byte[32];
        new SecureRandom().nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    private Map<String, Object> okUser(User u) {
        Map<String, Object> resp = new LinkedHashMap<>();
        Map<String, Object> user = new LinkedHashMap<>();

        user.put("userId", u.getUserId());
        user.put("name", u.getName());
        user.put("birthDate", u.getBirthDate());
        user.put("email", u.getEmail());
        user.put("role", u.getRole());
        user.put("phoneNumber", u.getPhoneNumber());
        user.put("createdAt", u.getCreatedAt());

        resp.put("status", "ok");
        resp.put("user", user);
        return resp;
    }

    private Map<String, Object> error(int code, String message) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("status", "error");
        m.put("code", code);
        m.put("message", message);
        return m;
    }
}
