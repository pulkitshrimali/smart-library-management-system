package com.example.ELEC5619.Controller;

import com.example.ELEC5619.Model.Author;
import com.example.ELEC5619.Model.Book;
import com.example.ELEC5619.Model.Genre;
import com.example.ELEC5619.Repository.AuthorRepository;
import com.example.ELEC5619.Repository.BookRepository;
import com.example.ELEC5619.Repository.GenreRepository;
import jakarta.transaction.Transactional;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
import java.util.LinkedHashMap;

/**
 * Controller that handles all administrative book management operations,
 * including creating, updating, and deleting books.
 * <p>
 * This controller interacts with {@link BookRepository}, {@link AuthorRepository},
 * and {@link GenreRepository} to maintain relationships between books, authors, and genres.
 */
@RestController
@CrossOrigin
@RequestMapping("/admin/books")
public class AdminController {

    private final BookRepository books;
    private final AuthorRepository authors;
    private final GenreRepository genres;

    /**
     * Constructs a new {@code AdminController} with the required repositories.
     *
     * @param books    the repository for managing book entities
     * @param authors  the repository for managing author entities
     * @param genres   the repository for managing genre entities
     */
    public AdminController(BookRepository books, AuthorRepository authors, GenreRepository genres) {
        this.books = books;
        this.authors = authors;
        this.genres = genres;
    }

    /**
     * Creates a new book entry in the system.
     * <p>
     * If the provided ISBN already exists, a 409 Conflict response is returned.
     * Missing title or ISBN will trigger a 400 Bad Request error.
     * The availableCopies are automatically set equal to totalCopies.
     *
     * @param body a map containing book details (title, ISBN, authors, genre, etc.)
     * @return a JSON payload of the created book, or an error response
     */
    @PostMapping
    @Transactional
    public ResponseEntity<?> create(@RequestBody Map<String, Object> body) {
        String title = str(body.get("title"));
        String isbn = str(body.get("isbn"));

        if (isBlank(title) || isBlank(isbn)) {
            return ResponseEntity.badRequest().body(error(400, "Title and ISBN are required"));
        }
        if (books.findByIsbn(isbn).isPresent()) {
            return ResponseEntity.status(409).body(error(409, "ISBN already exists"));
        }

        Book b = new Book();
        b.setTitle(title.trim());
        b.setIsbn(isbn.trim());

        applyAllFields(b, body, false);

        Integer total = b.getTotalCopies();
        if (total == null) {
            total = 1;
            b.setTotalCopies(1);
        }
        b.setAvailableCopies(total);

        Book saved = books.save(b);
        return ResponseEntity.ok(toPayload(saved));
    }

    /**
     * Updates an existing book identified by its ISBN.
     * <p>
     * Allows changing the ISBN if the new one is unique. The availableCopies are
     * synchronized with totalCopies to maintain consistency.
     *
     * @param isbn the ISBN of the existing book
     * @param body a map containing updated book details
     * @return a JSON payload of the updated book, or an error response if not found or duplicated
     */
    @PutMapping("/{isbn}")
    @Transactional
    public ResponseEntity<?> update(@PathVariable String isbn, @RequestBody Map<String, Object> body) {
        Book b = books.findByIsbn(isbn).orElse(null);
        if (b == null) {
            return ResponseEntity.status(404).body(error(404, "Book not found"));
        }

        applyAllFields(b, body, true);

        String newIsbn = str(body.get("isbn"));
        if (!isBlank(newIsbn) && !newIsbn.equals(isbn)) {
            var existingWithNewIsbn = books.findByIsbn(newIsbn.trim());
            if (existingWithNewIsbn.isPresent()
                    && !Objects.equals(existingWithNewIsbn.get().getBookId(), b.getBookId())) {
                return ResponseEntity.status(409).body(error(409, "ISBN already exists"));
            }
            b.setIsbn(newIsbn.trim());
        }

        Integer total = b.getTotalCopies();
        if (total == null) {
            total = 1;
            b.setTotalCopies(1);
        }
        b.setAvailableCopies(total);

        Book saved = books.save(b);
        return ResponseEntity.ok(toPayload(saved));
    }

    /**
     * Deletes a book by its ISBN.
     * <p>
     * Also removes any existing relationships from the book-author linking table.
     *
     * @param isbn the ISBN of the book to delete
     * @return a JSON response indicating whether the deletion was successful
     */
    @DeleteMapping("/{isbn}")
    @Transactional
    public ResponseEntity<?> delete(@PathVariable String isbn) {
        Book b = books.findByIsbn(isbn).orElse(null);
        if (b == null) {
            return ResponseEntity.status(404).body(error(404, "Book not found"));
        }

        books.deleteBookAuthorLinks(b.getBookId());
        books.delete(b);
        return ResponseEntity.ok(Map.of("deleted", true));
    }

    /**
     * Applies or updates book fields from the provided request body.
     * <p>
     * Handles authors and genres, ensuring new entities are created if missing.
     *
     * @param b        the book entity being modified
     * @param body     the input data from the request
     * @param isUpdate {@code true} if this is an update operation, {@code false} otherwise
     */
    private void applyAllFields(Book b, Map<String, Object> body, boolean isUpdate) {
        String title = str(body.get("title"));
        if (!isBlank(title)) b.setTitle(title.trim());

        String blurb = str(body.get("blurb"));
        if (!isUpdate || body.containsKey("blurb")) b.setBlurb(blurb);

        LocalDate publicationDate = parseDate(body.get("publicationDate"));
        if (!isUpdate || body.containsKey("publicationDate")) b.setPublicationDate(publicationDate);

        String publisher = str(body.get("publisher"));
        if (!isUpdate || body.containsKey("publisher")) b.setPublisher(publisher);

        Integer totalCopies = intval(body.get("totalCopies"));
        if (!isUpdate || body.containsKey("totalCopies")) {
            b.setTotalCopies(totalCopies == null ? null : Math.max(0, totalCopies));
        }

        String cover = str(body.get("coverImageUrl"));
        if (!isUpdate || body.containsKey("coverImageUrl")) b.setCoverImageUrl(cover);

        if (!isUpdate || body.containsKey("authors")) {
            List<Author> resolvedAuthors = parseAuthors(body.get("authors"));
            b.setAuthors(resolvedAuthors);
        }

        if (!isUpdate || body.containsKey("genre") || body.containsKey("genreName")) {
            String gname = body.containsKey("genreName")
                    ? str(body.get("genreName"))
                    : extractGenreName(body.get("genre"));
            Genre g = resolveGenreByName(gname);
            b.setGenre(g);
        }
    }

    /**
     * Converts a {@link Book} entity into a structured response map.
     *
     * @param b the book entity
     * @return a map representing the book in JSON format
     */
    private Map<String, Object> toPayload(Book b) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("bookId", b.getBookId() == null ? null : b.getBookId().toString());
        m.put("title", b.getTitle());
        m.put("isbn", b.getIsbn());
        m.put("blurb", b.getBlurb());
        m.put("publicationDate", b.getPublicationDate() == null ? null : b.getPublicationDate().toString());
        m.put("publisher", b.getPublisher());
        m.put("totalCopies", b.getTotalCopies());
        m.put("availableCopies", b.getAvailableCopies());
        m.put("coverImageUrl", b.getCoverImageUrl());

        List<Map<String, Object>> authorList = (b.getAuthors() == null ? 
        List.<Map<String, Object>>of() :
        b.getAuthors().stream()
                .map(a -> Map.<String, Object>of("name", a.getName()))
                .toList());

        m.put("authors", authorList);

        if (b.getGenre() != null) {
            m.put("genre", Map.of(
                    "genreId", b.getGenre().getGenreId().toString(),
                    "name", b.getGenre().getName()
            ));
        } else {
            m.put("genre", null);
        }
        return m;
    }

    /**
     * Safely converts an object to a string.
     *
     * @param o the object to convert
     * @return its string representation or {@code null} if the input is null
     */
    private String str(Object o) { return o == null ? null : String.valueOf(o); }

    /**
     * Checks whether a string is null or blank.
     *
     * @param s the string to check
     * @return {@code true} if blank or null, otherwise {@code false}
     */
    private boolean isBlank(String s) { return s == null || s.isBlank(); }

    /**
     * Parses an object into an integer if possible.
     *
     * @param o the object to convert
     * @return integer value or {@code null} if conversion fails
     */
    private Integer intval(Object o) {
        if (o == null) return null;
        try {
            if (o instanceof Number n) return n.intValue();
            return Integer.parseInt(String.valueOf(o));
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Parses supported date formats into {@link LocalDate}.
     * Accepts formats like YYYY, YYYY-MM-DD, or ISO date-time.
     *
     * @param o the object containing a date value
     * @return parsed {@link LocalDate} or {@code null} if invalid
     */
    private LocalDate parseDate(Object o) {
        if (o == null) return null;
        try {
            if (o instanceof Number n) return LocalDate.of(n.intValue(), 1, 1);
            String s = String.valueOf(o).trim();
            if (s.isBlank()) return null;
            if (s.length() >= 10 && s.charAt(4) == '-' && s.charAt(7) == '-')
                return LocalDate.parse(s.substring(0, 10));
            if (s.length() == 4) return LocalDate.of(Integer.parseInt(s), 1, 1);
            return LocalDate.parse(s);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Parses authors from either a comma-separated string or list of maps.
     * <p>
     * Creates new authors if they do not already exist in the repository.
     *
     * @param o author field from the request body
     * @return a list of resolved {@link Author} entities
     */
    private List<Author> parseAuthors(Object o) {
        if (o == null) return Collections.emptyList();

        List<String> names = new ArrayList<>();
        if (o instanceof Collection<?> col) {
            for (Object el : col) {
                if (el instanceof Map<?, ?> m) {
                    Object n = m.get("name");
                    if (n != null && !String.valueOf(n).isBlank()) {
                        names.add(String.valueOf(n).trim());
                    }
                } else if (el != null) {
                    names.add(String.valueOf(el).trim());
                }
            }
        } else {
            String s = String.valueOf(o);
            names.addAll(Arrays.stream(s.split(","))
                    .map(String::trim)
                    .filter(x -> !x.isBlank())
                    .collect(Collectors.toList()));
        }

        if (names.isEmpty()) return Collections.emptyList();

        List<Author> result = new ArrayList<>();
        for (String nm : names) {
            authors.findByNameIgnoreCase(nm).ifPresentOrElse(
                result::add,
                () -> {
                    Author a = new Author();
                    a.setAuthorId(UUID.randomUUID());
                    a.setName(nm);
                    result.add(authors.save(a));
                }
            );
        }
        return result;
    }

    /**
     * Extracts the genre name from various input formats.
     * Accepts either a string or a map with a "name" key.
     *
     * @param genreField the genre field from the request
     * @return the extracted genre name, or {@code null} if not found
     */
    private String extractGenreName(Object genreField) {
        if (genreField == null) return null;
        if (genreField instanceof Map<?, ?> m) {
            Object n = m.get("name");
            return n == null ? null : String.valueOf(n).trim();
        }
        return String.valueOf(genreField).trim();
    }

    /**
     * Finds a genre by name or creates it if not found.
     *
     * @param name the genre name to resolve
     * @return the resolved or newly created {@link Genre}
     */
    private Genre resolveGenreByName(String name) {
        if (isBlank(name)) return null;
        String clean = name.trim();
        return genres.findByNameIgnoreCase(clean).orElseGet(() -> {
            Genre g = new Genre();
            g.setGenreId(UUID.randomUUID());
            g.setName(clean);
            return genres.save(g);
        });
    }

    /**
     * Creates a standardized error response payload.
     *
     * @param code    HTTP status code
     * @param message error message
     * @return a map containing status and message keys
     */
    private Map<String, Object> error(int code, String message) {
        return Map.of("status", code, "message", message);
    }
}
