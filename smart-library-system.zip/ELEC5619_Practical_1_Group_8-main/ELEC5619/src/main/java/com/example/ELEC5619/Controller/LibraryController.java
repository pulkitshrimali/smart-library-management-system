package com.example.ELEC5619.Controller;

import com.example.ELEC5619.Model.Library;
import com.example.ELEC5619.Repository.LibraryRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;  

import java.util.List;

@RestController
@RequestMapping("/api/libraries")
public class LibraryController {

    private final LibraryRepository libraryRepository;

    public LibraryController(LibraryRepository libraryRepository) {
        this.libraryRepository = libraryRepository;
    }

    @GetMapping
    public List<Library> getAllLibraries() {
        return libraryRepository.findAll();
    }
}
