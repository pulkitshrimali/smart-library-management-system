package com.example.ELEC5619.Service;

import com.example.ELEC5619.Model.Waitlist;
import com.example.ELEC5619.Repository.WaitlistRepository;
import com.example.ELEC5619.Repository.BookRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class WaitlistService {

    private final WaitlistRepository waitlistRepository;
    private final BookRepository bookRepository;

    public WaitlistService(WaitlistRepository waitlistRepository, BookRepository bookRepository) {
        this.waitlistRepository = waitlistRepository;
        this.bookRepository = bookRepository;
    }

    @Transactional
    public Waitlist joinWaitlist(UUID userId, UUID bookId, UUID libraryId) {
        // Check if user is already on waitlist
        if (waitlistRepository.findByUserIdAndBookId(userId, bookId).isPresent()) {
            throw new RuntimeException("You are already on the waitlist for this book");
        }

        Waitlist waitlist = new Waitlist();
        waitlist.setUserId(userId);
        waitlist.setBookId(bookId);
        waitlist.setLibraryId(libraryId);
        
        return waitlistRepository.save(waitlist);
    }

    @Transactional
    public void leaveWaitlist(UUID userId, UUID bookId) {
        Waitlist waitlist = waitlistRepository.findByUserIdAndBookId(userId, bookId)
            .orElseThrow(() -> new RuntimeException("You are not on the waitlist for this book"));
        
        waitlistRepository.delete(waitlist);
    }

    public Optional<Waitlist> getUserWaitlistEntry(UUID userId, UUID bookId) {
        return waitlistRepository.findByUserIdAndBookId(userId, bookId);
    }

    public List<Waitlist> getUserWaitlist(UUID userId) {
        return waitlistRepository.findByUserId(userId);
    }

    public List<Waitlist> getBookWaitlist(UUID bookId) {
        return waitlistRepository.findByBookIdOrderByPosition(bookId);
    }

    public Long getWaitlistCount(UUID bookId) {
        return waitlistRepository.countByBookId(bookId);
    }
    
    public List<Waitlist> getUserWaitlistWithBooks(UUID userId) {
        return waitlistRepository.findByUserId(userId);
    }

    @Transactional
    public Optional<Waitlist> promoteNextUser(UUID bookId) {
        return waitlistRepository.findFirstInQueue(bookId);
    }
    
    @Transactional
    public void removeFromWaitlist(UUID waitlistId) {
        waitlistRepository.deleteById(waitlistId);
    }
    
    @Transactional
    public void promoteWaitlistForBook(UUID bookId) {
        // This method will be called when a book becomes available
        // The actual promotion logic is handled by the database trigger
        // This is just a placeholder for explicit promotion calls
    }
}