package com.example.ELEC5619.Service;

import com.example.ELEC5619.Model.Review;
import com.example.ELEC5619.Repository.ReviewRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ReviewService {
    private final ReviewRepository reviewRepository;

    public ReviewService(ReviewRepository reviewRepository) {
        this.reviewRepository = reviewRepository;
    }

    public List<Review> getReviewsByBook(UUID bookId) {
        List<Review> reviews = reviewRepository.findByBookId(bookId);
        // Populate user names
        for (Review review : reviews) {
            String userName = getUserNameById(review.getUserId());
            review.setUserName(userName != null ? userName : "Unknown User");
        }
        return reviews;
    }
    
    private String getUserNameById(UUID userId) {
        // Simple query to get user name - you might want to inject UserRepository
        try {
            return reviewRepository.findUserNameById(userId);
        } catch (Exception e) {
            return null;
        }
    }

    public Review getReviewById(UUID reviewId) {
        Review review = reviewRepository.findById(reviewId)
            .orElseThrow(() -> new RuntimeException("Review not found"));
        
        // Populate user name
        String userName = getUserNameById(review.getUserId());
        review.setUserName(userName != null ? userName : "Unknown User");
        
        return review;
    }

    public Review addReview(Review review) {
        return reviewRepository.save(review);
    }

    public Review updateReview(UUID reviewId, Review newReview, UUID userId) {
        return reviewRepository.findById(reviewId)
            .map(r -> {
                if (!r.getUserId().equals(userId)) {
                    throw new RuntimeException("You can only update your own reviews");
                }
                r.setRating(newReview.getRating());
                r.setReviewText(newReview.getReviewText());
                return reviewRepository.save(r);
            })
            .orElseThrow(() -> new RuntimeException("Review not found"));
    }

    // This method is no longer used - only admins can delete reviews
    @Deprecated
    public void deleteReview(UUID reviewId, UUID userId) {
        throw new RuntimeException("Regular users cannot delete reviews. Only administrators can moderate reviews.");
    }
    
    public void deleteReviewAsAdmin(UUID reviewId) {
        if (!reviewRepository.existsById(reviewId)) {
            throw new RuntimeException("Review not found");
        }
        reviewRepository.deleteById(reviewId);
    }
}