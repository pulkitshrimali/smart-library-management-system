package com.example.ELEC5619.Service;

import com.example.ELEC5619.Model.ReviewComment;
import com.example.ELEC5619.Repository.ReviewCommentRepository;
import com.example.ELEC5619.DTO.CommentWithUserDTO;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.UUID;

@Service
public class ReviewCommentService {
    private final ReviewCommentRepository repository;

    public ReviewCommentService(ReviewCommentRepository repository) {
        this.repository = repository;
    }

    public List<CommentWithUserDTO> getCommentsByReview(UUID reviewId) {
        return repository.findCommentsWithUserByReviewId(reviewId);
    }

    public List<ReviewComment> getRepliesByComment(UUID parentId) {
        return repository.findByParentIdOrderByCreatedAtAsc(parentId);
    }

    public ReviewComment addComment(ReviewComment comment) {
        return repository.save(comment);
    }

    public void deleteComment(UUID commentId) {
        repository.deleteById(commentId);
    }
}