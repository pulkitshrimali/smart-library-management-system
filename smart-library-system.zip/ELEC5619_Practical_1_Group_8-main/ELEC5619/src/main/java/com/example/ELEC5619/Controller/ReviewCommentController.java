package com.example.ELEC5619.Controller;

import java.util.List;
import java.util.UUID;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.http.ResponseEntity;

import com.example.ELEC5619.Model.ReviewComment;
import com.example.ELEC5619.Model.User;
import com.example.ELEC5619.Service.ReviewCommentService;
import com.example.ELEC5619.Repository.UserRepository;
import com.example.ELEC5619.DTO.CommentWithUserDTO;

/**
 * REST controller for managing comments on book reviews.
 * Provides endpoints to get, add, and delete comments and retrieve replies.
 */
@RestController
@RequestMapping("/api/reviews/{reviewId}/comments")
@CrossOrigin(origins = "*")
public class ReviewCommentController {
    private final ReviewCommentService service;
    private final UserRepository userRepository;

    public ReviewCommentController(ReviewCommentService service, UserRepository userRepository) {
        this.service = service;
        this.userRepository = userRepository;
    }

    /**
     * Get all comments for a specific review.
     * @param reviewId UUID of the review
     * @return list of comments with user names
     */
    @GetMapping
    public List<CommentWithUserDTO> getComments(@PathVariable UUID reviewId) {
        return service.getCommentsByReview(reviewId);
    }

    /**
     * Get all replies for a specific comment.
     * @param commentId UUID of the comment
     * @return list of replies
     */
    @GetMapping("/{commentId}/replies")
    public List<ReviewComment> getReplies(@PathVariable UUID commentId) {
        return service.getRepliesByComment(commentId);
    }

    /**
     * Add a new comment to a review.
     * @param reviewId UUID of the review
     * @param comment Comment object from request body
     * @param userEmail Email from cookie
     * @return created comment
     */
    @PostMapping
    public ResponseEntity<ReviewComment> addComment(@PathVariable UUID reviewId, 
                                                   @RequestBody ReviewComment comment,
                                                   @CookieValue(value = "userEmail", required = false) String userEmail) {
        if (userEmail == null) {
            return ResponseEntity.status(401).build();
        }
        
        User user = userRepository.findByEmailIgnoreCase(userEmail).orElse(null);
        if (user == null) {
            return ResponseEntity.status(401).build();
        }
        
        comment.setReviewId(reviewId);
        comment.setUserId(user.getUserId());
        ReviewComment savedComment = service.addComment(comment);
        return ResponseEntity.ok(savedComment);
    }

    /**
     * Delete a comment by its ID.
     * @param commentId UUID of the comment
     */
    @DeleteMapping("/{commentId}")
    public void deleteComment(@PathVariable UUID commentId) {
        service.deleteComment(commentId);
    }
}