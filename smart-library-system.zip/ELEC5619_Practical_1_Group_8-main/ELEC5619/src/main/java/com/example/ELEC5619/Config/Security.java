package com.example.ELEC5619.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * Configuration class that defines security-related beans for the application.
 * <p>
 * This class primarily provides a {@link PasswordEncoder} bean using the
 * BCrypt hashing algorithm, which is used to securely hash and verify user passwords.
 */
@Configuration
public class Security {

    /**
     * Creates and exposes a {@link PasswordEncoder} bean configured with the BCrypt algorithm.
     * <p>
     * The strength parameter (cost factor) is set to 12, which balances security and performance.
     * Higher cost factors increase the computational effort required to hash and verify passwords,
     * improving resistance to brute-force attacks.
     *
     * @return a {@link BCryptPasswordEncoder} instance with strength 12
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12); // cost 12
    }
}
