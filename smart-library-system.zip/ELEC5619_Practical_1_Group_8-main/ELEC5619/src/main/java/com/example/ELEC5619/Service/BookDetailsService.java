package com.example.ELEC5619.Service;

import com.example.ELEC5619.Model.Book;
import com.example.ELEC5619.Repository.BookRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class BookDetailsService {

    private final BookRepository bookRepository;

    public BookDetailsService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    @Transactional(readOnly = true)
    public Optional<Book> getById(UUID bookId) {
        return bookRepository.findById(bookId);
    }

    @Transactional(readOnly = true)
    public Optional<Book> getByIsbn(String isbn) {
        if (isbn == null || isbn.isBlank()) return Optional.empty();
        return bookRepository.findByIsbn(isbn);
    }

    @Transactional(readOnly = true)
    public Optional<Book> getByExactTitle(String title) {
        if (title == null || title.isBlank()) return Optional.empty();
        return bookRepository.findFirstByTitleIgnoreCase(title);
    }

    @Transactional(readOnly = true)
    public Optional<Book> getByTitleContains(String titleLike) {
        if (titleLike == null || titleLike.isBlank()) return Optional.empty();
        List<Book> matches = bookRepository.findByTitleContainingIgnoreCase(titleLike);
        return matches.isEmpty() ? Optional.empty() : Optional.of(matches.get(0));
    }

    /** Priority: id → isbn → exact title → contains title. */
    @Transactional(readOnly = true)
    public Optional<Book> resolveOne(String id, String isbn, String title) {
        if (id != null && !id.isBlank()) {
            try {
                UUID uuid = UUID.fromString(id.trim());
                Optional<Book> byId = getById(uuid);
                if (byId.isPresent()) return byId;
            } catch (IllegalArgumentException ignored) { /* not a UUID */ }
        }
        Optional<Book> byIsbn = getByIsbn(isbn);
        if (byIsbn.isPresent()) return byIsbn;

        Optional<Book> byExact = getByExactTitle(title);
        if (byExact.isPresent()) return byExact;

        return getByTitleContains(title);
    }

    /* Placeholder until you add a Review entity/repo */
    @Transactional(readOnly = true)
    public List<Map<String, Object>> getReviewsForBook(UUID bookId) {
        return Collections.emptyList();
    }


    public List<Book> find5BySameGenre(String isbn) { return bookRepository.findTop5BySameGenre(isbn); }

    public List<Book> find5BySameAuthor(String isbn) { return bookRepository.findTop5BySameAuthor(isbn); }
}
