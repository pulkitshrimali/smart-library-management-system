package com.example.ELEC5619.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.example.ELEC5619.Model.Book;
import com.example.ELEC5619.Service.BookDetailsService;

@RestController
@RequestMapping("/bookdetails")
@CrossOrigin
public class BookDetailsController {

    private final BookDetailsService bookDetailsService;

    public BookDetailsController(BookDetailsService bookDetailsService) {
        this.bookDetailsService = bookDetailsService;
    }

    @GetMapping("/isbn/{isbn}")
    public Book getByIsbnPath(@PathVariable("isbn") String isbn) {
        System.out.println(bookDetailsService.getByIsbn(isbn));
        return bookDetailsService.getByIsbn(isbn)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Book not found"));
    }


    @GetMapping
    public Map<String, Object> resolveByIsbn(@RequestParam(value = "isbn") String isbn) {
        var opt = bookDetailsService.getByIsbn(isbn);
        var items = opt.<List<Book>>map(List::of).orElseGet(List::of);
        Map<String, Object> resp = new HashMap<>();
        resp.put("total", items.size());
        resp.put("items", items);
        return resp;
    }
    
    @GetMapping("/isbn/{isbn}/related")
public Map<String, Object> related(@PathVariable String isbn) {
    Map<String, Object> resp = new HashMap<>();
    resp.put("byGenre", bookDetailsService.find5BySameGenre(isbn));
    resp.put("byAuthor", bookDetailsService.find5BySameAuthor(isbn));
    return resp;
}


    /** Reviews by ISBN: GET /bookdetails/isbn/{isbn}/reviews */
    // @GetMapping("/isbn/{isbn}/reviews")
    // public List<Map<String, Object>> getReviewsByIsbn(@PathVariable("isbn") String isbn) {
    //     return bookDetailsService.getReviewsForIsbn(isbn);
    // }
}
