package com.example.ELEC5619.Controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.ELEC5619.Model.User;
import com.example.ELEC5619.Model.Waitlist;
import com.example.ELEC5619.Repository.BookRepository;
import com.example.ELEC5619.Repository.LibraryRepository;
import com.example.ELEC5619.Repository.UserRepository;
import com.example.ELEC5619.Service.EmailService;
import com.example.ELEC5619.Service.WaitlistService;

/**
 * REST controller for managing book waitlists in the library system
 * Handles operations for joining/leaving waitlists, checking status, and managing queue positions
 * Uses session-based authentication via userEmail cookie
 */
@RestController
@RequestMapping("/api/waitlist")
@CrossOrigin(origins = "*")
public class WaitlistController {

    private final WaitlistService waitlistService;
    private final UserRepository userRepository;
    private final LibraryRepository libraryRepository;
    private final BookRepository bookRepository;
    private final EmailService emailService;

    /**
     * Constructor for dependency injection of required services and repositories
     */
    public WaitlistController(WaitlistService waitlistService, UserRepository userRepository, 
                            LibraryRepository libraryRepository, BookRepository bookRepository, 
                            EmailService emailService) {
        this.waitlistService = waitlistService;
        this.userRepository = userRepository;
        this.libraryRepository = libraryRepository;
        this.bookRepository = bookRepository;
        this.emailService = emailService;
    }

    /**
     * Adds a user to the waitlist for a specific book
     * Sends email confirmation with queue position and notifies other users of position changes
     * 
     * @param request JSON body containing bookId
     * @param userEmail Users email from session cookie
     * @return Success response with position or error message
     */
    @PostMapping("/join")
    public ResponseEntity<?> joinWaitlist(@RequestBody Map<String, String> request,
                                        @CookieValue(value = "userEmail", required = false) String userEmail) {
        // Check if user is authenticated via session cookie
        if (userEmail == null) {
            return ResponseEntity.status(401).body(Map.of(
                "success", false,
                "message", "Not logged in"
            ));
        }

        try {
            // Find user by email from session
            User user = userRepository.findByEmailIgnoreCase(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
            
            UUID bookId = UUID.fromString(request.get("bookId"));
            // Get the first available library (assuming single library system)
            UUID libraryId = libraryRepository.findFirst()
                .map(library -> library.getLibraryId())
                .orElseThrow(() -> new RuntimeException("No library found"));

            // Add user to waitlist - position assigned by database trigger
            Waitlist waitlist = waitlistService.joinWaitlist(user.getUserId(), bookId, libraryId);

            // Send email notification asynchronously to get correct position after DB trigger executes
            new Thread(() -> {
                try {
                    Thread.sleep(100); // Brief delay for database trigger to assign position
                    
                    String bookTitle = bookRepository.findById(bookId)
                        .map(book -> book.getTitle())
                        .orElse("Unknown Book");
                    
                    // Get updated position from database after trigger execution
                    int position = waitlistService.getUserWaitlistEntry(user.getUserId(), bookId)
                        .map(w -> w.getPosition())
                        .orElse(1);
                    
                    // Send confirmation email with queue position
                    emailService.send(
                        userEmail,
                        "Waitlist Confirmation",
                        String.format("You have been added to the waitlist for '%s'. Your position is #%d.", 
                                    bookTitle, position)
                    );
                } catch (Exception e) {
                    System.err.println("Failed to send waitlist email: " + e.getMessage());
                }
            }).start();

            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Added to waitlist successfully!",
                "position", waitlist.getPosition()
            ));

        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    /**
     * Removes a user from the waitlist for a specific book
     * Automatically updates positions for remaining users and sends notifications
     * 
     * @param request JSON body containing bookId
     * @param userEmail Users email from session cookie
     * @return Success response or error message
     */
    @PostMapping("/leave")
    public ResponseEntity<?> leaveWaitlist(@RequestBody Map<String, String> request,
                                         @CookieValue(value = "userEmail", required = false) String userEmail) {
        // Check authentication
        if (userEmail == null) {
            return ResponseEntity.status(401).body(Map.of(
                "success", false,
                "message", "Not logged in"
            ));
        }

        try {
            User user = userRepository.findByEmailIgnoreCase(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
            
            UUID bookId = UUID.fromString(request.get("bookId"));
            
            // Get book details for email notifications
            String bookTitle = bookRepository.findById(bookId)
                .map(book -> book.getTitle())
                .orElse("Unknown Book");
            
            // Store leaving users position to determine who needs position updates
            int leavingPosition = waitlistService.getUserWaitlistEntry(user.getUserId(), bookId)
                .map(w -> w.getPosition())
                .orElse(0);
            
            // Remove user from waitlist - triggers position updates for remaining users
            waitlistService.leaveWaitlist(user.getUserId(), bookId);

            // Send confirmation email to user who left the waitlist
            try {
                emailService.send(
                    userEmail,
                    "Waitlist Removal Confirmation",
                    String.format("You have been removed from the waitlist for '%s'.", bookTitle)
                );
            } catch (Exception e) {
                System.err.println("Failed to send waitlist removal email: " + e.getMessage());
            }
            
            // Notify remaining users of their updated positions (asynchronous to avoid blocking)
            if (leavingPosition > 0) {
                new Thread(() -> {
                    try {
                        Thread.sleep(100); // Wait for database trigger to update positions
                        
                        // Get all users still on waitlist after position updates
                        List<Waitlist> updatedWaitlist = waitlistService.getBookWaitlist(bookId);
                        for (Waitlist w : updatedWaitlist) {
                            // Notify users whose positions were affected by the removal
                            if (w.getPosition() >= leavingPosition) {
                                User affectedUser = userRepository.findById(w.getUserId()).orElse(null);
                                if (affectedUser != null && affectedUser.getEmail() != null) {
                                    System.out.println("Sending position update to: " + affectedUser.getEmail() + 
                                                     " for position: " + w.getPosition());
                                    emailService.send(
                                        affectedUser.getEmail(),
                                        "Waitlist Position Update",
                                        String.format("Your position for '%s' has been updated to #%d.", 
                                                    bookTitle, w.getPosition())
                                    );
                                    Thread.sleep(25000); // Delay between emails to avoid spam
                                }
                            }
                        }
                    } catch (Exception e) {
                        System.err.println("Failed to send position update emails: " + e.getMessage());
                    }
                }).start();
            }

            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Removed from waitlist successfully!"
            ));

        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    /**
     * Gets waitlist status for a specific book, including total count and users position if logged in.
     * 
     * @param bookId UUID of the book to check
     * @param userEmail Optional user email from session cookie
     * @return Waitlist status with total count and user position (if applicable)
     */
    @GetMapping("/status/{bookId}")
    public ResponseEntity<Map<String, Object>> getWaitlistStatus(@PathVariable UUID bookId,
                                                               @CookieValue(value = "userEmail", required = false) String userEmail) {
        try {
            // Get total number of users waiting for this book
            Long totalWaiting = waitlistService.getWaitlistCount(bookId);
            
            // If user is logged in, check their specific position
            if (userEmail != null) {
                User user = userRepository.findByEmailIgnoreCase(userEmail).orElse(null);
                if (user != null) {
                    Optional<Waitlist> userEntry = waitlistService.getUserWaitlistEntry(user.getUserId(), bookId);
                    if (userEntry.isPresent()) {
                        return ResponseEntity.ok(Map.of(
                            "onWaitlist", true,
                            "position", userEntry.get().getPosition(),
                            "totalWaiting", totalWaiting
                        ));
                    }
                }
            }

            return ResponseEntity.ok(Map.of(
                "onWaitlist", false,
                "totalWaiting", totalWaiting
            ));

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "error", "Error checking waitlist status"
            ));
        }
    }

    @GetMapping("/user")
    public ResponseEntity<?> getUserWaitlist(@CookieValue(value = "userEmail", required = false) String userEmail) {
        if (userEmail == null) {
            return ResponseEntity.status(401).body(Map.of(
                "success", false,
                "message", "Not logged in"
            ));
        }

        try {
            User user = userRepository.findByEmailIgnoreCase(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
            
            List<Waitlist> waitlist = waitlistService.getUserWaitlistWithBooks(user.getUserId());
            return ResponseEntity.ok(waitlist);

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
}