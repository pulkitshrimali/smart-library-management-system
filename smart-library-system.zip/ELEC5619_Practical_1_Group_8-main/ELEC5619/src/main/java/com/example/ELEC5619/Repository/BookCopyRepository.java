package com.example.ELEC5619.Repository;

import com.example.ELEC5619.Model.BookCopy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface BookCopyRepository extends JpaRepository<BookCopy, UUID> {
    
    List<BookCopy> findByBookId(UUID bookId);
    
    @Query("SELECT bc FROM BookCopy bc WHERE bc.bookId = :bookId AND bc.status = 'AVAILABLE'")
    List<BookCopy> findAvailableCopiesByBookId(@Param("bookId") UUID bookId);
    
    @Query("SELECT bc FROM BookCopy bc WHERE bc.bookId = :bookId AND bc.status = 'AVAILABLE' ORDER BY bc.libraryId LIMIT 1")
    Optional<BookCopy> findFirstAvailableCopyByBookId(@Param("bookId") UUID bookId);
    
    @Modifying
    @Query(value = "UPDATE libraryhub.bookcopies SET status = CAST(:status AS libraryhub.copy_status) WHERE copy_id = :copyId", nativeQuery = true)
    void updateCopyStatusWithCast(@Param("copyId") UUID copyId, @Param("status") String status);
}