package com.example.ELEC5619.Model;

import jakarta.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "bookcopies")
public class BookCopy {
    
    @Id
    @GeneratedValue
    @Column(name = "copy_id")
    private UUID copyId;
    
    @Column(name = "library_id", nullable = false)
    private UUID libraryId;
    
    @Column(name = "book_id", nullable = false)
    private UUID bookId;
    
    @Column(nullable = false)
    private String status = "AVAILABLE";
    
    // Constructors
    public BookCopy() {}
    
    // Getters and Setters
    public UUID getCopyId() { return copyId; }
    public void setCopyId(UUID copyId) { this.copyId = copyId; }
    
    public UUID getLibraryId() { return libraryId; }
    public void setLibraryId(UUID libraryId) { this.libraryId = libraryId; }
    
    public UUID getBookId() { return bookId; }
    public void setBookId(UUID bookId) { this.bookId = bookId; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}