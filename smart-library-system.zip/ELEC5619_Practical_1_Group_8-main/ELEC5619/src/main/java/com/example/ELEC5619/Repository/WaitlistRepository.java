package com.example.ELEC5619.Repository;

import com.example.ELEC5619.Model.Waitlist;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface WaitlistRepository extends JpaRepository<Waitlist, UUID> {

    @Query("SELECT w FROM Waitlist w WHERE w.userId = :userId AND w.bookId = :bookId")
    Optional<Waitlist> findByUserIdAndBookId(@Param("userId") UUID userId, @Param("bookId") UUID bookId);

    @Query("SELECT w FROM Waitlist w WHERE w.bookId = :bookId ORDER BY w.position ASC")
    List<Waitlist> findByBookIdOrderByPosition(@Param("bookId") UUID bookId);

    @Query("SELECT w FROM Waitlist w WHERE w.userId = :userId ORDER BY w.position ASC")
    List<Waitlist> findByUserId(@Param("userId") UUID userId);

    @Query("SELECT w FROM Waitlist w WHERE w.bookId = :bookId AND w.position = 1")
    Optional<Waitlist> findFirstInQueue(@Param("bookId") UUID bookId);

    @Query("SELECT COUNT(w) FROM Waitlist w WHERE w.bookId = :bookId")
    Long countByBookId(@Param("bookId") UUID bookId);
}