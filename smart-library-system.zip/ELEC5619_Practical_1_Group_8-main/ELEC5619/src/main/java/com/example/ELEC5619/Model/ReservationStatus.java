package com.example.ELEC5619.Model;

public enum ReservationStatus {
    PENDING, CONFIRMED, CANCELLED, COMPLETED
}