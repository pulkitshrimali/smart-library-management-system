package com.example.ELEC5619.Repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.ELEC5619.Model.ReviewComment;
import com.example.ELEC5619.DTO.CommentWithUserDTO;

@Repository
public interface ReviewCommentRepository extends JpaRepository<ReviewComment, UUID> {
    List<ReviewComment> findByReviewIdOrderByCreatedAtAsc(UUID reviewId);
    List<ReviewComment> findByParentIdOrderByCreatedAtAsc(UUID parentId);
    
    @Query("SELECT new com.example.ELEC5619.DTO.CommentWithUserDTO(c.commentId, c.reviewId, c.userId, u.name, c.parentId, c.message, c.createdAt, c.updatedAt) " +
           "FROM ReviewComment c JOIN User u ON c.userId = u.userId " +
           "WHERE c.reviewId = :reviewId ORDER BY c.createdAt ASC")
    List<CommentWithUserDTO> findCommentsWithUserByReviewId(@Param("reviewId") UUID reviewId);
}