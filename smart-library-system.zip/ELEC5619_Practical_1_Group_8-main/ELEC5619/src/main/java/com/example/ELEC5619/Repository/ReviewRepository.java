package com.example.ELEC5619.Repository;

import com.example.ELEC5619.Model.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.UUID;

public interface ReviewRepository extends JpaRepository<Review, UUID> {
    List<Review> findByBookId(UUID bookId);
    List<Review> findByUserId(UUID userId);
    Review findByBookIdAndUserId(UUID bookId, UUID userId);
    
    @Query(value = "SELECT u.name FROM libraryhub.users u WHERE u.user_id = ?1", nativeQuery = true)
    String findUserNameById(UUID userId);
}