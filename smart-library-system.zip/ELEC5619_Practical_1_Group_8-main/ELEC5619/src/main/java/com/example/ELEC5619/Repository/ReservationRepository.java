package com.example.ELEC5619.Repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.ELEC5619.Model.Reservation;

@Repository
public interface ReservationRepository extends JpaRepository<Reservation, UUID> {
    
    List<Reservation> findByUserId(UUID userId);
    
    @Query("SELECT r FROM Reservation r WHERE r.userId = :userId AND r.status IN ('PENDING', 'CONFIRMED')")
    List<Reservation> findActiveReservationsByUserId(@Param("userId") UUID userId);
    
    @Query(value = """
        SELECT COUNT(*) > 0 FROM libraryhub.reservation r
        JOIN libraryhub.bookcopies bc ON r.copy_id = bc.copy_id
        WHERE r.user_id = :userId 
        AND bc.book_id = :bookId 
        AND r.status IN ('PENDING', 'CONFIRMED')
        """, nativeQuery = true)
    boolean hasActiveReservationForBook(@Param("userId") UUID userId, @Param("bookId") UUID bookId);
    
    @Query(value = """
        SELECT r.reservation_id, r.user_id, r.copy_id, r.start_date, r.end_date, r.status,
               b.title, b.isbn, b.cover_image_url, 
               EXTRACT(YEAR FROM b.publication_date) as publication_year,
               STRING_AGG(a.name, ', ') as author, r.reserved_at, r.hold_expiry, l.name as library_name
        FROM libraryhub.reservation r
        JOIN libraryhub.bookcopies bc ON r.copy_id = bc.copy_id
        JOIN libraryhub.books b ON bc.book_id = b.book_id
        JOIN libraryhub.libraries l ON bc.library_id = l.library_id
        LEFT JOIN libraryhub.bookauthors ba ON b.book_id = ba.book_id
        LEFT JOIN libraryhub.authors a ON ba.author_id = a.author_id
        WHERE r.user_id = :userId
        GROUP BY r.reservation_id, r.user_id, r.copy_id, r.start_date, r.end_date, r.status,
                 b.title, b.isbn, b.cover_image_url, b.publication_date, r.reserved_at, r.hold_expiry, l.name
        ORDER BY r.start_date DESC
        """, nativeQuery = true)
    List<Object[]> findReservationsWithBooksByUserId(@Param("userId") UUID userId);
    
    @Modifying
    @Query(value = """
        INSERT INTO libraryhub.reservation (reservation_id, user_id, copy_id, start_date, end_date, status, reserved_at, hold_expiry)
        VALUES (:reservationId, :userId, :copyId, :startDate, :endDate, CAST(:status AS libraryhub.reservation_status), :reservedAt, :holdExpiry)
        """, nativeQuery = true)
    void insertReservationWithCast(@Param("reservationId") UUID reservationId,
                                  @Param("userId") UUID userId,
                                  @Param("copyId") UUID copyId,
                                  @Param("startDate") java.time.LocalDate startDate,
                                  @Param("endDate") java.time.LocalDate endDate,
                                  @Param("status") String status,
                                  @Param("reservedAt") java.time.LocalDate reservedAt,
                                  @Param("holdExpiry") java.time.LocalDate holdExpiry);
    
    @Modifying
    @Query(value = "UPDATE libraryhub.reservation SET status = CAST(:status AS libraryhub.reservation_status) WHERE reservation_id = :reservationId", nativeQuery = true)
    void updateReservationStatusWithCast(@Param("reservationId") UUID reservationId, @Param("status") String status);
    
    @Query(value = """
        SELECT r.reservation_id, r.user_id, r.copy_id, r.start_date, r.end_date, r.status,
               b.title, b.isbn, b.cover_image_url, 
               EXTRACT(YEAR FROM b.publication_date) as publication_year,
               STRING_AGG(a.name, ', ') as author, r.reserved_at, r.hold_expiry, l.name as library_name, u.name as user_name
        FROM libraryhub.reservation r
        JOIN libraryhub.bookcopies bc ON r.copy_id = bc.copy_id
        JOIN libraryhub.books b ON bc.book_id = b.book_id
        JOIN libraryhub.libraries l ON bc.library_id = l.library_id
        JOIN libraryhub.users u ON r.user_id = u.user_id
        LEFT JOIN libraryhub.bookauthors ba ON b.book_id = ba.book_id
        LEFT JOIN libraryhub.authors a ON ba.author_id = a.author_id
        WHERE r.status = 'PENDING'
        GROUP BY r.reservation_id, r.user_id, r.copy_id, r.start_date, r.end_date, r.status,
                 b.title, b.isbn, b.cover_image_url, b.publication_date, r.reserved_at, r.hold_expiry, l.name, u.name
        ORDER BY r.reserved_at DESC
        """, nativeQuery = true)
    List<Object[]> findAllPendingPickups();
    
    @Query(value = """
        SELECT r.reservation_id, r.user_id, r.copy_id, r.start_date, r.end_date, r.status,
               b.title, b.isbn, b.cover_image_url, 
               EXTRACT(YEAR FROM b.publication_date) as publication_year,
               STRING_AGG(a.name, ', ') as author, r.reserved_at, r.hold_expiry, l.name as library_name, u.name as user_name
        FROM libraryhub.reservation r
        JOIN libraryhub.bookcopies bc ON r.copy_id = bc.copy_id
        JOIN libraryhub.books b ON bc.book_id = b.book_id
        JOIN libraryhub.libraries l ON bc.library_id = l.library_id
        JOIN libraryhub.users u ON r.user_id = u.user_id
        LEFT JOIN libraryhub.bookauthors ba ON b.book_id = ba.book_id
        LEFT JOIN libraryhub.authors a ON ba.author_id = a.author_id
        WHERE r.status = 'CONFIRMED'
        GROUP BY r.reservation_id, r.user_id, r.copy_id, r.start_date, r.end_date, r.status,
                 b.title, b.isbn, b.cover_image_url, b.publication_date, r.reserved_at, r.hold_expiry, l.name, u.name
        ORDER BY r.start_date DESC
        """, nativeQuery = true)
    List<Object[]> findAllCheckedOutBooks();
}