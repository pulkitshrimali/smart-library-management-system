package com.example.ELEC5619.Controller;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.ELEC5619.Model.Review;
import com.example.ELEC5619.Model.User;
import com.example.ELEC5619.Repository.UserRepository;
import com.example.ELEC5619.Service.ReviewService;

/**
 * REST controller for managing book reviews
 * Provides endpoints to create, read, update, and delete reviews.
 */
@RestController
@RequestMapping("/api/reviews")
@CrossOrigin(origins = "*")
public class ReviewController {
    private final ReviewService reviewService;
    private final UserRepository userRepository;

    public ReviewController(ReviewService reviewService, UserRepository userRepository) {
        this.reviewService = reviewService;
        this.userRepository = userRepository;
    }

    /**
     * Get all reviews for a specific book
     * @param bookId UUID of the book
     * @return list of reviews
     */
    @GetMapping("/book/{bookId}")
    public List<Review> getReviewsByBook(@PathVariable UUID bookId) {
        return reviewService.getReviewsByBook(bookId);
    }

    /**
     * Get a single review by its ID
     * @param reviewId UUID of the review
     * @return the review
     */
    @GetMapping("/{reviewId}")
    public Review getReviewById(@PathVariable UUID reviewId) {
        return reviewService.getReviewById(reviewId);
    }

    /**
     * Add a new review (requires authentication)
     * @param review Review object from request body
     * @param userEmail User's email from session cookie
     * @return created review or error response
     */
    @PostMapping
    public ResponseEntity<?> addReview(@RequestBody Review review, 
                                     @CookieValue(value = "userEmail", required = false) String userEmail) {
        if (userEmail == null) {
            return ResponseEntity.status(401).body(Map.of(
                "success", false,
                "message", "Not logged in"
            ));
        }
        
        try {
            User user = userRepository.findByEmailIgnoreCase(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
            
            review.setUserId(user.getUserId());
            Review savedReview = reviewService.addReview(review);
            
            return ResponseEntity.ok(savedReview);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    /**
     * Update an existing review by ID (only owner can update)
     * @param reviewId UUID of the review
     * @param review Review object with updated fields
     * @param userEmail User's email from session cookie
     * @return updated review or error response
     */
    @PutMapping("/{reviewId}")
    public ResponseEntity<?> updateReview(@PathVariable UUID reviewId, 
                                        @RequestBody Review review,
                                        @CookieValue(value = "userEmail", required = false) String userEmail) {
        if (userEmail == null) {
            return ResponseEntity.status(401).body(Map.of(
                "success", false,
                "message", "Not logged in"
            ));
        }
        
        try {
            User user = userRepository.findByEmailIgnoreCase(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
            
            Review updatedReview = reviewService.updateReview(reviewId, review, user.getUserId());
            
            return ResponseEntity.ok(updatedReview);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }

    /**
     * Delete a review by its ID (ADMIN ONLY)
     * @param reviewId UUID of the review
     * @param userEmail User's email from session cookie
     * @return success response or error message
     */
    @DeleteMapping("/{reviewId}")
    public ResponseEntity<?> deleteReview(@PathVariable UUID reviewId,
                                        @CookieValue(value = "userEmail", required = false) String userEmail) {
        if (userEmail == null) {
            return ResponseEntity.status(401).body(Map.of(
                "success", false,
                "message", "Not logged in"
            ));
        }
        
        try {
            User user = userRepository.findByEmailIgnoreCase(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
            
            // Only admins can delete reviews
            if (!"ADMIN".equals(user.getRole())) {
                return ResponseEntity.status(403).body(Map.of(
                    "success", false,
                    "message", "Only administrators can delete reviews"
                ));
            }
            
            reviewService.deleteReviewAsAdmin(reviewId);
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Review deleted successfully"
            ));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
}