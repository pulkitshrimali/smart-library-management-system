package com.example.ELEC5619.Controller;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.ELEC5619.Model.Reservation;
import com.example.ELEC5619.Model.ReservationWithBook;
import com.example.ELEC5619.Model.User;
import com.example.ELEC5619.Repository.UserRepository;
import com.example.ELEC5619.Service.ReservationService;

@RestController
@RequestMapping("/api/reservations")
@CrossOrigin(origins = "*")
public class ReservationController {
    
    private final ReservationService reservationService;
    private final UserRepository userRepository;
    
    public ReservationController(ReservationService reservationService, UserRepository userRepository) {
        this.reservationService = reservationService;
        this.userRepository = userRepository;
    }
    
    @PostMapping("/reserve")
    public ResponseEntity<?> reserveBook(@RequestBody Map<String, String> request,
                                       @CookieValue(value = "userEmail", required = false) String userEmail) {
        if (userEmail == null) {
            return ResponseEntity.status(401).body(Map.of(
                "success", false,
                "message", "Not logged in"
            ));
        }
        
        try {
            User user = userRepository.findByEmailIgnoreCase(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
            UUID bookId = UUID.fromString(request.get("bookId"));
            
            Reservation reservation = reservationService.createReservation(user.getUserId(), bookId, userEmail);
            
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Book reserved successfully!",
                "reservationId", reservation.getReservationId(),
                "endDate", reservation.getEndDate()
            ));
            
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", "Invalid request format"
            ));
        }
    }
    
    @GetMapping("/check-availability/{bookId}")
    public ResponseEntity<Map<String, Object>> checkAvailability(@PathVariable UUID bookId,
                                                               @CookieValue(value = "userEmail", required = false) String userEmail) {
        try {
            if (userEmail == null) {
                return ResponseEntity.ok(Map.of(
                    "canReserve", false,
                    "hasReservation", false,
                    "message", "Please log in to check availability"
                ));
            }
            
            User user = userRepository.findByEmailIgnoreCase(userEmail)
                .orElse(null);
            if (user == null) {
                return ResponseEntity.ok(Map.of(
                    "canReserve", false,
                    "hasReservation", false,
                    "message", "User not found"
                ));
            }
            
            boolean canReserve = reservationService.canReserveBook(user.getUserId(), bookId);
            boolean hasReservation = !canReserve && reservationService.hasActiveReservationForBook(user.getUserId(), bookId);
            
            String message;
            if (hasReservation) {
                message = "You have already reserved a copy of this book";
            } else if (canReserve) {
                message = "Available for reservation";
            } else {
                message = "No copies available - join waitlist";
            }
            
            return ResponseEntity.ok(Map.of(
                "canReserve", canReserve,
                "hasReservation", hasReservation,
                "message", message
            ));
            
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "canReserve", false,
                "hasReservation", false,
                "message", "Error checking availability"
            ));
        }
    }
    
    @GetMapping("/user")
    public ResponseEntity<?> getUserReservations(@CookieValue(value = "userEmail", required = false) String userEmail) {
        if (userEmail == null) {
            return ResponseEntity.status(401).body(Map.of(
                "success", false,
                "message", "Not logged in"
            ));
        }
        
        try {
            User user = userRepository.findByEmailIgnoreCase(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
            List<ReservationWithBook> reservations = reservationService.getUserReservationsWithBooks(user.getUserId());
            return ResponseEntity.ok(reservations);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    @PostMapping("/cancel/{reservationId}")
    public ResponseEntity<?> cancelReservation(@PathVariable UUID reservationId,
                                              @CookieValue(value = "userEmail", required = false) String userEmail) {
        if (userEmail == null) {
            return ResponseEntity.status(401).body(Map.of(
                "success", false,
                "message", "Not logged in"
            ));
        }
        
        try {
            User user = userRepository.findByEmailIgnoreCase(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
            reservationService.cancelReservation(reservationId, userEmail);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Reservation cancelled successfully"
            ));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    // Admin-only endpoints
    @GetMapping("/admin/pending-pickups")
    public ResponseEntity<?> getPendingPickups(@CookieValue(value = "userEmail", required = false) String userEmail) {
        if (userEmail == null) {
            return ResponseEntity.status(401).body(Map.of(
                "success", false,
                "message", "Not logged in"
            ));
        }
        
        try {
            User user = userRepository.findByEmailIgnoreCase(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
            
            if (!"ADMIN".equals(user.getRole())) {
                return ResponseEntity.status(403).body(Map.of(
                    "success", false,
                    "message", "Admin access required"
                ));
            }
            
            List<ReservationWithBook> pendingPickups = reservationService.getAllPendingPickups();
            return ResponseEntity.ok(pendingPickups);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    @GetMapping("/admin/checked-out")
    public ResponseEntity<?> getCheckedOutBooks(@CookieValue(value = "userEmail", required = false) String userEmail) {
        if (userEmail == null) {
            return ResponseEntity.status(401).body(Map.of(
                "success", false,
                "message", "Not logged in"
            ));
        }
        
        try {
            User user = userRepository.findByEmailIgnoreCase(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
            
            if (!"ADMIN".equals(user.getRole())) {
                return ResponseEntity.status(403).body(Map.of(
                    "success", false,
                    "message", "Admin access required"
                ));
            }
            
            List<ReservationWithBook> checkedOutBooks = reservationService.getAllCheckedOutBooks();
            return ResponseEntity.ok(checkedOutBooks);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    @PostMapping("/admin/mark-picked-up/{reservationId}")
    public ResponseEntity<?> markAsPickedUp(@PathVariable UUID reservationId,
                                           @CookieValue(value = "userEmail", required = false) String userEmail) {
        if (userEmail == null) {
            return ResponseEntity.status(401).body(Map.of(
                "success", false,
                "message", "Not logged in"
            ));
        }
        
        try {
            User user = userRepository.findByEmailIgnoreCase(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
            
            if (!"ADMIN".equals(user.getRole())) {
                return ResponseEntity.status(403).body(Map.of(
                    "success", false,
                    "message", "Admin access required"
                ));
            }
            
            reservationService.markAsPickedUp(reservationId);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Book marked as picked up"
            ));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    @PostMapping("/admin/mark-returned/{reservationId}")
    public ResponseEntity<?> markAsReturned(@PathVariable UUID reservationId,
                                           @CookieValue(value = "userEmail", required = false) String userEmail) {
        if (userEmail == null) {
            return ResponseEntity.status(401).body(Map.of(
                "success", false,
                "message", "Not logged in"
            ));
        }
        
        try {
            User user = userRepository.findByEmailIgnoreCase(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
            
            if (!"ADMIN".equals(user.getRole())) {
                return ResponseEntity.status(403).body(Map.of(
                    "success", false,
                    "message", "Admin access required"
                ));
            }
            
            reservationService.markAsReturned(reservationId);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Book marked as returned"
            ));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
}