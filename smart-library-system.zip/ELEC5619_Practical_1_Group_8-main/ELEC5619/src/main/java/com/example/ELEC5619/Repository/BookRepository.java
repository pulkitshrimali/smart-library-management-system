package com.example.ELEC5619.Repository;

import com.example.ELEC5619.Model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Modifying;     
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import java.util.Optional;  


@Repository
public interface BookRepository extends JpaRepository<Book, UUID> {

    @Query(value = """
        SELECT DISTINCT b.* 
        FROM libraryhub.books b
        LEFT JOIN libraryhub.bookauthors ba ON b.book_id = ba.book_id
        LEFT JOIN libraryhub.authors a ON a.author_id = ba.author_id
        LEFT JOIN libraryhub.genre g ON g.genre_id = b.genre_id
        LEFT JOIN libraryhub.bookcopies bc ON bc.book_id = b.book_id
        LEFT JOIN libraryhub.libraries l ON l.library_id = bc.library_id
        WHERE (:searchPattern IS NULL
            OR LOWER(b.title) LIKE :searchPattern
            OR b.isbn LIKE :searchPattern
            OR LOWER(a.name) LIKE :searchPattern
            OR LOWER(g.name) LIKE :searchPattern)
        AND (:availability IS NULL
            OR (:availability = 'available' AND b.available_copies > 0)
            OR (:availability = 'checked' AND b.available_copies = 0))
        AND (:genre IS NULL OR LOWER(g.name) = LOWER(:genre))
        AND (:library IS NULL OR l.library_id::text = :library)
        AND b.publication_date >= COALESCE(:startDate, DATE '1000-01-01')
        AND b.publication_date <= COALESCE(:endDate, DATE '9999-12-31')
    """, nativeQuery = true)
    List<Book> searchBooks(
            @Param("searchPattern") String searchPattern,
            @Param("availability") String availability,
            @Param("genre") String genre,
            @Param("library") String library,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate
    );

    Optional<Book> findByIsbn(String isbn);

    Optional<Book> findFirstByTitleIgnoreCase(String title);

    List<Book> findByTitleContainingIgnoreCase(String title);

    @Query(value = """
        SELECT b.*
        FROM libraryhub.books b
        WHERE b.genre_id = (
            SELECT genre_id FROM libraryhub.books WHERE isbn = :isbn
        )
        AND b.book_id <> (
            SELECT book_id FROM libraryhub.books WHERE isbn = :isbn
        )
        ORDER BY b.publication_date DESC NULLS LAST
        LIMIT 5
    """, nativeQuery = true)
    List<Book> findTop5BySameGenre(@Param("isbn") String isbn);

    @Query(value = """
        SELECT DISTINCT b.*
        FROM libraryhub.books b
        JOIN libraryhub.bookauthors ba ON ba.book_id = b.book_id
        WHERE ba.author_id IN (
            SELECT ba2.author_id
            FROM libraryhub.bookauthors ba2
            JOIN libraryhub.books bx ON bx.book_id = ba2.book_id
            WHERE bx.isbn = :isbn
        )
        AND b.book_id <> (
            SELECT book_id FROM libraryhub.books WHERE isbn = :isbn
        )
        ORDER BY b.publication_date DESC NULLS LAST
        LIMIT 5
    """, nativeQuery = true)
    List<Book> findTop5BySameAuthor(@Param("isbn") String isbn);

    @Query(value = """
        SELECT b.*
        FROM libraryhub.books b
        ORDER BY random()
        LIMIT 1
    """, nativeQuery = true)
    Optional<Book> findRandomBook();


    @Modifying(clearAutomatically = true, flushAutomatically = true)
@Query(value = "DELETE FROM libraryhub.bookauthors WHERE book_id = :bookId", nativeQuery = true)
void deleteBookAuthorLinks(@Param("bookId") java.util.UUID bookId);


    @Query(value = "UPDATE libraryhub.books SET available_copies = available_copies - 1 WHERE book_id = :bookId AND available_copies > 0", nativeQuery = true)
    @org.springframework.data.jpa.repository.Modifying
    @org.springframework.transaction.annotation.Transactional
    void decrementAvailableCopies(@Param("bookId") UUID bookId);

    @Query(value = "UPDATE libraryhub.books SET available_copies = available_copies + 1 WHERE book_id = :bookId", nativeQuery = true)
    @org.springframework.data.jpa.repository.Modifying
    @org.springframework.transaction.annotation.Transactional
    void incrementAvailableCopies(@Param("bookId") UUID bookId);


}
