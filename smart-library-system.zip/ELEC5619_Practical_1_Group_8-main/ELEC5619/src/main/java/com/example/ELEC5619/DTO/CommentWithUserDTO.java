package com.example.ELEC5619.DTO;

import java.time.LocalDateTime;
import java.util.UUID;

public class CommentWithUserDTO {
    private UUID commentId;
    private UUID reviewId;
    private UUID userId;
    private String userName;
    private UUID parentId;
    private String message;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public CommentWithUserDTO(UUID commentId, UUID reviewId, UUID userId, String userName, 
                             UUID parentId, String message, LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.commentId = commentId;
        this.reviewId = reviewId;
        this.userId = userId;
        this.userName = userName;
        this.parentId = parentId;
        this.message = message;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    // Getters and setters
    public UUID getCommentId() { return commentId; }
    public void setCommentId(UUID commentId) { this.commentId = commentId; }
    
    public UUID getReviewId() { return reviewId; }
    public void setReviewId(UUID reviewId) { this.reviewId = reviewId; }
    
    public UUID getUserId() { return userId; }
    public void setUserId(UUID userId) { this.userId = userId; }
    
    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }
    
    public UUID getParentId() { return parentId; }
    public void setParentId(UUID parentId) { this.parentId = parentId; }
    
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}