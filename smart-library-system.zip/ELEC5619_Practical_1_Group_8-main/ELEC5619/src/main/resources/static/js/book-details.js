// // Checkout button animation
// document.querySelector('.checkout-btn').addEventListener('click', function() {
//     this.style.transform = 'scale(0.95)';
//     this.textContent = '✅ Added to Cart';
//     this.style.background = '#A3B18A';
//     setTimeout(() => { this.style.transform = 'scale(1)'; }, 150);
// });

// // Write review button animation
// document.querySelector('.write-review-btn').addEventListener('click', function() {
//     this.style.transform = 'scale(0.95)';
//     setTimeout(() => { this.style.transform = 'scale(1)'; }, 150);
// });

// // Optional: add hover effect dynamically to review cards
// document.querySelectorAll('.review-card').forEach(card => {
//     card.addEventListener('mouseenter', () => card.style.transform = 'translateY(-3px)');
//     card.addEventListener('mouseleave', () => card.style.transform = 'translateY(0)');
// });
