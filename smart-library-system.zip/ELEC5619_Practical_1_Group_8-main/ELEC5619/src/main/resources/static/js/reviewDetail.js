class ReviewDetailManager {
  constructor() {
    this.reviewId = null;
    this.currentUser = null;
    this.init();
  }

  async init() {
    this.getReviewIdFromUrl();
    await this.checkUserSession();
    this.setupEventListeners();
    this.loadReviewDetail();
    this.loadComments();
  }

  getReviewIdFromUrl() {
    const params = new URLSearchParams(window.location.search);
    this.reviewId = params.get('id');
  }

  async checkUserSession() {
    try {
      const response = await fetch('/auth/me');
      if (response.ok) {
        const data = await response.json();
        if (data.status === 'ok') {
          this.currentUser = data.user;
        }
      }
    } catch (error) {
      console.log('User not logged in');
    }
  }

  setupEventListeners() {
    document.getElementById('submitComment')?.addEventListener('click', () => {
      this.submitComment();
    });
  }

  async loadReviewDetail() {
    if (!this.reviewId) {
      document.getElementById('reviewText').textContent = 'Review not found';
      return;
    }

    try {
      const response = await fetch(`/api/reviews/${this.reviewId}`);
      if (!response.ok) throw new Error('Failed to load review');
      
      const review = await response.json();
      this.displayReview(review);
    } catch (error) {
      console.error('Error loading review:', error);
      document.getElementById('reviewText').textContent = 'Error loading review';
    }
  }

  displayReview(review) {
    document.getElementById('reviewerName').textContent = review.userName || 'Unknown User';
    document.getElementById('reviewRating').innerHTML = '★'.repeat(review.rating) + '☆'.repeat(5 - review.rating);
    document.getElementById('reviewDate').textContent = new Date(review.createdAt).toLocaleDateString();
    document.getElementById('reviewText').textContent = review.reviewText || 'No comment provided.';
  }



  async loadComments() {
    try {
      const response = await fetch(`/api/reviews/${this.reviewId}/comments`);
      if (!response.ok) throw new Error('Failed to load comments');
      
      const comments = await response.json();
      this.displayComments(comments);
    } catch (error) {
      console.error('Error loading comments:', error);
    }
  }

  displayComments(comments) {
    const commentsList = document.getElementById('commentsList');
    
    if (comments.length === 0) {
      commentsList.innerHTML = '<div class="no-comments">No comments yet. Be the first to comment!</div>';
      return;
    }

    // Build comment tree
    const commentTree = this.buildCommentTree(comments);
    const commentsHtml = this.renderCommentTree(commentTree);
    commentsList.innerHTML = commentsHtml;
  }

  buildCommentTree(comments) {
    const commentMap = new Map();
    const rootComments = [];

    // Create map of all comments
    comments.forEach(comment => {
      comment.replies = [];
      commentMap.set(comment.commentId, comment);
    });

    // Build tree structure
    comments.forEach(comment => {
      if (comment.parentId) {
        const parent = commentMap.get(comment.parentId);
        if (parent) {
          parent.replies.push(comment);
        }
      } else {
        rootComments.push(comment);
      }
    });

    return rootComments;
  }

  renderCommentTree(comments, depth = 0) {
    return comments.map(comment => {
      const marginLeft = depth * 20;
      const repliesHtml = comment.replies.length > 0 ? this.renderCommentTree(comment.replies, depth + 1) : '';
      
      return `
        <div class="comment" data-comment-id="${comment.commentId}" style="margin-left: ${marginLeft}px;">
          <div class="comment-author">${comment.userName || 'Unknown User'}</div>
          <div class="comment-text">${this.escapeHtml(comment.message)}</div>
          <div class="comment-date">${new Date(comment.createdAt).toLocaleDateString()}</div>
          <button class="reply-btn" onclick="reviewManager.showReplyForm('${comment.commentId}')">Reply</button>
          <div id="reply-form-${comment.commentId}" class="reply-form" style="display: none;">
            <textarea placeholder="Write a reply..." rows="2"></textarea>
            <div class="reply-actions">
              <button onclick="reviewManager.submitReply('${comment.commentId}', this)">Post Reply</button>
              <button onclick="reviewManager.cancelReply('${comment.commentId}')">Cancel</button>
            </div>
          </div>
        </div>
        ${repliesHtml}
      `;
    }).join('');
  }

  async submitComment(parentId = null) {
    if (!this.currentUser) {
      alert('Please log in to comment');
      window.location.href = '/Login.html';
      return;
    }

    const commentText = document.getElementById('commentText').value.trim();
    
    if (!commentText) {
      alert('Please enter a comment');
      return;
    }

    try {
      const commentData = {
        message: commentText,
        parentId: parentId
      };

      const response = await fetch(`/api/reviews/${this.reviewId}/comments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(commentData)
      });

      if (response.ok) {
        document.getElementById('commentText').value = '';
        await this.loadComments();
      } else {
        throw new Error('Failed to submit comment');
      }
    } catch (error) {
      console.error('Error submitting comment:', error);
      alert('Failed to submit comment. Please try again.');
    }
  }

  showReplyForm(parentId) {
    // Hide all other reply forms
    document.querySelectorAll('.reply-form').forEach(form => {
      form.style.display = 'none';
    });
    
    // Show this reply form
    const replyForm = document.getElementById(`reply-form-${parentId}`);
    if (replyForm) {
      replyForm.style.display = 'block';
      replyForm.querySelector('textarea').focus();
    }
  }

  cancelReply(parentId) {
    const replyForm = document.getElementById(`reply-form-${parentId}`);
    if (replyForm) {
      replyForm.style.display = 'none';
      replyForm.querySelector('textarea').value = '';
    }
  }

  async submitReply(parentId, buttonElement) {
    if (!this.currentUser) {
      alert('Please log in to reply');
      window.location.href = '/Login.html';
      return;
    }

    const replyForm = document.getElementById(`reply-form-${parentId}`);
    const textarea = replyForm.querySelector('textarea');
    const message = textarea.value.trim();
    
    if (!message) {
      alert('Please enter a reply');
      return;
    }

    try {
      const replyData = {
        message: message,
        parentId: parentId
      };

      buttonElement.disabled = true;
      buttonElement.textContent = 'Posting...';

      const response = await fetch(`/api/reviews/${this.reviewId}/comments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(replyData)
      });

      if (response.ok) {
        textarea.value = '';
        replyForm.style.display = 'none';
        await this.loadComments();
      } else {
        throw new Error('Failed to submit reply');
      }
    } catch (error) {
      console.error('Error submitting reply:', error);
      alert('Failed to submit reply. Please try again.');
    } finally {
      buttonElement.disabled = false;
      buttonElement.textContent = 'Post Reply';
    }
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}

// Initialize when DOM is ready
let reviewManager;
document.addEventListener('DOMContentLoaded', () => {
  console.log('DOM loaded, initializing ReviewDetailManager...');
  reviewManager = new ReviewDetailManager();
  console.log('ReviewDetailManager initialized:', reviewManager);
});