document.getElementById('forgotBtn').addEventListener('click', forgot)

async function forgot() {
    const emailInput = document.getElementById('femail');
    const errEmail = document.getElementById("errfemail");

    const email = (emailInput.value || '').trim();

    let ok = true;

    // --- Email validation ---
    if (!/^\S+@\S+\.\S+$/.test(email)) {
       if (errEmail) errEmail.textContent = 'Please enter a valid email.';
       return;
    } else {
       if (errEmail) errEmail.textContent = '';
    }

    if (!ok) return;

    try {
        const response = await fetch('/auth/forgot', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email })
        });

        const data = await response.json();
        // Always show a generic success to prevent email enumeration
        openDialog({
          message: 'If the account exists, we will send a reset link. Please check your inbox.',
          type: 'success',
          autoCloseMs: 3000,
          redirect: 'Login.html'
        });
   } catch (err) {
    console.error('Network or server error:', err);
   }
}
