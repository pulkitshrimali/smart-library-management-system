document.getElementById("resetBtn").addEventListener("click", reset);

async function reset() {
    const passwordInput = document.getElementById("npw");
    const confirmPassword = document.getElementById("ncpw");
    const errPassword = document.getElementById("errrnpw");
    const errConfirmPassword = document.getElementById("errrncpw");

    const password = passwordInput.value.trim();
    const confirm = confirmPassword.value.trim();

    // clear old errors
    errPassword.textContent = "";
    errConfirmPassword.textContent = "";

    let ok = true;

    // --- Password validation ---
    // must be at least 12 characters, contain at least one number and one symbol
    const hasNumber = /\d/.test(password);
    const hasSymbol = /[^A-Za-z0-9]/.test(password);

    if (!password) {
    errPassword.textContent = "Password is required.";
    ok = false;
    } else if (password.length < 12) {
    errPassword.textContent = "Use at least 12 characters with numbers & symbols.";
    ok = false;
    } else if (!hasNumber || !hasSymbol) {
    errPassword.textContent = "Password must include at least one number and one symbol.";
    ok = false;
    }

    // Check if they match
    if (password !== confirm) {
    errConfirmPassword.textContent = "Passwords do not match.";
    ok = false;
    }

    if (!ok) return;

    // Read token from URL
    const token = new URLSearchParams(location.search).get("token");
    if (!token) {
    openDialog({
      message: "Reset link missing or expired. Please request a new one.",
      type: "error",
      autoCloseMs: 1000,
      redirect: "Login.html"
    });
    return;
    }

    // Send to backend
    try {
    const res = await fetch("/auth/reset", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token, newPassword: password })
    });

    const data = await res.json();

    if (res.ok && data.status === "ok") {
      openDialog({
        message: "Your password has been updated. You can now log in.",
        type: "success",
        autoCloseMs: 2500,
        redirect: "Login.html"
      });
    } else {
      openDialog({
        message: data.message || "Could not reset password. Please try again.",
        type: "error",
        autoCloseMs: 900
      });
    }
    } catch (err) {
    console.error("Network or server error:", err);
    }
}

function toggle(btn, id) {
  const el = document.getElementById(id);

  if (el.type === "password") {
    el.type = "text";
    btn.textContent = "🙈";  // hide icon
  } else {
    el.type = "password";
    btn.textContent = "👁";    // show icon
  }
}