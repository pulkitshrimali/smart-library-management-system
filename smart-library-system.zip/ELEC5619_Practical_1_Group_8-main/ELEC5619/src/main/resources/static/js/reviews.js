class ReviewManager {
  constructor() {
    this.currentIsbn = null;
    this.currentBookId = null;
    this.selectedRating = 0;
    this.currentUser = null;
    this.init();
  }

  async init() {
    await this.checkUserSession();
    this.setupEventListeners();
    this.loadReviews();
  }

  async checkUserSession() {
    try {
      const response = await fetch('/auth/me');
      if (response.ok) {
        const data = await response.json();
        if (data.status === 'ok') {
          this.currentUser = data.user;
        }
      }
    } catch (error) {
      console.log('User not logged in');
    }
  }

  setupEventListeners() {
    // Star rating selection
    document.querySelectorAll('#starRating span').forEach(star => {
      star.addEventListener('click', (e) => {
        this.selectedRating = parseInt(e.target.dataset.value);
        this.updateStarDisplay();
      });
    });

    // Submit review
    document.getElementById('submitReview')?.addEventListener('click', () => {
      this.submitReview();
    });

    // Cancel review
    document.querySelector('.cancel')?.addEventListener('click', () => {
      this.clearForm();
    });

    // Toggle review form
    document.querySelector('.write-review-btn')?.addEventListener('click', () => {
      this.toggleReviewForm();
    });
  }

  updateStarDisplay() {
    document.querySelectorAll('#starRating span').forEach((star, index) => {
      star.style.color = index < this.selectedRating ? '#588157' : '#ccc';
    });
  }

  toggleReviewForm() {
    const form = document.querySelector('.review-form');
    form.style.display = form.style.display === 'none' ? 'block' : 'none';
  }

  async loadReviews() {
    const params = new URLSearchParams(location.search);
    this.currentIsbn = params.get('isbn');
    
    console.log('Loading reviews for ISBN:', this.currentIsbn);
    
    if (!this.currentIsbn) {
      console.log('No ISBN found in URL');
      return;
    }

    try {
      // First get book data to extract bookId
      console.log('Fetching book data...');
      const bookResponse = await fetch(`/bookdetails/isbn/${encodeURIComponent(this.currentIsbn)}`);
      if (!bookResponse.ok) throw new Error('Failed to fetch book data');
      
      const book = await bookResponse.json();
      console.log('Book data:', book);
      this.currentBookId = book.bookId;
      
      if (!this.currentBookId) {
        console.log('No bookId found in book data');
        return;
      }

      // Now load reviews using bookId
      console.log('Fetching reviews for bookId:', this.currentBookId);
      const response = await fetch(`/api/reviews/book/${this.currentBookId}`);
      if (!response.ok) throw new Error('Failed to load reviews');
      
      const reviews = await response.json();
      console.log('Reviews loaded:', reviews);
      this.displayReviews(reviews);
    } catch (error) {
      console.error('Error loading reviews:', error);
      const container = document.querySelector('.reviews-container');
      if (container) {
        container.innerHTML = '<p class="no-reviews">Error loading reviews. Please try again.</p>';
      }
    }
  }

  displayReviews(reviews) {
    const container = document.querySelector('.reviews-container');
    const viewMoreContainer = document.getElementById('viewMoreReviews');
    if (!container) return;

    if (reviews.length === 0) {
      container.innerHTML = '<p class="no-reviews">No reviews yet. Be the first to review!</p>';
      if (viewMoreContainer) viewMoreContainer.style.display = 'none';
      return;
    }

    // Show only first 2 reviews
    const reviewsToShow = reviews.slice(0, 2);
    
    container.innerHTML = reviewsToShow.map(review => `
      <div class="review-card" onclick="window.location.href='Review.html?id=${review.reviewId}'" style="cursor: pointer;">
        <div class="reviewer-header">
          <div class="reviewer-name">${review.userName || 'Unknown User'}</div>
          <div class="review-stars">${'★'.repeat(review.rating)}${'☆'.repeat(5 - review.rating)}</div>
        </div>
        <div class="review-text">${this.escapeHtml(review.reviewText || 'No comment provided.')}</div>
        <div class="review-date">${new Date(review.createdAt).toLocaleDateString()}</div>
      </div>
    `).join('');

    // Show "View All Reviews" link if there's at least 1 review
    const debugInfo = document.getElementById('debugInfo');
    if (viewMoreContainer) {
      if (reviews.length >= 1) {
        viewMoreContainer.style.display = 'block';
        if (debugInfo) debugInfo.textContent = `Debug: Showing link (${reviews.length} reviews found)`;
      } else {
        viewMoreContainer.style.display = 'none';
        if (debugInfo) debugInfo.textContent = `Debug: Hiding link (no reviews found)`;
      }
    } else {
      if (debugInfo) debugInfo.textContent = 'Debug: viewMoreContainer not found';
    }
  }

  async submitReview() {
    if (!this.currentUser) {
      alert('Please log in to submit a review');
      window.location.href = '/Login.html';
      return;
    }

    if (!this.currentBookId) {
      alert('Book ID not found');
      return;
    }

    if (this.selectedRating === 0) {
      alert('Please select a rating');
      return;
    }

    const reviewText = document.getElementById('reviewText').value.trim();

    const reviewData = {
      bookId: this.currentBookId,
      rating: this.selectedRating,
      reviewText: reviewText
    };

    try {
      const response = await fetch('/api/reviews', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(reviewData)
      });

      const result = await response.json();
      
      if (response.ok) {
        // Reload reviews and clear form
        await this.loadReviews();
        this.clearForm();
        this.toggleReviewForm();
        
        alert('Review submitted successfully!');
      } else {
        throw new Error(result.message || 'Failed to submit review');
      }
    } catch (error) {
      console.error('Error submitting review:', error);
      alert('Failed to submit review. Please try again.');
    }
  }

  clearForm() {
    document.getElementById('reviewText').value = '';
    this.selectedRating = 0;
    this.updateStarDisplay();
  }



  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}

// Global function for view all reviews link
function viewAllReviews() {
  const params = new URLSearchParams(location.search);
  const isbn = params.get('isbn');
  if (isbn) {
    window.location.href = `all-reviews.html?isbn=${encodeURIComponent(isbn)}`;
  }
}

// Initialise when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  new ReviewManager();
});