document.getElementById("loginBtn").addEventListener("click", login);

async function login() {
  const emailInput = document.getElementById("lemail");
  const passwordInput = document.getElementById("lpw");
  const errEmail = document.getElementById("errlemail");
  const errPassword = document.getElementById("errlpw");

  errPassword.textContent = "";

  let ok = true;

  // Email validation
  if (!emailInput.value.trim() || !/^\S+@\S+\.\S+$/.test(emailInput.value)) {
    errEmail.textContent = "Please enter a valid email.";
    ok = false;
  } else {
    errEmail.textContent = "";
  }

  if (!ok) return;

  try {
    const res = await fetch("/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: emailInput.value.trim(),
        password: passwordInput.value,
      }),
    });

    const data = await res.json();

    if (data.status === "ok") {
      const roleRaw = (data.role || data.user?.role || "user").toString().toLowerCase();
      const role = roleRaw.includes("admin") ? "admin" : "user";
      const userPayload = data.user || { name: data.name || "User", email: emailInput.value.trim() };
      try {
        localStorage.setItem("lh.role", role);
        localStorage.setItem("lh.user", JSON.stringify({
          name: userPayload.name || "User",
          email: userPayload.email || emailInput.value.trim()
        }));
      } catch (storageError) {
        console.warn("Unable to persist login state", storageError);
      }

      openDialog({
        type: "success",
        message: "Welcome back!!!!!",
        showOk: false,
        redirect: "GlobalSearch.html",
        autoCloseMs: 2000
      });
    } else {
      openDialog({
        type: "error",
        message: "Your account or password is not correct!!! ",
        showOk: true,          // now will actually show
        redirect: null,
        // Consider removing autoCloseMs here if you want the user to read it:
        // autoCloseMs: 2000
      });
    }
  } catch (error) {           // FIX: name matches the variable we log
    console.error("Network or server error:", error);
    openDialog({
      type: "error",
      message: "Network error. Please try again.",
      showOk: true
    });
  }
}

function toggle(btn, id) {
  const el = document.getElementById(id);
  if (el.type === "password") {
    el.type = "text";
    btn.textContent = "🙈";
  } else {
    el.type = "password";
    btn.textContent = "👁";
  }
}