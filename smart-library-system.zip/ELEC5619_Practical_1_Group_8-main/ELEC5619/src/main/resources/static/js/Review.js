document.addEventListener("DOMContentLoaded", () => {
    const stars = document.querySelectorAll("#starRating span");
    let selectedRating = 0;
  
    // Star Rating Interaction
    stars.forEach(star => {
      star.addEventListener("click", () => {
        selectedRating = star.getAttribute("data-value");
        stars.forEach(s => s.classList.remove("selected"));
        for (let i = 0; i < selectedRating; i++) {
          stars[i].classList.add("selected");
        }
      });
    });
  
    // Submit Review
    document.getElementById("submitReview").addEventListener("click", () => {
      const reviewText = document.getElementById("reviewText").value;
      if (!selectedRating || !reviewText.trim()) {
        alert("Please provide a rating and write a review.");
        return;
      }
      alert(`Review submitted!\nRating: ${selectedRating} stars\nReview: ${reviewText}`);
    });
  
    // Like/Dislike Buttons
    document.querySelectorAll(".like").forEach(button => {
      button.addEventListener("click", () => {
        alert("You liked this review!");
      });
    });
  
    document.querySelectorAll(".dislike").forEach(button => {
      button.addEventListener("click", () => {
        alert("You disliked this review!");
      });
    });
  });
  