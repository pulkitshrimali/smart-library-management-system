/* -------------------------------------------
 * Profile page – wired to backend like global search
 * ------------------------------------------- */

/** Optional: set in HTML before this script if you need a different host
 *   <script>window.API_BASE_URL = "http://localhost:8080";</script>
 */
const BASE = (typeof window.API_BASE_URL === "string" && window.API_BASE_URL) || "";

/* ---------- Small API helper (like services.js) ---------- */
async function api(path, { method = "GET", headers, body } = {}) {
  const res = await fetch(`${BASE}${path}`, {
    method,
    credentials: "include",
    headers: {
      ...(body ? { "Content-Type": "application/json" } : {}),
      ...(headers || {})
    },
    body: body ? JSON.stringify(body) : undefined
  });

  // Try to parse JSON even on non-200 for better error messages
  let data;
  try {
    data = await res.json();
  } catch {
    data = null;
  }

  return { ok: res.ok, status: res.status, data };
}

/* ---------- DOM cache ---------- */
const els = {
  // navbar
  user: document.getElementById("user"),
  userabbr: document.getElementById("userabbr"),

  // profile card
  profileUser: document.getElementById("profileUser"),
  profileUserabbr: document.getElementById("profileUserabbr"),
  profileEmail: document.getElementById("profileEmail"),
  profileBirth: document.getElementById("profileBirth"),
  profilePhone: document.getElementById("profilePhone"),
  profileUserId: document.getElementById("profileUserId"),
  profileResetBtn: document.getElementById("profileResetBtn"),

  // sections that might show messages
  borrowedList: document.querySelector(".section ul.book-list"),  // first "Borrowed Books"
  historyList: document.querySelectorAll(".section ul.book-list")[1], // second "Reservation History"

  // optional error outlet (add <div id="profile-error"></div> if you want)
  err: document.getElementById("profile-error"),
};

/* ---------- Page state ---------- */
const state = {
  me: null,       // {status:"ok", user:{...}}
  profile: null,  // normalized profile object
  loading: false,
  error: null
};

/* ---------- Helpers ---------- */
function setText(node, v) {
  if (!node) return;
  node.textContent = v ?? "";
}

function getInitials(name) {
  if (!name || !name.trim()) return "??";
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0][0].toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

function parseNotificationPrefs(str) {
  // backend stores as a JSON string sometimes
  try {
    if (!str) return {};
    if (typeof str === "object") return str;
    return JSON.parse(str);
  } catch {
    return {};
  }
}

/* ---------- Backend calls ---------- */
async function checkAuth() {
  const { ok, data, status } = await api("/auth/me");
  if (!ok) {
    // not authenticated – bounce to login
    window.location.href = "/login.html";
    return null;
  }
  return data || null;
}

async function getProfileByEmail(email) {
  // GET /profile?email=...
  const { ok, data, status } = await api(`/profile?email=${encodeURIComponent(email)}`);
  if (!ok) {
    const msg =
      status === 404 ? "User not found" : (data && (data.message || data.error)) || "Failed to load profile";
    throw new Error(msg);
  }
  return data; // your controller returns a Map – normalize below
}

/* ---------- Render ---------- */
function renderError(message) {
  state.error = message;
  if (els.err) setText(els.err, message);
}

function renderProfile() {
  const p = state.profile || {};
  const name = p.name || "";
  const abbr = getInitials(name);

  // Navbar
  setText(els.user, name);
  setText(els.userabbr, abbr);

  // Profile card
  setText(els.profileUser, name);
  setText(els.profileUserabbr, abbr);
  setText(els.profileEmail, p.email || "");
  setText(els.profileBirth, p.birthDate || "");
  setText(els.profilePhone, p.phone || "");
  setText(els.profileUserId, p.userId || "");
}

/* ---------- Init flow ---------- */
async function init() {
  try {
    state.loading = true;

    // 1) who am I?
    const me = await checkAuth();
    if (!me) return; // redirected already if unauthenticated

    state.me = me;
    const email = me?.user?.email || me?.email;
    const nameFromAuth = me?.user?.name || me?.name;

    // 2) get profile by email
    const raw = await getProfileByEmail(email);

    // Your controller returns:
    //  return ResponseEntity.ok(Map.of("name", u.getName(), "email", u.getEmail(), "birthDate", u.getBirthDate(), "phone", "...", "role", u.getRole()))
    // OR if someone wrapped it already, sometimes {user:{...}}
    const payload = raw.user || raw;

    const normalized = {
      userId: payload.userId || payload.id || "", // fill if you have it
      name: payload.name || nameFromAuth || "",
      email: payload.email || email || "",
      birthDate: payload.birthDate || "", // yyyy-mm-dd
      phone: payload.phone || "",
      role: payload.role || "",
      notificationPreferences: parseNotificationPrefs(payload.notificationPreferences)
    };

    state.profile = normalized;
    renderProfile();
    if (els.err) setText(els.err, ""); // clear any old error

    if (els.profileResetBtn) {
      const path = "/Reset.html";
      els.profileResetBtn.addEventListener("click", (e) => {
        e.preventDefault();
        window.location.assign(path);
      });
    }
  } catch (e) {
    console.error(e);
    renderError(e?.message || "Failed to load profile.");
  } finally {
    state.loading = false;
  }
}

/* ---------- Start ---------- */
document.addEventListener("DOMContentLoaded", init);