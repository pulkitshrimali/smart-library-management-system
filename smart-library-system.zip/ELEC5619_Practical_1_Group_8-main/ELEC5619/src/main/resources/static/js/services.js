// backend base URL (set in window.API_BASE_URL if needed)
const API_BASE_URL = (typeof window !== "undefined" && window.API_BASE_URL) ? window.API_BASE_URL : "";

// fetch books list from backend
export async function listBooks(options = {}) {
  const q = options.q || "";
  const page = options.page || 1;
  const perPage = options.perPage || 6;
  const filters = options.filters || {}; // { availability, genre, library, year }

  // build URL
  const url = new URL(API_BASE_URL + "/books", window.location.origin);

  if (q) url.searchParams.set("q", q);
  if (page) url.searchParams.set("page", page);
  if (perPage) url.searchParams.set("perPage", perPage);

  // add filters as query params
  if (filters.availability) url.searchParams.set("availability", filters.availability);
  if (filters.genre) url.searchParams.set("genre", filters.genre);
  if (filters.library) url.searchParams.set("library", filters.library);
  if (filters.year) url.searchParams.set("year", filters.year);

  const res = await fetch(url.toString(), {
    headers: { "Accept": "application/json" }
  });

  if (!res.ok) {
    throw new Error(`Books fetch failed (${res.status})`);
  }

  // backend should return { total, items }
  return await res.json();
}
// fetch genres list from backend
export async function listGenres() {
  const url = new URL(API_BASE_URL + "/genres", window.location.origin);

  const res = await fetch(url.toString(), { headers: { "Accept": "application/json" } });
  if (!res.ok) {
    throw new Error(`Genres fetch failed (${res.status})`);
  }

  return await res.json(); // backend returns array of genres
}

// fetch libraries list from backend
export async function listLibraries() {
  const url = new URL(API_BASE_URL + "/api/libraries", window.location.origin);

  const res = await fetch(url.toString(), { headers: { "Accept": "application/json" } });
  if (!res.ok) {
    throw new Error(`Libraries fetch failed (${res.status})`);
  }

  return await res.json(); // backend returns array of libraries
}