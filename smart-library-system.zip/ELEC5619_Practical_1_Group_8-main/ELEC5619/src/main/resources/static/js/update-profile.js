function openDialogById(id){ const d=document.getElementById(id); if(d) d.style.display='flex'; }

// Elements
const btnOpenUpdate = document.getElementById('btnOpenUpdate');
const updateDialog  = document.getElementById('updateDialog');

const elEmail = document.getElementById('profileEmail');
const elPhone = document.getElementById('profilePhone');
const elBirth = document.getElementById('profileBirth');

const updEmail = document.getElementById('updEmail');
const updPhone = document.getElementById('updPhone');
const updBirth = document.getElementById('updBirth');

const errEmail = document.getElementById('errEmail');
const errPhone = document.getElementById('errPhone');
const errBirth = document.getElementById('errBirth');

btnOpenUpdate.addEventListener('click', () => {
  // Prefill from current profile display
  updEmail.value = (elEmail?.textContent || '').trim();
  updPhone.value = (elPhone?.textContent || '').trim();
  // Birth in yyyy-mm-dd if your display is already that format:
  updBirth.value = (elBirth?.textContent || '').trim();

  // Clear errors
  errEmail.textContent = ''; errPhone.textContent = ''; errBirth.textContent = '';

  openDialogById('updateDialog');
});

// Validation helper
function validateProfile() {
  let ok = true;

  // Email
  if (!updEmail.value || !/^\S+@\S+\.\S+$/.test(updEmail.value)) {
    errEmail.textContent = 'Please enter a valid email.';
    ok = false;
  } else errEmail.textContent = '';

  // Phone (AU example 0 + 9 digits)
  if (!updPhone.value || !/^0\d{9}$/.test(updPhone.value)) {
    errPhone.textContent = 'Phone must be 10 digits starting with 0.';
    ok = false;
  } else errPhone.textContent = '';

  // Birth date
  if (!updBirth.value) {
    errBirth.textContent = 'Please select your birth date.';
    ok = false;
  } else errBirth.textContent = '';

  return ok;
}

// Submit
document.getElementById('updateForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!validateProfile()) return;

  // Update UI immediately
  if (elEmail) elEmail.textContent = updEmail.value;
  if (elPhone) elPhone.textContent = updPhone.value;
  if (elBirth) elBirth.textContent = updBirth.value;

  // (Optional) Send to backend
  try {
    const res = await fetch('/profile', {
      method: 'PUT',
      headers: { 'Content-Type':'application/json' },
      body: JSON.stringify({
        email: updEmail.value,
        phone: updPhone.value,
        birth: updBirth.value
      })
    });
    if (!res.ok) throw new Error('Update failed');
  } catch (err) {
    alert('Could not save changes. Please try again.');
    return;
  }

  updateDialog.style.display = 'none';

   openDialog({
      type: 'success',
      message: 'Congratulation !!! Profile updated successfully',
      showOk: true,
      redirect: null,
      autoCloseMs: 2000
    });
});