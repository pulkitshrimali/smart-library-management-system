import './navbar.js';

let pendingPickups = [];

document.addEventListener('DOMContentLoaded', async () => {
  await loadPendingPickups();
  setupEventListeners();
});

function setupEventListeners() {
  const searchInput = document.getElementById('searchInput');
  searchInput.addEventListener('input', filterBooks);
}

async function loadPendingPickups() {
  try {
    const response = await fetch('/api/reservations/admin/pending-pickups', {
      credentials: 'include'
    });
    
    if (response.status === 401) {
      window.location.href = '/Login.html';
      return;
    }
    
    if (response.status === 403) {
      showConfirmDialog('Admin access required', 'error');
      return;
    }
    
    if (!response.ok) {
      throw new Error('Failed to load pending pickups');
    }
    
    pendingPickups = await response.json();
    renderBooks(pendingPickups);
  } catch (error) {
    console.error('Error loading pending pickups:', error);
    showConfirmDialog('Failed to load pending pickups', 'error');
  }
}

function renderBooks(books) {
  const tbody = document.getElementById('rows');
  tbody.innerHTML = '';
  
  if (books.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 2rem;">No pending pickups</td></tr>';
    return;
  }
  
  books.forEach(book => {
    const row = document.createElement('tr');
    
    const reservedDate = new Date(book.reservedAt).toLocaleDateString();
    const holdExpiry = new Date(book.holdExpiry).toLocaleDateString();
    const isExpired = new Date(book.holdExpiry) < new Date();
    
    row.innerHTML = `
      <td>
        <div style="display: flex; align-items: center; gap: 0.5rem;">
          ${book.coverImageUrl ? `<img src="${book.coverImageUrl}" alt="${book.title}" style="width: 40px; height: 60px; object-fit: cover; border-radius: 4px;">` : ''}
          <div>
            <div style="font-weight: 600;">${book.title}</div>
            <div style="font-size: 0.875rem; color: #666;">${book.isbn}</div>
          </div>
        </div>
      </td>
      <td>${book.author || 'Unknown'}</td>
      <td>${book.userName}</td>
      <td>${reservedDate}</td>
      <td style="color: ${isExpired ? '#dc2626' : 'inherit'}; font-weight: ${isExpired ? '600' : 'normal'};">
        ${holdExpiry}
        ${isExpired ? '<span style="color: #dc2626; font-size: 0.75rem; display: block;">EXPIRED</span>' : ''}
      </td>
      <td>
        <button class="btn" onclick="markAsPickedUp('${book.reservationId}')" 
                style="background: #2563eb; color: white; font-size: 0.875rem; padding: 0.5rem 1rem;">
          Mark as Picked Up
        </button>
      </td>
    `;
    
    tbody.appendChild(row);
  });
}

function filterBooks() {
  const searchTerm = document.getElementById('searchInput').value.toLowerCase();
  const filteredBooks = pendingPickups.filter(book => 
    book.title.toLowerCase().includes(searchTerm) ||
    (book.author && book.author.toLowerCase().includes(searchTerm)) ||
    book.userName.toLowerCase().includes(searchTerm) ||
    (book.isbn && book.isbn.toLowerCase().includes(searchTerm))
  );
  renderBooks(filteredBooks);
}

window.markAsPickedUp = async function(reservationId) {
  const ok = await showConfirmDialog('Mark this book as picked up?');
  if (!ok) return;
  
  try {
    const response = await fetch(`/api/reservations/admin/mark-picked-up/${reservationId}`, {
      method: 'POST',
      credentials: 'include'
    });
    
    const result = await response.json();
    
    if (result.success) {
        showConfirmDialog('Book marked as picked up successfully', 'success');
        await loadPendingPickups(); // Refresh the list
    } else {
      showConfirmDialog(result.message || 'Failed to mark book as picked up', 'error');
    }
  } catch (error) {
    console.error('Error marking book as picked up:', error);
    showConfirmDialog('Failed to mark book as picked up', 'error');
  }
};

function showConfirmDialog(message) {
  const dlg = document.getElementById('appDialog');
  const msg = document.getElementById('dlgMsg');
  const actions = dlg.querySelector('.dialog-actions');

  msg.textContent = message || '';
  dlg.style.display = 'flex';

  return new Promise((resolve) => {
    const close = (v) => { dlg.style.display = 'none'; resolve(v); };
    actions.querySelector('.ok').onclick = () => close(true);
    actions.querySelector('.cancel').onclick = () => close(false);
    dlg.onclick = (e) => { if (e.target === dlg) close(false); }; // backdrop = cancel
  });
}