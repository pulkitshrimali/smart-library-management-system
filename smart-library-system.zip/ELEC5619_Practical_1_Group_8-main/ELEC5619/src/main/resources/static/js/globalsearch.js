import "./navbar.js";
import { listBooks, listGenres, listLibraries } from './services.js';

// State management
const state = { 
  q: "", 
  page: 1, 
  perPage: 6, 
  sort: "relevance",
  filters: { availability: null, genre: null, library: null, year: null }
};

// DOM elements
const els = {
  q: document.getElementById("q"),
  sort: document.getElementById("sort"),
  list: document.getElementById("list"),
  empty: document.getElementById("empty"),
  emptyTitle: document.getElementById("emptyTitle"),
  count: document.getElementById("count"),
  prev: document.getElementById("prev"),
  next: document.getElementById("next"),
  reset: document.getElementById("resetFilters")
};

// Filter elements
const filterEls = {
  availability: document.getElementById("fAvail"),
  genre: document.getElementById("fCat"),
  library: document.getElementById("fLibrary"),
  year: document.getElementById("fYear")
};

// Utility functions
function debounce(fn, ms = 200) {
  let t;
  return (...a) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...a), ms);
  };
}

function escapeHtml(value) {
  if (value === null || value === undefined) return "";
  return String(value).replace(/[&<>"']/g, (char) => {
    switch (char) {
      case "&": return "&amp;";
      case "<": return "&lt;";
      case ">": return "&gt;";
      case '"': return "&quot;";
      case "'": return "&#39;";
      default: return char;
    }
  });
}

function initialsFromTitle(title) {
  if (!title || typeof title !== "string") return "BK";
  const words = title.trim().split(/\s+/).filter(Boolean);
  if (words.length === 0) return "BK";
  if (words.length === 1) return words[0].slice(0, 2).toUpperCase();
  return `${words[0][0]}${words[words.length - 1][0]}`.toUpperCase();
}

function sortItems(items, sortKey) {
  const arr = items.slice();
  if (sortKey === "title") {
    arr.sort((a, b) => (a.title || "").localeCompare(b.title || ""));
  } else if (sortKey === "rating") {
    const r = v => (typeof v === "number" ? v : 0);
    arr.sort((a, b) => r(b.rating) - r(a.rating));
  } else if (sortKey === "year") {
    const getYear = (book) => {
      if (!book.publicationDate) return 0;
      return new Date(book.publicationDate).getFullYear();
    };
    arr.sort((a, b) => getYear(b) - getYear(a));
  }
  return arr;
}

function coverThumb(book) {
  const url = typeof book.coverImageUrl === "string" ? book.coverImageUrl.trim() : "";
  if (url) {
    const safeUrl = escapeHtml(url);
    const title = escapeHtml(book.title || "Book");
    return `
      <div class="cover-thumb">
        <img src="${safeUrl}" alt="${title} cover" loading="lazy" decoding="async" />
      </div>
    `;
  }
  return `<div class="cover-thumb">${escapeHtml(initialsFromTitle(book.title))}</div>`;
}


function card(book) {
  const genres = (book.genres || (book.genre ? [book.genre.name] : []))
    .map(g => `<span class='badge'>${escapeHtml(g)}</span>`)
    .join("");

  const authorList = Array.isArray(book.authors)
    ? book.authors
        .map((a) => {
          if (!a) return "";
          if (typeof a === "string") return a;
          if (typeof a.name === "string") return a.name;
          return "";
        })
        .map((name) => name.trim())
        .filter(Boolean)
    : [];
  const authors = authorList.length ? authorList.join(", ") : "Unknown";

  const rating = (book.rating !== undefined && book.rating !== null && !isNaN(book.rating))
    ? Number(book.rating).toFixed(1)
    : "";

  const available = typeof book.availableCopies === "number" ? book.availableCopies > 0 : false;
  const statusClass = available ? "status-ok" : "status-no";
  const statusLabel = available ? "Available" : "Checked Out";

  const year = book.publicationDate ? new Date(book.publicationDate).getFullYear() : "—";
  const href = book.isbn ? `BookDetails.html?isbn=${encodeURIComponent(book.isbn)}` : "#";
  const disabledAttr = book.isbn ? "" : " data-disabled='true'";

  const metaParts = [
    `by ${authors}`,
    ,
    book.isbn ? `ISBN ${book.isbn}` : null,
    `📅 ${year}`
  ].filter(Boolean);

  const meta = metaParts.map(part => `<span>${escapeHtml(part)}</span>`).join("");

  return `
    <a class="card" href="${href}"${disabledAttr} aria-label="${escapeHtml(`${book.title || "Untitled"} – ${statusLabel}`)}">
      ${coverThumb(book)}
      <div class="card-main">
        <div class="title">${escapeHtml(book.title || "Untitled")}</div>
        <div class="meta">${meta}</div>
        <div class="badges">${genres}</div>
      </div>
      <div class="status-overlay ${statusClass}">
        <span>${escapeHtml(statusLabel)}</span>
      </div>
    </a>
  `;
}

async function render() {
  try {
    const activeFilters = {};
    for (let key in state.filters) {
      activeFilters[key] = state.filters[key] === "all" ? null : state.filters[key];
    }
    
    const res = await listBooks({ 
      q: state.q, 
      page: state.page, 
      perPage: state.perPage, 
      filters: activeFilters 
    });
    
    const total = typeof res.total === "number" ? res.total : 0;
    const items = sortItems(Array.isArray(res.items) ? res.items : [], state.sort);
    const pages = Math.max(1, Math.ceil(total / state.perPage));
    
    if (state.page > pages) state.page = pages;

    els.count.textContent = `${total} ${total === 1 ? "result" : "results"} found`;

    if (total === 0) {
      els.list.innerHTML = "";
      els.empty.style.display = "block";
      els.emptyTitle.textContent = state.q.trim() ? `No results for "${state.q}"` : "No results";
    } else {
      els.empty.style.display = "none";
      els.list.innerHTML = items.map(card).join("");
      els.list.querySelectorAll("a[data-disabled]").forEach((anchor) => {
        anchor.addEventListener("click", (event) => event.preventDefault());
        anchor.classList.add("is-disabled");
      });
    }

    els.prev.disabled = state.page <= 1;
    els.next.disabled = state.page >= pages;
  } catch(e) {
    els.list.innerHTML = `<div class='empty'><h3>Something went wrong</h3><p class='sub'>${e?.message || "Please try again."}</p></div>`;
  }
}

// Initialize
async function init() {
  // Populate genres
  try {
    const genres = await listGenres();
    const genreEl = document.getElementById("fCat");
    genreEl.innerHTML = `<option value="all">All</option>` + 
      genres.map(g => `<option value="${g.name}">${g.name}</option>`).join("");
  } catch(e) {
    console.error("Failed to load genres:", e);
  }

  // Populate libraries
  try {
    const libraries = await listLibraries();
    const libraryEl = document.getElementById("fLibrary");
    libraryEl.innerHTML = `<option value="all">All Libraries</option>` + 
      libraries.map(l => `<option value="${l.libraryId}">${l.name}</option>`).join("");
  } catch(e) {
    console.error("Failed to load libraries:", e);
  }

  // Event listeners
  Object.entries(filterEls).forEach(([key, el]) => {
    el.addEventListener("change", () => {
      state.filters[key] = el.value;
      state.page = 1;
      render();
    });
  });

  els.q.addEventListener("input", debounce(e => {
    state.q = e.target.value;
    state.page = 1;
    state.sort = "relevance";
    els.sort.value = "relevance";
    render();
  }, 160));

  els.sort.addEventListener("change", () => {
    state.sort = els.sort.value || "relevance";
    state.page = 1;
    render();
  });

  els.prev.addEventListener("click", () => {
    if (state.page > 1) {
      state.page--;
      render();
    }
  });

  els.next.addEventListener("click", () => {
    state.page++;
    render();
  });
  els.reset.addEventListener("click", () => {
    // Reset all filters and search
    Object.entries(filterEls).forEach(([k, el]) => {
      el.value = "all";
      state.filters[k] = null;
    });
    els.q.value = "";
    els.sort.value = "relevance";
    state.q = "";
    state.sort = "relevance";
    state.page = 1;
    render();
  });
  // Initial render
  render();
}

// Start when DOM is ready
document.addEventListener('DOMContentLoaded', init);
