document.addEventListener("DOMContentLoaded", () => {
    const reserveBtn = document.getElementById("reserve-btn");
  
    reserveBtn.addEventListener("click", () => {
      alert("Book reserved successfully!");
    });
  });
  