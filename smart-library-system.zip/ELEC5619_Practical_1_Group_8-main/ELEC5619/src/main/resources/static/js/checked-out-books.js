import './navbar.js';

let checkedOutBooks = [];

document.addEventListener('DOMContentLoaded', async () => {
  await loadCheckedOutBooks();
  setupEventListeners();
});

function setupEventListeners() {
  const searchInput = document.getElementById('searchInput');
  searchInput.addEventListener('input', filterBooks);
}

async function loadCheckedOutBooks() {
  try {
    const response = await fetch('/api/reservations/admin/checked-out', {
      credentials: 'include'
    });
    
    if (response.status === 401) {
      window.location.href = '/Login.html';
      return;
    }
    
    if (response.status === 403) {
      showConfirmDialog('Admin access required', 'error');
      return;
    }
    
    if (!response.ok) {
      throw new Error('Failed to load checked out books');
    }
    
    checkedOutBooks = await response.json();
    renderBooks(checkedOutBooks);
  } catch (error) {
    console.error('Error loading checked out books:', error);
    showConfirmDialog('Failed to load checked out books', 'error');
  }
}

function renderBooks(books) {
  const tbody = document.getElementById('rows');
  tbody.innerHTML = '';
  
  if (books.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 2rem;">No books currently checked out</td></tr>';
    return;
  }
  
  books.forEach(book => {
    const row = document.createElement('tr');
    
    const startDate = new Date(book.startDate).toLocaleDateString();
    const endDate = new Date(book.endDate).toLocaleDateString();
    const isOverdue = new Date(book.endDate) < new Date();
    
    row.innerHTML = `
      <td>
        <div style="display: flex; align-items: center; gap: 0.5rem;">
          ${book.coverImageUrl ? `<img src="${book.coverImageUrl}" alt="${book.title}" style="width: 40px; height: 60px; object-fit: cover; border-radius: 4px;">` : ''}
          <div>
            <div style="font-weight: 600;">${book.title}</div>
            <div style="font-size: 0.875rem; color: #666;">${book.isbn}</div>
          </div>
        </div>
      </td>
      <td>${book.author || 'Unknown'}</td>
      <td>${book.userName}</td>
      <td>${startDate}</td>
      <td style="color: ${isOverdue ? '#dc2626' : 'inherit'}; font-weight: ${isOverdue ? '600' : 'normal'};">
        ${endDate}
        ${isOverdue ? '<span style="color: #dc2626; font-size: 0.75rem; display: block;">OVERDUE</span>' : ''}
      </td>
      <td>
        <button class="btn" onclick="markAsReturned('${book.reservationId}')" 
                style="background: #059669; color: white; font-size: 0.875rem; padding: 0.5rem 1rem;">
          Mark as Returned
        </button>
      </td>
    `;
    
    tbody.appendChild(row);
  });
}

function filterBooks() {
  const searchTerm = document.getElementById('searchInput').value.toLowerCase();
  const filteredBooks = checkedOutBooks.filter(book => 
    book.title.toLowerCase().includes(searchTerm) ||
    (book.author && book.author.toLowerCase().includes(searchTerm)) ||
    book.userName.toLowerCase().includes(searchTerm) ||
    (book.isbn && book.isbn.toLowerCase().includes(searchTerm))
  );
  renderBooks(filteredBooks);
}

window.markAsReturned = async function(reservationId) {
  const ok = await showConfirmDialog('Mark this book as picked up?');
  if (!ok) return;
  
  try {
    const response = await fetch(`/api/reservations/admin/mark-returned/${reservationId}`, {
      method: 'POST',
      credentials: 'include'
    });
    
    const result = await response.json();
    
    if (result.success) {
      showConfirmDialog('Book marked as returned successfully', 'success');
      await loadCheckedOutBooks(); // Refresh the list
    } else {
      showConfirmDialog(result.message || 'Failed to mark book as returned', 'error');
    }
  } catch (error) {
    console.error('Error marking book as returned:', error);
    showConfirmDialog('Failed to mark book as returned', 'error');
  }
};

function showConfirmDialog(message) {
  const dlg = document.getElementById('appDialog');
  const msg = document.getElementById('dlgMsg');
  const actions = dlg.querySelector('.dialog-actions');

  msg.textContent = message || '';
  dlg.style.display = 'flex';

  return new Promise((resolve) => {
    const close = (v) => { dlg.style.display = 'none'; resolve(v); };
    actions.querySelector('.ok').onclick = () => close(true);
    actions.querySelector('.cancel').onclick = () => close(false);
    dlg.onclick = (e) => { if (e.target === dlg) close(false); }; // backdrop = cancel
  });
}