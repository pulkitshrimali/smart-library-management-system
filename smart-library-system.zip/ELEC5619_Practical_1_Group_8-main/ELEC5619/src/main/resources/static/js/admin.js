import "./navbar.js";

document.addEventListener("DOMContentLoaded", () => {
  const API = window.API_BASE_URL || "";
  const state = { q: "", page: 1, perPage: 8, editingIsbn: null };

  const $ = (id) => document.getElementById(id);
  const els = {
    title: $("title"),
    author: $("author"),
    isbn: $("isbn"),
    summary: $("summary"),
    genre: $("genre"),
    publisher: $("publisher"),
    pubdate: $("pubdate") || $("year"),
    copies: $("copies"),
    q: $("searchInput"),
    saveBtn: $("btnSave") || $("btnAddOpen"),
    clearBtn: $("btnCancel"),
    rows: $("rows"),
    modalForm: $("modalForm"),
    modalClose: $("modalClose"),
    modalTitle: $("modalTitle"),
    addOpen: $("btnAddOpen"),
  };

  function openDeleteModal(title, onConfirm) {
    const overlay = document.getElementById("modalDelete");
    const msg = document.getElementById("delMsg");
    const btnConfirm = document.getElementById("delConfirm");
    const btnCancel = document.getElementById("delCancel");
    const btnClose = document.getElementById("delClose");
    if (!overlay || !btnConfirm || !btnCancel || !btnClose || !msg) return;

    msg.innerHTML = `Are you sure you want to permanently delete <strong>${title || "this book"}</strong>?`;

    const close = () => {
      overlay.style.display = "none";
      btnConfirm.onclick = null;
      btnCancel.onclick = null;
      btnClose.onclick = null;
      overlay.onclick = null;
    };

    btnConfirm.onclick = async () => {
      await onConfirm();
      close();
    };
    btnCancel.onclick = close;
    btnClose.onclick = close;
    overlay.onclick = (e) => { if (e.target === overlay) close(); };
    overlay.style.display = "flex";
  }

  function showMsg(kind, text) {
    if (!els.msg) return console[kind === "error" ? "error" : "log"](text);
    els.msg.textContent = text;
    els.msg.style.display = text ? "block" : "none";
    els.msg.style.background = kind === "error" ? "#fde2e2" : kind === "warn" ? "#fff4cc" : "#e6f6e6";
    els.msg.style.color = kind === "error" ? "#8b1d1d" : "#3e3b00";
    els.msg.style.border = kind === "error" ? "1px solid #f3b1b1" : "1px solid #e5d48a";
  }

  const on = (el, ev, fn) => el && el.addEventListener(ev, fn);

  function yearOf(s) {
    if (!s) return "—";
    const y = new Date(s).getFullYear();
    return isNaN(y) ? "—" : String(y);
  }

  async function listBooks({ q, page, perPage }) {
    const sp = new URLSearchParams();
    if (q?.trim()) sp.set("q", q.trim());
    sp.set("page", page);
    sp.set("perPage", perPage);
    const res = await fetch(`${API}/books?${sp.toString()}`, { headers: { Accept: "application/json" } });
    if (!res.ok) throw new Error(`Failed to load books (${res.status})`);
    return res.json();
  }

  async function createBook(payload) {
    const res = await fetch(`${API}/admin/books`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.message || "Add failed");
    return data;
  }

  async function updateBook(isbn, payload) {
    const res = await fetch(`${API}/admin/books/${encodeURIComponent(isbn)}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.message || "Update failed");
    return data;
  }

  async function deleteBook(isbn) {
    const res = await fetch(`${API}/admin/books/${encodeURIComponent(isbn)}`, { method: "DELETE" });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.message || "Delete failed");
    return data;
  }

  function setModalMode(mode) {
    const isEdit = mode === "edit";
    if (els.modalTitle) els.modalTitle.textContent = isEdit ? "Edit Book" : "Add Book";
    if (els.saveBtn) els.saveBtn.textContent = isEdit ? "Update" : "Save";
  }

  function clearForm() {
    if (els.title) els.title.value = "";
    if (els.author) els.author.value = "";
    if (els.summary) els.summary.value = "";
    if (els.genre) els.genre.value = "";
    if (els.isbn) els.isbn.value = "";
    if (els.pubdate) els.pubdate.value = "";
    if (els.publisher) els.publisher.value = "";
    if (els.copies) els.copies.value = "1";
    state.editingIsbn = null;
    setModalMode("add");
    showMsg("", "");
  }

  function payloadFromForm() {
    const authors = (els.author?.value || "")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean)
      .map((name) => ({ name }));
    const payload = {
      title: els.title?.value.trim(),
      authors,
      isbn: els.isbn?.value.trim(),
    };

    if (els.pubdate?.value) {
      const dt = new Date(els.pubdate.value);
      if (!Number.isNaN(dt.getTime())) {
        payload.publicationDate = dt.toISOString();
      }
    }

    const summary = els.summary?.value?.trim();
    if (summary) payload.blurb = summary;

    const genreName = els.genre?.value?.trim();
    if (genreName) payload.genreName = genreName;

    const publisher = els.publisher?.value?.trim();
    if (publisher) payload.publisher = publisher;

    const totalCopies = Number.parseInt(els.copies?.value, 10);
    if (Number.isFinite(totalCopies) && totalCopies > 0) payload.totalCopies = totalCopies;

    return payload;
  }

  async function render() {
    try {
      const res = await listBooks({ q: state.q, page: state.page, perPage: state.perPage });
      const items = Array.isArray(res.items) ? res.items : [];
      if (!els.rows) return;

      if (!items.length) {
        els.rows.innerHTML = `<tr><td colspan="4" style="padding:14px;color:#4b5b52">No books found.</td></tr>`;
        return;
      }

      els.rows.innerHTML = "";
      items.forEach((b) => {
        const tr = document.createElement("tr");
        const totalCopies = Number.isFinite(Number(b.totalCopies)) ? Number(b.totalCopies) : null;
        const available = Number.isFinite(Number(b.availableCopies)) ? Number(b.availableCopies) : null;
        const copiesCount = totalCopies !== null ? totalCopies : available !== null ? available : null;
        const copiesText = copiesCount === null ? "—" : `${copiesCount}`;

        tr.innerHTML = `
          <td class="cell-title">${b.title || "—"}</td>
          <td>${Array.isArray(b.authors) && b.authors.length ? b.authors.map(a => a.name).join(", ") : (b.author || "—")}</td>
          <td>${copiesText}</td>
          <td>${b.publicationDate ? yearOf(b.publicationDate) : "—"}</td>
          <td>
            <div class="row-actions">
              <button class="btn" data-edit="${b.isbn}">Edit</button>
              <button class="btn danger" data-del="${b.isbn}" data-title="${(b.title || "").replace(/"/g, '&quot;')}">Delete</button>
            </div>
          </td>
        `;
        // Navigate to details page on row click (ignore button clicks)
        tr.addEventListener("click", (e) => {
          if (!e.target.closest("button")) window.location.href = `bookdetails.html?isbn=${b.isbn}`;
        });
        els.rows.appendChild(tr);
      });

      // Attach button events
      els.rows.querySelectorAll("[data-edit]").forEach((btn) => {
        btn.addEventListener("click", (e) => {
          e.stopPropagation();
          const isbn = btn.getAttribute("data-edit");
          const book = items.find((x) => x.isbn === isbn);
          if (!book) return;
          setModalMode("edit");
          if (els.title) els.title.value = book.title || "";
          if (els.author) els.author.value = Array.isArray(book.authors) && book.authors.length ? book.authors.map(a => a.name).join(", ") : (book.author || "");
          if (els.isbn) els.isbn.value = book.isbn || "";
          if (els.pubdate) els.pubdate.value = book.publicationDate ? book.publicationDate.slice(0,10) : "";
          if (els.summary) els.summary.value = book.blurb || "";
          if (els.genre) els.genre.value = (book.genre && (book.genre.name || book.genreName)) || "";
          if (els.publisher) els.publisher.value = book.publisher || "";
          if (els.copies) els.copies.value = Number.isFinite(Number(book.totalCopies)) ? book.totalCopies : "";
          state.editingIsbn = isbn;
          if (els.modalForm) els.modalForm.style.display = "flex";
        });
      });

      els.rows.querySelectorAll("[data-del]").forEach((btn) => {
        btn.addEventListener("click", (e) => {
          e.stopPropagation();
          const isbn = btn.getAttribute("data-del");
          const title = btn.dataset.title || isbn;
          openDeleteModal(title, async () => {
            try {
              await deleteBook(isbn);
              if (state.editingIsbn === isbn) clearForm();
              await render();
            } catch (err) {
              alert(err.message || "Delete failed");
            }
          });
        });
      });
    } catch (err) {
      els.rows.innerHTML = `<tr><td colspan="5" style="color:#8b1d1d;padding:12px">${err.message || "Failed to load"}</td></tr>`;
      console.error(err);
    }
  }

  // Event listeners for modal/buttons
  on(els.addOpen, "click", () => { clearForm(); if (els.modalForm) els.modalForm.style.display = "flex"; });
  on(els.modalClose, "click", () => { if (els.modalForm) els.modalForm.style.display = "none"; clearForm(); });
  on(els.clearBtn, "click", () => { if (els.modalForm) els.modalForm.style.display = "none"; clearForm(); });

  on(els.saveBtn, "click", async () => {
    const p = payloadFromForm();
    if (!p.title || !p.isbn || !p.authors.length) return alert("Title, Author(s), and ISBN are required.");
    try {
      if (state.editingIsbn) {
        await updateBook(state.editingIsbn, p);
      } else {
        await createBook(p);
      }
      clearForm();
      if (els.modalForm) els.modalForm.style.display = "none";
      await render();
    } catch (e) {
      alert(e.message || (state.editingIsbn ? "Failed to update" : "Failed to add"));
    }
  });

  // Search input
  let t;
  on(els.q, "input", () => {
    clearTimeout(t);
    t = setTimeout(() => { state.q = els.q.value; state.page = 1; render(); }, 220);
  });

  render();
});
