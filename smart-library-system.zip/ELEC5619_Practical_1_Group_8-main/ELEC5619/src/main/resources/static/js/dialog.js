// Open the single dialog with options
// type: "success" | "error" | "info"
function openDialog({ message = "", type = "info", redirect = null, autoCloseMs = 2000 } = {}) {
  const dlg   = document.getElementById("appDialog");
  const icon  = document.getElementById("dlgIcon");
  const msgEl = document.getElementById("dlgMsg");

  // Reset + apply type
  dlg.classList.remove("success","error","info");
  dlg.classList.add(type);

  // Icon per type
  icon.textContent = type === "success" ? "✅" : type === "error" ? "❌" : "ℹ️";

  // Message
  msgEl.textContent = message || "";

  // Show dialog
  dlg.style.display = "flex";

  // Auto-close + optional redirect
  if (autoCloseMs) {
    clearTimeout(openDialog._t);
    openDialog._t = setTimeout(() => {
      dlg.style.display = "none";
      if (redirect) window.location.href = redirect;
    }, autoCloseMs);
  }
}

// Close dialog manually (if needed)
function closeDialog(dlg) {
  if (typeof dlg === "string") dlg = document.getElementById(dlg);
  if (!dlg) return;
  dlg.style.display = "none";
}
