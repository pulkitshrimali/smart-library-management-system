// how each book card looks
function card(book) {
  let genreHtml = book.genres && book.genres.length
    ? book.genres.map(g => `<span class='badge'>${g}</span>`).join("")
    : "";

  let rating = book.rating ? book.rating.toFixed(1) : "—";

  let status = book.available
    ? "<span class='status ok'>Available</span>"
    : "<span class='status no'>Checked Out</span>";

  return `
  <a href="BookDetails.html?id=${book.id}" style="text-decoration:none;color:inherit">
    <article class="card">
      <div class="icon">📘</div>
      <div>
        <div class="title">${book.title}</div>
        <div class="meta">
          <span>by ${book.author}</span>
          <span>★ ${rating}</span>
          <span>ISBN ${book.isbn}</span>
          <span>📅 ${book.year}</span>
        </div>
        <div class="badges">${genreHtml}</div>
      </div>
      ${status}
    </article>
  </a>
  `;
}

// get ?id= from URL
const params = new URLSearchParams(window.location.search);
const bookId = parseInt(params.get("id"), 10);

async function loadBookDetails() {
  const res = await fetch("./mocks/data.json");
  const books = await res.json();

  const book = books.find(b => b.id === bookId);

  if (!book) {
    document.querySelector(".main").innerHTML = "<p>❌ Book not found.</p>";
    return;
  }

  // recommendations: same author and same genre, exclude current
  const related = books.filter(b => {
    const sameAuthor = b.author === book.author;
    const sameGenre = b.genres.some(g => book.genres.includes(g));
    return sameAuthor && sameGenre && b.id !== book.id;
  });
  const relatedList = document.getElementById("related-list");
  relatedList.innerHTML = related.length
    ? related.map(b => card(b)).join("")
    : "<div class='related-empty'>No related books found.</div>";
}
loadBookDetails();