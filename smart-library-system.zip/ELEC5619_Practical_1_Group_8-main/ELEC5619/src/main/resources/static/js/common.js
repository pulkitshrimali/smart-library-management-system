/**
 * Common JavaScript functions for LibraryHub
 * Contains shared utilities and API helpers
 */

// Global configuration from server
window.LibraryHub = window.LibraryHub || {};
window.LibraryHub.config = window.APP_CONFIG || {};

// API Helper Functions
class ApiService {
    constructor() {
        this.baseUrl = window.LibraryHub.config.API_BASE_URL || '/api';
        this.csrfToken = window.LibraryHub.config.CSRF_TOKEN;
        this.csrfHeader = window.LibraryHub.config.CSRF_HEADER;
    }

    /**
     * Make authenticated API call with CSRF protection
     */
    async makeRequest(url, options = {}) {
        const defaultHeaders = {
            'Content-Type': 'application/json',
        };

        // Add CSRF token if available
        if (this.csrfToken && this.csrfHeader) {
            defaultHeaders[this.csrfHeader] = this.csrfToken;
        }

        const config = {
            credentials: 'include',
            headers: {
                ...defaultHeaders,
                ...options.headers
            },
            ...options
        };

        try {
            const response = await fetch(url, config);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const contentType = response.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                return await response.json();
            }
            
            return await response.text();
        } catch (error) {
            console.error('API Request failed:', error);
            throw error;
        }
    }

    /**
     * GET request
     */
    async get(endpoint) {
        return this.makeRequest(`${this.baseUrl}${endpoint}`, {
            method: 'GET'
        });
    }

    /**
     * POST request
     */
    async post(endpoint, data) {
        return this.makeRequest(`${this.baseUrl}${endpoint}`, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }

    /**
     * PUT request
     */
    async put(endpoint, data) {
        return this.makeRequest(`${this.baseUrl}${endpoint}`, {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    }

    /**
     * DELETE request
     */
    async delete(endpoint) {
        return this.makeRequest(`${this.baseUrl}${endpoint}`, {
            method: 'DELETE'
        });
    }
}

// Initialize API service
window.LibraryHub.api = new ApiService();

// Utility Functions
class Utils {
    /**
     * Escape HTML to prevent XSS attacks
     */
    static escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * Format date for display
     */
    static formatDate(dateString, options = {}) {
        if (!dateString) return 'Unknown';
        
        const defaultOptions = {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        };
        
        try {
            const date = new Date(dateString);
            return date.toLocaleDateString('en-US', { ...defaultOptions, ...options });
        } catch (error) {
            console.error('Date formatting error:', error);
            return dateString;
        }
    }

    /**
     * Generate star rating display
     */
    static generateStarDisplay(rating) {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 >= 0.5;
        const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
        
        let stars = '';
        
        // Full stars
        for (let i = 0; i < fullStars; i++) {
            stars += '★';
        }
        
        // Half star (using outline star for simplicity)
        if (hasHalfStar) {
            stars += '☆';
        }
        
        // Empty stars
        for (let i = 0; i < emptyStars; i++) {
            stars += '☆';
        }
        
        return stars;
    }

    /**
     * Show notification to user
     */
    static showNotification(message, type = 'info', duration = 5000) {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <span class="notification-message">${this.escapeHtml(message)}</span>
            <button class="notification-close" onclick="this.parentElement.remove()">×</button>
        `;
        
        // Add to page
        document.body.appendChild(notification);
        
        // Auto remove after duration
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, duration);
        
        return notification;
    }

    /**
     * Debounce function calls
     */
    static debounce(func, wait, immediate = false) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                timeout = null;
                if (!immediate) func(...args);
            };
            const callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func(...args);
        };
    }

    /**
     * Throttle function calls
     */
    static throttle(func, limit) {
        let inThrottle;
        return function executedFunction(...args) {
            if (!inThrottle) {
                func.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }

    /**
     * Check if user is logged in
     */
    static isUserLoggedIn() {
        return window.LibraryHub.config.USER_LOGGED_IN === true;
    }

    /**
     * Redirect to login page
     */
    static redirectToLogin(returnUrl = null) {
        const redirect = returnUrl || window.location.pathname + window.location.search;
        window.location.href = `/login?redirect=${encodeURIComponent(redirect)}`;
    }

    /**
     * Format number with commas
     */
    static formatNumber(num) {
        if (typeof num !== 'number') return '0';
        return num.toLocaleString();
    }

    /**
     * Truncate text to specified length
     */
    static truncateText(text, maxLength, suffix = '...') {
        if (!text || text.length <= maxLength) return text;
        return text.substring(0, maxLength - suffix.length) + suffix;
    }
}

// Attach utilities to global object
window.LibraryHub.utils = Utils;

// User Management
class UserService {
    constructor() {
        this.currentUser = null;
        this.api = window.LibraryHub.api;
    }

    /**
     * Load current user data
     */
    async loadCurrentUser() {
        try {
            this.currentUser = await this.api.get('/user/current');
            this.updateUserDisplay();
            return this.currentUser;
        } catch (error) {
            console.error('Error loading user data:', error);
            this.handleGuestUser();
            return null;
        }
    }

    /**
     * Update user display in navigation
     */
    updateUserDisplay() {
        const userNameEl = document.getElementById('userName');
        const userAvatarEl = document.getElementById('userAvatar');
        
        if (this.currentUser && userNameEl && userAvatarEl) {
            userNameEl.textContent = `${this.currentUser.firstName} ${this.currentUser.lastName}`;
            userAvatarEl.textContent = 
                (this.currentUser.firstName.charAt(0) + this.currentUser.lastName.charAt(0)).toUpperCase();
        }
    }

    /**
     * Handle guest user state
     */
    handleGuestUser() {
        const userNameEl = document.getElementById('userName');
        const userAvatarEl = document.getElementById('userAvatar');
        
        if (userNameEl) userNameEl.textContent = 'Guest';
        if (userAvatarEl) userAvatarEl.textContent = '?';
    }

    /**
     * Get current user
     */
    getCurrentUser() {
        return this.currentUser;
    }

    /**
     * Check if user is logged in
     */
    isLoggedIn() {
        return this.currentUser !== null;
    }
}

// Initialize user service
window.LibraryHub.userService = new UserService();

// Loading State Management
class LoadingManager {
    /**
     * Show loading state
     */
    static show(containerId = 'loadingContainer') {
        const container = document.getElementById(containerId);
        if (container) {
            container.style.display = 'flex';
        }
    }

    /**
     * Hide loading state
     */
    static hide(containerId = 'loadingContainer') {
        const container = document.getElementById(containerId);
        if (container) {
            container.style.display = 'none';
        }
    }

    /**
     * Show main content with animation
     */
    static showMainContent(contentId = 'mainContent') {
        const mainContent = document.getElementById(contentId);
        if (mainContent) {
            mainContent.style.display = 'block';
            setTimeout(() => {
                mainContent.classList.add('loaded');
            }, 100);
        }
    }
}

window.LibraryHub.loadingManager = LoadingManager;

// Error Handling
class ErrorHandler {
    /**
     * Show error message
     */
    static showError(message, containerId = 'errorContainer') {
        const errorContainer = document.getElementById(containerId);
        const errorMessage = document.getElementById('errorMessage');
        
        if (errorContainer && errorMessage) {
            errorMessage.textContent = message;
            errorContainer.style.display = 'block';
        }
    }

    /**
     * Hide error message
     */
    static hideError(containerId = 'errorContainer') {
        const errorContainer = document.getElementById(containerId);
        if (errorContainer) {
            errorContainer.style.display = 'none';
        }
    }

    /**
     * Handle API errors
     */
    static handleApiError(error, userMessage = 'An error occurred. Please try again.') {
        console.error('API Error:', error);
        
        // Check for specific error types
        if (error.message.includes('401') || error.message.includes('403')) {
            Utils.showNotification('Please log in to continue', 'error');
            Utils.redirectToLogin();
            return;
        }
        
        if (error.message.includes('404')) {
            this.showError('The requested resource was not found.');
            return;
        }
        
        if (error.message.includes('500')) {
            this.showError('Server error. Please try again later.');
            return;
        }
        
        // Network errors
        if (!navigator.onLine) {
            this.showError('No internet connection. Please check your connection and try again.');
            return;
        }
        
        // Generic error
        this.showError(userMessage);
    }
}

window.LibraryHub.errorHandler = ErrorHandler;

// Initialize common functionality
document.addEventListener('DOMContentLoaded', function() {
    // Load user data
    window.LibraryHub.userService.loadCurrentUser();
    
    // Add smooth scroll behavior for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Handle network status changes
    window.addEventListener('online', function() {
        console.log('Connection restored');
        Utils.showNotification('Connection restored', 'success', 3000);
        ErrorHandler.hideError();
    });

    window.addEventListener('offline', function() {
        console.log('Connection lost');
        Utils.showNotification('Connection lost. Please check your internet connection.', 'error');
    });
    
    // Add click handler for user avatar (could open dropdown menu)
    const userAvatar = document.getElementById('userAvatar');
    if (userAvatar) {
        userAvatar.addEventListener('click', function() {
            // Could implement user menu dropdown here
            console.log('User avatar clicked');
        });
    }
});

// CSS for notifications (add to head if not already present)
if (!document.querySelector('#notification-styles')) {
    const style = document.createElement('style');
    style.id = 'notification-styles';
    style.textContent = `
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 8px;
            color: white;
            font-weight: 600;
            z-index: 10000;
            display: flex;
            align-items: center;
            gap: 15px;
            max-width: 400px;
            animation: slideInRight 0.3s ease;
        }
        
        .notification-info { background: #588157; }
        .notification-success { background: #A3B18A; }
        .notification-error { background: #cd5c5c; }
        .notification-warning { background: #f0ad4e; }
        
        .notification-close {
            background: none;
            border: none;
            color: white;
            font-size: 18px;
            cursor: pointer;
            padding: 0;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
    `;
    document.head.appendChild(style);
}

// Export for potential module use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        ApiService,
        Utils,
        UserService,
        LoadingManager,
        ErrorHandler
    };
}