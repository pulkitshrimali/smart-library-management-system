const KEY_ROLE = "lh.role";
const KEY_USER = "lh.user";

document.getElementById("signupBtn").addEventListener("click", signup);

async function signup() {
  const nameInput = document.getElementById("suname");
  const phoneInput = document.getElementById("suphone");
  const emailInput = document.getElementById("suemail");
  const birthInput = document.getElementById("subirth");
  const passwordInput = document.getElementById("supw");
  const confirmPassword = document.getElementById("csupw");
  const errPhone = document.getElementById("errsuphone");
  const errEmail = document.getElementById("errsuemail");
  const errPassword = document.getElementById("errsupw");
  const errConfirmPassword = document.getElementById("errcsupw");
  const btn = document.getElementById("signupBtn");

  const password = passwordInput.value.trim();
  errPassword.textContent = "";

  let ok = true;

  // --- Email validation ---
  if (!emailInput.value.trim() || !/^\S+@\S+\.\S+$/.test(emailInput.value)) {
    errEmail.textContent = "Please enter a valid email.";
    ok = false;
  } else {
    errEmail.textContent = "";
  }

  // Phone (AU example 0 + 9 digits)
  if (!phoneInput.value || !/^0\d{9}$/.test(phoneInput.value)) {
      errPhone.textContent = 'Phone must be 10 digits starting with 0.';
      ok = false;
  } else errPhone.textContent = '';


  // --- Password validation ---
  // must be at least 12 characters, contain at least one number and one symbol
  const hasNumber = /\d/.test(password);
  const hasSymbol = /[^A-Za-z0-9]/.test(password);

  if (!password) {
        errPassword.textContent = "Password is required.";
        ok = false;
  } else if (password.length < 12) {
        errPassword.textContent = "Use at least 12 characters with numbers & symbols.";
        ok = false;
  } else if (!hasNumber || !hasSymbol) {
        errPassword.textContent = "Password must include at least one number and one symbol.";
        ok = false;
  }

  // Check if they match
  if (passwordInput.value !== confirmPassword.value) {
    errConfirmPassword.textContent = "Passwords do not match.";
      return;
  }else{
  errConfirmPassword.textContent = "";
  }
  if (!ok) return;


  try{
    // --- Send data to backend ---
    const response = await fetch("/auth/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: emailInput.value.trim(),
        password: passwordInput.value.trim(),
        name: nameInput.value.trim(),
        phoneNumber: phoneInput.value.trim(),  
    birthDate: birthInput.value.trim() 
      })
    });

    const data = await response.json();

    // --- Handle response from backend ---
    if (data.status === "ok") {
     try{
       localStorage.setItem(KEY_ROLE, "user");
       localStorage.setItem(KEY_USER, JSON.stringify({
         name: nameInput.value.trim() || "User",
         email: emailInput.value.trim()
       }));
     } catch(storageError){
       console.warn("Unable to persist signup state", storageError);
     }
     // show success + redirect
     openDialog({
        type: "success",
        message: "Congratulation Signup successful!!!!!",
        showOk: false,
        redirect: "GlobalSearch.html",
        autoCloseMs: 2000
      });
      setTimeout(() => { window.location.href = target; }, 2100);
    } else {
    // generic error popup
    openDialog({
            type: "error",
            message: "Unfortunately, Your account didn't signup",
             showOk: true,
            redirect: null,
            autoCloseMs: 1700
          });
    }

  }catch(error){
     console.error("Network or server error:", error);
  }
}


function toggle(btn, id) {
  const el = document.getElementById(id);

  if (el.type === "password") {
    el.type = "text";
    btn.textContent = "🙈";  // hide icon
  } else {
    el.type = "password";
    btn.textContent = "👁";    // show icon
  }
}
