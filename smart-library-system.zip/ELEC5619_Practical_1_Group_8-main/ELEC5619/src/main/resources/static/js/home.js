import "./navbar.js";
import { listBooks } from "./services.js";

const testimonials = [
  {
    quote: "“LibraryHub helped me find textbooks that were always checked out in the main library.”",
    name: "Ava – Electrical Engineering"
  },
  {
    quote: "“I love the weekly shelves. They keep me reading beyond my course list.”",
    name: "Marcus – Information Systems"
  },
  {
    quote: "“The reminders save me from late fees, and the surprise picks are always on point.”",
    name: "Priya – Industrial Design"
  }
];

document.addEventListener("DOMContentLoaded", () => {
  loadCarouselBooks();
  initRandomPick();
  loadStats();
  cycleTestimonials();
  initSignupForm();
});

function initRandomPick() {
  const btn = document.getElementById("randomPickBtn");
  const output = document.getElementById("randomPickOutput");
  if (!btn || !output) return;

  btn.addEventListener("click", async () => {
    const suggestion = await getRandomSuggestion();
    output.textContent = suggestion ? `Try: ${suggestion}` : "Try refreshing for more ideas.";
  });
}

async function getRandomSuggestion() {
  try {
    const response = await fetch("/books/random", { headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    const formatted = formatBookSuggestion(data);
    if (formatted) return formatted;
  } catch (error) {
    console.warn("Falling back to local suggestions:", error);
  }

  const fallbackBooks = collectCarouselBooks();
  if (!fallbackBooks.length) return "";
  const pick = fallbackBooks[Math.floor(Math.random() * fallbackBooks.length)];
  return formatBookSuggestion(pick);
}

function collectCarouselBooks() {
  return Array.from(document.querySelectorAll("#carouselTrack .book-card")).map((card) => {
    const title = card.dataset.title?.trim() || card.querySelector("h3")?.textContent?.trim();
    const authors = (card.dataset.authors || "")
      .split("|")
      .map((name) => name.trim())
      .filter(Boolean)
      .map((name) => ({ name }));
    return { title, authors };
  }).filter((book) => !!book.title);
}

function formatBookSuggestion(book) {
  if (!book || !book.title) return "";
  const title = book.title.trim();
  const authors = Array.isArray(book.authors) ? book.authors : [];
  const authorNames = authors
    .map((a) => a?.name?.trim())
    .filter(Boolean)
    .join(", ");
  return authorNames ? `${title} by ${authorNames}` : title;
}

async function loadCarouselBooks() {
  const track = document.getElementById("carouselTrack");
  if (!track) return;

  try {
    const { items = [] } = await listBooks({ page: 1, perPage: 24 });
    const uniqueBooks = dedupeBooks(items);

    if (!uniqueBooks.length) {
      track.innerHTML = `<p class="carousel-empty">No featured books to display yet.</p>`;
      initCarousel();
      return;
    }

    track.innerHTML = "";

    uniqueBooks.slice(0, 8).forEach((book) => {
      const card = document.createElement("a");
      card.className = "book-card";

      if (book.isbn) {
        card.href = `./BookDetails.html?isbn=${encodeURIComponent(book.isbn)}`;
      } else {
        card.href = "#";
        card.addEventListener("click", (event) => event.preventDefault());
      }

      const authorNames = extractAuthorNames(book);
      card.dataset.title = book.title || "";
      card.dataset.authors = authorNames.join("|");

      card.appendChild(createCoverElement(book));

      const titleEl = document.createElement("h3");
      titleEl.textContent = book.title || "Untitled";
      card.appendChild(titleEl);

      const authorEl = document.createElement("p");
      authorEl.className = "book-authors";
      authorEl.textContent = authorNames.length
        ? authorNames.join(", ")
        : "Unknown author";
      card.appendChild(authorEl);

      track.appendChild(card);
    });
  } catch (error) {
    console.warn("Failed to load featured books:", error);
    track.innerHTML = `<p class="carousel-empty">Unable to load featured books right now.</p>`;
  }

  initCarousel();
}

function createCoverElement(book) {
  const cover = document.createElement("div");
  cover.className = "book-cover";

  const url = typeof book.coverImageUrl === "string" ? book.coverImageUrl.trim() : "";
  if (url) {
    const img = document.createElement("img");
    img.src = url;
    img.alt = `${book.title || "Book"} cover`;
    img.loading = "lazy";
    img.decoding = "async";
    cover.appendChild(img);
  } else {
    cover.classList.add("is-placeholder");
    cover.textContent = initialsFromTitle(book.title);
  }

  return cover;
}

function extractAuthorNames(book) {
  if (!book || !Array.isArray(book.authors)) return [];
  return book.authors
    .map((author) => {
      if (!author) return "";
      if (typeof author === "string") return author;
      if (typeof author.name === "string") return author.name;
      return "";
    })
    .map((name) => name.trim())
    .filter(Boolean);
}

function dedupeBooks(books) {
  if (!Array.isArray(books)) return [];
  const seen = new Set();
  const result = [];

  books.forEach((book) => {
    if (!book) return;
    const key = (book.bookId || book.isbn || (book.title ? book.title.toLowerCase() : null));
    if (!key) return;
    if (seen.has(key)) return;
    seen.add(key);
    result.push(book);
  });

  return result;
}

function initialsFromTitle(title) {
  if (!title || typeof title !== "string") return "BK";
  const words = title.trim().split(/\s+/).filter(Boolean);
  if (words.length === 0) return "BK";
  if (words.length === 1) return words[0].slice(0, 2).toUpperCase();
  const first = words[0][0];
  const last = words[words.length - 1][0];
  return `${first}${last}`.toUpperCase();
}

async function loadStats() {
  const defaults = collectDefaultStats();

  try {
    const response = await fetch("/api/stats", { headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();

    const values = {};
    for (const [key, fallback] of Object.entries(defaults)) {
      values[key] = numberOr(fallback, data?.[key]);
    }
    animateStats(values);
  } catch (error) {
    console.warn("Falling back to default stats:", error);
    animateStats(defaults);
  }
}

function collectDefaultStats() {
  const stats = {};
  document.querySelectorAll(".stat-number").forEach((el) => {
    const key = el.dataset.stat;
    if (key) {
      stats[key] = Number(el.dataset.count || 0);
    }
  });
  return stats;
}

function numberOr(fallback, value) {
  return typeof value === "number" && !Number.isNaN(value) ? value : fallback;
}

function animateStats(values) {
  document.querySelectorAll(".stat-number").forEach((el) => {
    const key = el.dataset.stat;
    const target = key && typeof values?.[key] === "number"
      ? values[key]
      : Number(el.dataset.count || 0);
    animateValue(el, target);
  });
}

function animateValue(el, target) {
  const safeTarget = Math.max(0, Math.floor(target));
  el.dataset.count = String(safeTarget);

  if (safeTarget === 0) {
    el.textContent = "0";
    return;
  }

  let current = 0;
  const increment = Math.max(1, Math.round(safeTarget / 60));

  const timer = setInterval(() => {
    current += increment;
    if (current >= safeTarget) {
      el.textContent = safeTarget.toLocaleString();
      clearInterval(timer);
    } else {
      el.textContent = current.toLocaleString();
    }
  }, 30);
}

function initCarousel() {
  const track = document.getElementById("carouselTrack");
  const btnPrev = document.getElementById("carouselPrev");
  const btnNext = document.getElementById("carouselNext");
  if (!track || !btnPrev || !btnNext) return;

  const cards = Array.from(track.querySelectorAll(".book-card"));
  const hasCards = cards.length > 0;

  btnPrev.disabled = !hasCards;
  btnNext.disabled = !hasCards;

  if (!hasCards) {
    if (track._autoSlide) {
      clearInterval(track._autoSlide);
      track._autoSlide = null;
    }
    return;
  }

  const defaultGap = 18;
  const calculateGap = () => {
    const style = window.getComputedStyle(track);
    const gapValue = parseFloat(style.columnGap || style.gap || defaultGap);
    return Number.isFinite(gapValue) ? gapValue : defaultGap;
  };

  const cardWidth = () => {
    const first = cards[0];
    if (!first) return 220;
    return first.getBoundingClientRect().width + calculateGap();
  };

  const move = (direction) => {
    track.scrollBy({ left: direction * cardWidth(), behavior: "smooth" });
  };

  btnPrev.onclick = () => move(-1);
  btnNext.onclick = () => move(1);

  if (track._autoSlide) {
    clearInterval(track._autoSlide);
  }
  track._autoSlide = setInterval(() => move(1), 6000);

  track.onmouseenter = () => {
    if (track._autoSlide) {
      clearInterval(track._autoSlide);
      track._autoSlide = null;
    }
  };
  track.onmouseleave = () => {
    if (!track._autoSlide) {
      track._autoSlide = setInterval(() => move(1), 6000);
    }
  };
}

function cycleTestimonials() {
  const quoteEl = document.getElementById("testimonialQuote");
  const nameEl = document.getElementById("testimonialName");
  if (!quoteEl || !nameEl || testimonials.length === 0) return;

  let index = 0;
  update();

  setInterval(() => {
    index = (index + 1) % testimonials.length;
    update();
  }, 7000);

  function update() {
    const { quote, name } = testimonials[index];
    quoteEl.textContent = quote;
    nameEl.textContent = name;
  }
}

function initSignupForm() {
  const form = document.getElementById("signupForm");
  const feedback = document.getElementById("signupFeedback");
  const emailInput = document.getElementById("signupEmail");
  if (!form || !feedback || !emailInput) return;

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    if (!emailInput.value.trim()) {
      feedback.textContent = "Please enter an email address.";
      feedback.style.color = "#ffe07a";
      return;
    }
    feedback.textContent = "Thanks! Check your inbox for the next reading list.";
    feedback.style.color = "#f6f9f2";
    form.reset();
  });
}
