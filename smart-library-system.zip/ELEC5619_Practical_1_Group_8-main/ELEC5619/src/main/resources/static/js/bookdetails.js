let currentBook = null;

document.addEventListener("DOMContentLoaded", async () => {
  const params = new URLSearchParams(location.search);
  const isbn = params.get("isbn");
  if (!isbn) return;

  try {
    const res = await fetch(`/bookdetails/isbn/${encodeURIComponent(isbn)}`);
    if (!res.ok) throw new Error("Failed to fetch book");
    const book = await res.json();
    currentBook = book;

    // Populate UI
    document.querySelector(".book-title-main").textContent = book.title;
    document.querySelector(".book-author-main").textContent =
      (book.authors || []).map(a => a.name).join(", ") || "—";

    if (book.coverImageUrl) {
      const cover = document.querySelector(".large-cover");
      cover.src = book.coverImageUrl;
      cover.alt = `${book.title} cover`;
    }

    document.querySelector(".blurb-content").textContent =
      book.blurb || "No summary provided.";

    setInfo("Genre", book.genre?.name);
    setInfo("Publication Date", book.publicationDate);
    setInfo("Publisher", book.publisher);
    setInfo("Total Copies", book.totalCopies);
    setInfo("Available Copies", book.availableCopies);

    // ✅ NEW: Fetch and display average rating
    await loadBookRating(book.bookId);

    const reserveBtn = document.querySelector("#reserveBtn");
    const avail = document.querySelector(".availability-status");

    if (role === "guest") {
      // Guest users cannot reserve — do not call checkBookAvailability
      avail.textContent = "Login to Reserve";
      avail.className = "availability-status login-required";
      reserveBtn.disabled = false;
      reserveBtn.textContent = "Login to Reserve";
      reserveBtn.addEventListener("click", () => {
        window.location.href = "./Login.html";
      });
    } else {
      // Logged-in users: check availability normally
      await checkBookAvailability(book.bookId, avail, reserveBtn);
      reserveBtn.addEventListener("click", handleReservation);
    }

    // Fetch related books
    const relRes = await fetch(`/bookdetails/isbn/${encodeURIComponent(isbn)}/related`);
    if (!relRes.ok) throw new Error("Failed to fetch related books");
    const related = await relRes.json();
    renderList(".related-genre", related.byGenre || []);
    renderList(".related-author", related.byAuthor || []);

  } catch (err) {
    console.error(err);
    alert("Error loading book details.");
  }
});

// ✅ NEW FUNCTION: Calculate and render average rating
async function loadBookRating(bookId) {
  const ratingStars = document.getElementById("overallRating");
  const ratingText = document.getElementById("ratingText");

  try {
    const response = await fetch(`/api/reviews/book/${bookId}`);
    if (!response.ok) throw new Error("Failed to load reviews");

    const reviews = await response.json();

    if (reviews.length === 0) {
      ratingStars.innerHTML = "☆☆☆☆☆";
      ratingText.textContent = "No ratings yet";
      return;
    }

    const totalReviews = reviews.length;
    const averageRating = reviews.reduce((sum, r) => sum + r.rating, 0) / totalReviews;
    const roundedRating = Math.round(averageRating * 10) / 10;

    ratingStars.innerHTML = "★".repeat(Math.floor(averageRating)) + "☆".repeat(5 - Math.floor(averageRating));
    ratingText.textContent = `${roundedRating} out of 5 stars (${totalReviews} review${totalReviews !== 1 ? "s" : ""})`;
  } catch (err) {
    console.error("Error loading reviews:", err);
    ratingStars.innerHTML = "☆☆☆☆☆";
    ratingText.textContent = "Error loading ratings";
  }
}

// helper to update info grid row
function setInfo(labelText, value) {
  document.querySelectorAll(".info-item").forEach(row => {
    const label = row.querySelector(".info-label");
    const val = row.querySelector(".info-value");
    if (label && val && label.textContent.trim().toLowerCase() === labelText.toLowerCase()) {
      val.textContent = value ?? "—";
    }
  });
}

function renderList(selector, books) {
  const container = document.querySelector(selector);
  if (!container) return;
  container.innerHTML = ""; // clear

  if (!books || books.length === 0) {
    const msg = document.createElement("p");
    msg.className = "empty-msg";
    msg.textContent = "No books found.";
    container.appendChild(msg);
    return;
  }

  books.forEach(b => {
    const card = document.createElement("article");
    card.className = "card";

    const authors = (b.authors && b.authors.length > 0)
      ? b.authors.map(a => a.name).join(", ")
      : "Unknown author";

    card.innerHTML = `
      <div class="icon">📘</div>
      <div>
        <div class="title">${b.title}</div>
        <div class="meta">
          <span>by ${authors}</span>
          <span>📅 ${b.publicationDate || ""}</span>
        </div>
      </div>
    `;

    // Make entire card clickable
    card.style.cursor = "pointer";
    card.addEventListener("click", () => {
      window.location.href = `./BookDetails.html?isbn=${encodeURIComponent(b.isbn)}`;
    });

    container.appendChild(card);
  });
}

// Check book availability for current user
async function checkBookAvailability(bookId, availElement, reserveBtn) {
  try {
    const response = await fetch(`/api/reservations/check-availability/${bookId}`);
    const result = await response.json();

    if (result.canReserve) {
      availElement.textContent = "Available Now";
      availElement.classList.add("available");
      reserveBtn.disabled = false;
    } else if (result.hasReservation) {
      availElement.textContent = "You have already reserved a copy of this book";
      availElement.classList.add("reserved");
      reserveBtn.disabled = true;
      reserveBtn.textContent = "✓ Reserved";
    } else {
      if (result.message === "Please log in to check availability") {
        availElement.textContent = "Login to check availability";
        availElement.classList.add("login-required");
        reserveBtn.disabled = true;
        reserveBtn.textContent = "Login to Reserve";
      } else {
        availElement.textContent = "📚 Not Available";
        availElement.classList.add("unavailable");
        reserveBtn.disabled = false;
        reserveBtn.textContent = "Join Waitlist";
        const newBtn = reserveBtn.cloneNode(true);
        reserveBtn.parentNode.replaceChild(newBtn, reserveBtn);
        newBtn.addEventListener("click", () => handleWaitlist(bookId));
      }
    }
  } catch (error) {
    console.error("Error checking availability:", error);
    availElement.textContent = "Error checking availability";
    availElement.classList.add("error");
    reserveBtn.disabled = true;
  }
}

// Handle book reservation
async function handleReservation() {
  if (!currentBook) {
    alert("Book information not loaded");
    return;
  }

  const reserveBtn = document.querySelector("#reserveBtn");
  const originalText = reserveBtn.textContent;

  try {
    reserveBtn.disabled = true;
    reserveBtn.textContent = "Reserving...";

    const response = await fetch("/api/reservations/reserve", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ bookId: currentBook.bookId })
    });

    const result = await response.json();

    if (result.success) {
      showNotification("Success!", `Book reserved successfully! Due date: ${result.endDate}`, "success");
      reserveBtn.textContent = "✓ Reserved";
      reserveBtn.classList.add("reserved");

      const avail = document.querySelector(".availability-status");
      avail.textContent = "Reserved by you";
      avail.classList.remove("available");
      avail.classList.add("reserved");

      setTimeout(() => {
        window.location.href = '/Reservation.html';
      }, 1500);
    } else {
      throw new Error(result.message);
    }
  } catch (error) {
    console.error("Reservation error:", error);
    showNotification("Error", error.message || "Failed to reserve book", "error");
    reserveBtn.disabled = false;
    reserveBtn.textContent = originalText;
  }
}

// Waitlist-related functions
async function handleWaitlist(bookId) {
  try {
    const response = await fetch("/api/waitlist/join", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ bookId })
    });

    const result = await response.json();
    if (result.success) {
      showNotification("Success!", "Added to waitlist!", "success");
      setTimeout(() => window.location.href = '/Reservation.html?tab=waitlist', 1500);
    } else throw new Error(result.message);
  } catch (error) {
    console.error("Waitlist error:", error);
    showNotification("Error", error.message || "Failed to join waitlist", "error");
  }
}

async function leaveWaitlist(bookId) {
  try {
    const response = await fetch("/api/waitlist/leave", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ bookId })
    });

    const result = await response.json();
    if (result.success) {
      showNotification("Success!", "Removed from waitlist", "success");
      location.reload();
    } else throw new Error(result.message);
  } catch (error) {
    console.error("Leave waitlist error:", error);
    showNotification("Error", error.message || "Failed to leave waitlist", "error");
  }
}

// Notifications
function showNotification(title, message, type = "info") {
  const notification = document.createElement("div");
  notification.className = `notification ${type}`;
  notification.innerHTML = `
    <div class="notification-content">
      <h4>${title}</h4>
      <p>${message}</p>
      <button class="notification-close">&times;</button>
    </div>
  `;
  document.body.appendChild(notification);

  notification.querySelector(".notification-close").addEventListener("click", () => notification.remove());
  setTimeout(() => notification.remove(), 5000);
}
