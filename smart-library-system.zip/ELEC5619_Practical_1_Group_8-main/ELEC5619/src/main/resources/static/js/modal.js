// Custom modal for better UX
function showModal(title, message, onConfirm) {
  // Create modal HTML
  const modal = document.createElement('div');
  modal.className = 'custom-modal';
  modal.innerHTML = `
    <div class="modal-overlay">
      <div class="modal-content">
        <h3>${title}</h3>
        <p>${message}</p>
        <div class="modal-buttons">
          <button class="btn-cancel">Cancel</button>
          <button class="btn-confirm">Confirm</button>
        </div>
      </div>
    </div>
  `;
  
  document.body.appendChild(modal);
  
  // Add event listeners
  modal.querySelector('.btn-cancel').addEventListener('click', () => {
    modal.remove();
  });
  
  modal.querySelector('.btn-confirm').addEventListener('click', () => {
    modal.remove();
    onConfirm();
  });
  
  // Close on overlay click
  modal.querySelector('.modal-overlay').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) {
      modal.remove();
    }
  });
}