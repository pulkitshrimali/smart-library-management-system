export const KEY_ROLE = "lh.role";
export const KEY_USER = "lh.user";
const NAVBAR_PATH = "./Navbar.html";

window.LibraryHubNavbarKeys = {
  KEY_ROLE,
  KEY_USER
};

/**
 * Attach the reusable navbar to a mount point.
 * @param {HTMLElement} mount
 */
export async function attachNavbar(mount) {
  if (!mount) return;
  const active = mount.dataset.navActive || null;

  try {
    const response = await fetch(NAVBAR_PATH, { cache: "no-cache" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const html = await response.text();
    const template = document.createElement("template");
    template.innerHTML = html.trim();

    const fragment = document.createDocumentFragment();
    template.content.childNodes.forEach((node) => {
      if (node.nodeType === Node.ELEMENT_NODE && node.tagName === "SCRIPT") {
        const script = document.createElement("script");
        if (node.type) script.type = node.type;
        if (node.src) {
          script.src = node.getAttribute("src");
        } else {
          script.textContent = node.textContent;
        }
        fragment.appendChild(script);
      } else {
        fragment.appendChild(node.cloneNode(true));
      }
    });

    if (typeof document !== "undefined") {
      if (active) {
        document.body.dataset.navActive = active;
      } else {
        delete document.body.dataset.navActive;
      }
    }
    mount.replaceWith(fragment);
  } catch (error) {
    console.error("Failed to load navbar:", error);
    mount.innerHTML = fallbackMarkup();
  }
}

function fallbackMarkup() {
  const active = (document.body?.dataset?.navActive || "").toLowerCase();
  const linkClass = (label) => `nav-link${active === label.toLowerCase() ? " active" : ""}`;
  return `
    <header class="navbar">
      <div class="nav-container">
        <div class="logo-section">
          <div class="logo">📚</div>
          <div class="site-name">LibraryHub</div>
        </div>
        <nav class="nav-menu">
          <a class="${linkClass("Home")}" href="./Home.html">Home</a>
          <a class="${linkClass("Browse")}" href="./GlobalSearch.html">Browse</a>
          <a class="${linkClass("Help")}" href="./Help.html">Help</a>
        </nav>
        <div class="nav-user-section">
          <a class="nav-link" href="./Login.html">Login</a>
          <a class="btn btn-primary" href="./SignUp.html">Sign Up</a>
        </div>
      </div>
    </header>
  `;
}

function autoAttach() {
  const mounts = document.querySelectorAll("[data-navbar]");
  mounts.forEach((mount) => {
    attachNavbar(mount);
  });
}

document.addEventListener("DOMContentLoaded", autoAttach);
