// Map API statuses to panels
const statusToPanel = (s='') => {
  const k = String(s).toLowerCase();
  if (['confirmed'].includes(k)) return 'active';
  if (['pending'].includes(k)) return 'upcoming';
  if (['completed','cancelled'].includes(k)) return 'past';
  if (['waitlist','queued','hold'].includes(k)) return 'waitlist';
  return 'active';
};

// Build one card (panel-aware)
const makeCard = (b, panelKey) => {
  // pill text + style
  let pillClass, pillLabel, btnClass, btnLabel, dateInfo;

  if (panelKey === 'past') {
     pillClass = 'returned';
     pillLabel = 'Returned';
     btnClass  = 'ghost';
     btnLabel  = 'View Details';
     dateInfo = '<div class="row"><b>Status:</b> Returned</div>';
   } else if (panelKey === 'active') {
     pillClass = 'picked';
     pillLabel = 'Checked Out';
     btnClass  = 'primary';
     btnLabel  = 'Return Early';
     dateInfo = `<div class="row"><b>Checked out:</b> ${b.checkedOutDate}</div><div class="row"><b>Due:</b> ${b.due}</div>`;
   } else if (panelKey === 'upcoming') {
     pillClass = 'ready';
     pillLabel = 'Ready for Pickup';
     btnClass  = 'ghost';
     btnLabel  = 'Cancel Reservation';
     const daysLeft = b.holdDaysLeft;
     const pickupLocation = b.libraryName ? `<div class="row"><b>Pick up at:</b> ${b.libraryName}</div>` : '';
     dateInfo = `<div class="row"><b>Hold expires in:</b> ${daysLeft} day${daysLeft !== 1 ? 's' : ''}</div>${pickupLocation}`;
   } else if (panelKey === 'waitlist') {
     pillClass = 'wait';
     pillLabel = 'On Waitlist';
     btnClass  = 'ghost';
     btnLabel  = 'Leave Waitlist';
     dateInfo = `<div class="row"><b>Position:</b> #${b.position || 1}</div>`;
   } else {
     pillClass = 'unknown';
     pillLabel = 'Pending';
     btnClass  = 'ghost';
     btnLabel  = 'Cancel';
     dateInfo = '<div class="row"><b>Status:</b> Pending</div>';
   }

  return `
    <article class="card fade-in">
      <div class="card-inner">
        <div class="cover"><img src="${b.cover}" alt="${b.title}"></div>
        <div>
          <h2 class="title">${b.title}</h2>
          <div class="meta"><div><strong>${b.author}</strong></div><div>${b.year}</div></div>
          ${dateInfo}
          <div class="actions">
            <span class="pill ${pillClass}">${pillLabel}</span>
          </div>
          <div class="actions">
            <button class="btn ${btnClass}" onclick="handleReservationAction('${b.reservationId}', '${btnLabel}', '${b.bookId || ''}')">${btnLabel}</button>
          </div>
        </div>
      </div>
    </article>
  `;
};


// Toggle tabs/panels
function activate(id){
  const btns   = document.querySelectorAll('.tab');
  const panels = document.querySelectorAll('.tab-panel');

  // If the requested tab is hidden (no items), pick the first visible tab
  const requestedBtn = document.querySelector(`.tab[data-tab="${id}"]`);
  if (!requestedBtn || requestedBtn.hidden) {
    const firstVisible = Array.from(btns).find(b => !b.hidden);
    id = firstVisible ? firstVisible.dataset.tab : id;
  }

  btns.forEach(b => {
    const on = b.dataset.tab === id && !b.hidden;
    b.classList.toggle('active', on);
    b.setAttribute('aria-selected', on ? 'true' : 'false');
    b.setAttribute('tabindex', on ? '0' : '-1');
  });

  panels.forEach(p => {
    const on = p.id === `panel-${id}` && !document.querySelector(`.tab[data-tab="${id}"]`)?.hidden;
    p.classList.toggle('show', on);
    p.hidden = !on;
  });
}

// Renders one group into its panel
function renderGroup(key, items){
  const panel = document.getElementById(`panel-${key}`);
  panel.innerHTML = items.map(item => makeCard(item, key)).join('');
}

// Updates counts and shows all tabs regardless of content
function updateCountsAndHide(groups){
  const labels = {active:'Checked Out', upcoming:'Ready for Pickup', past:'History', waitlist:'Waitlist'};
  Object.entries(labels).forEach(([key, label]) => {
    const btn   = document.querySelector(`.tab[data-tab="${key}"]`);
    const panel = document.getElementById(`panel-${key}`);
    const count = groups[key].length;

    // update number and show on button label
    if (btn) btn.textContent = `${label} (${count})`;

    // Always show all tabs
    if (btn) btn.hidden = false;
    if (panel) {
      panel.hidden = false;
      if (count === 0) {
        panel.innerHTML = '<div class="empty-state">No reservations in this category</div>';
      }
    }
  });
}

// Load all reservations and distribute by status
// preferredTab is optional (e.g., 'active', 'upcoming', 'past', 'waitlist')
async function loadReservations(preferredTab = 'active'){
  try {
    const [reservationsRes, waitlistRes] = await Promise.all([
      fetch('/api/reservations/user'),
      fetch('/api/waitlist/user')
    ]);
    
    if (!reservationsRes.ok) {
      if (reservationsRes.status === 401) {
        window.location.href = '/Login.html';
        return;
      }
      throw new Error('Failed to load reservations');
    }
    
    const reservationData = await reservationsRes.json();
    const waitlistData = waitlistRes.ok ? await waitlistRes.json() : [];
    
    // Transform reservation data
    const transformedReservations = reservationData.map(reservation => {
      const status = reservation.status.toLowerCase();
      let holdDaysLeft = 0;
      
      // Calculate days left for hold expiry
      if (status === 'pending' && reservation.holdExpiry) {
        const today = new Date();
        const holdExpiry = new Date(reservation.holdExpiry);
        holdDaysLeft = Math.max(0, Math.ceil((holdExpiry - today) / (1000 * 60 * 60 * 24)));
      }
      
      return {
        reservationId: reservation.reservationId,
        title: reservation.title || 'Unknown Title',
        author: reservation.author || 'Unknown Author',
        year: reservation.publicationYear || 'Unknown',
        cover: reservation.coverImageUrl || '/images/default-book.jpg',
        reservedFrom: reservation.startDate,
        reservedTo: reservation.endDate,
        due: reservation.endDate,
        checkedOutDate: reservation.startDate,
        holdDaysLeft: holdDaysLeft,
        libraryName: reservation.libraryName,
        status: status
      };
    });
    
    // Transform waitlist data
    const transformedWaitlist = waitlistData.map(waitlist => ({
      reservationId: waitlist.waitlistId,
      bookId: waitlist.bookId,
      title: waitlist.book?.title || 'Unknown Title',
      author: waitlist.book?.authors?.map(a => a.name).join(', ') || 'Unknown Author',
      year: waitlist.book?.publicationDate ? new Date(waitlist.book.publicationDate).getFullYear() : 'Unknown',
      cover: waitlist.book?.coverImageUrl || '/images/default-book.jpg',
      position: waitlist.position,
      status: 'waitlist'
    }));
    
    const groups = {active:[], upcoming:[], past:[], waitlist:[]};
    
    // bucket reservation items
    transformedReservations.forEach(item => {
      const key = statusToPanel(item.status);
      groups[key].push(item);
    });
    
    // add waitlist items
    groups.waitlist.push(...transformedWaitlist);
    
    // render
    renderGroup('active',   groups.active);
    renderGroup('upcoming', groups.upcoming);
    renderGroup('past',     groups.past);
    renderGroup('waitlist', groups.waitlist);
    
    // hide empty tabs, update counts, then activate the right one
    updateCountsAndHide(groups);
    activate(preferredTab);
    
  } catch (error) {
    console.error('Error loading reservations:', error);
    // Fallback to mock data
    const res = await fetch('./mocks/reservation-data.json');
    const data = await res.json();

    const groups = {active:[], upcoming:[], past:[], waitlist:[]};

    // bucket items
    data.forEach(item => {
      const key = statusToPanel(item.status);
      groups[key].push(item);
    });

    // render
    renderGroup('active',   groups.active);
    renderGroup('upcoming', groups.upcoming);
    renderGroup('past',     groups.past);
    renderGroup('waitlist', groups.waitlist);

    // hide empty tabs, update counts, then activate the right one
    updateCountsAndHide(groups);
    activate(preferredTab);
  }
}

// Init tabs & load data
document.addEventListener('DOMContentLoaded', () => {
  // tab click behavior
  document.querySelectorAll('.tab').forEach(b => {
    b.addEventListener('click', () => activate(b.dataset.tab));
  });

  // Check URL parameter for preferred tab
  const urlParams = new URLSearchParams(window.location.search);
  const preferredTab = urlParams.get('tab') || 'active';
  
  // load everything; start on preferred tab
  loadReservations(preferredTab);
});

// Handle reservation actions (cancel, return, etc.)
async function handleReservationAction(reservationId, action, bookId = '') {
  if (action === 'Cancel Reservation') {
    showModal(
      'Cancel Reservation',
      'Are you sure you want to cancel this reservation? This action cannot be undone.',
      async () => {
    
        try {
          const response = await fetch(`/api/reservations/cancel/${reservationId}`, {
            method: 'POST'
          });
          
          const result = await response.json();
          
          if (result.success) {
            showNotification('Success', 'Reservation cancelled successfully', 'success');
            // Reload reservations to update the display
            loadReservations('upcoming');
          } else {
            showNotification('Error', result.message, 'error');
          }
        } catch (error) {
          console.error('Error cancelling reservation:', error);
          showNotification('Error', 'Failed to cancel reservation', 'error');
        }
      }
    );
  } else if (action === 'Leave Waitlist') {
    showModal(
      'Leave Waitlist',
      'Are you sure you want to leave the waitlist for this book?',
      async () => {
        try {
          const response = await fetch('/api/waitlist/leave', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ bookId: bookId })
          });
          
          const result = await response.json();
          
          if (result.success) {
            showNotification('Success', 'Removed from waitlist successfully', 'success');
            loadReservations('waitlist');
          } else {
            showNotification('Error', result.message, 'error');
          }
        } catch (error) {
          console.error('Error leaving waitlist:', error);
          showNotification('Error', 'Failed to leave waitlist', 'error');
        }
      }
    );
  }
}

// Show confirmation modal
function showModal(title, message, onConfirm) {
  const modal = document.createElement('div');
  modal.className = 'modal-overlay';
  modal.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
  `;
  modal.innerHTML = `
    <div class="modal" style="
      background: white;
      padding: 2rem;
      border-radius: 8px;
      max-width: 400px;
      width: 90%;
      box-shadow: 0 4px 20px rgba(0,0,0,0.15);
    ">
      <h3 style="margin-top: 0;">${title}</h3>
      <p>${message}</p>
      <div class="modal-actions" style="
        display: flex;
        gap: 1rem;
        justify-content: flex-end;
        margin-top: 1.5rem;
      ">
        <button class="btn ghost" onclick="this.closest('.modal-overlay').remove()" style="
          padding: 0.5rem 1rem;
          border: 1px solid #ccc;
          background: white;
          border-radius: 4px;
          cursor: pointer;
        ">Cancel</button>
        <button class="btn primary" id="confirmBtn" style="
          padding: 0.5rem 1rem;
          background: #007bff;
          color: white;
          border: none;
          border-radius: 4px;
          cursor: pointer;
        ">Confirm</button>
      </div>
    </div>
  `;
  
  document.body.appendChild(modal);
  
  modal.querySelector('#confirmBtn').addEventListener('click', () => {
    modal.remove();
    onConfirm();
  });
}

// Show notification
function showNotification(title, message, type = 'info') {
  const notification = document.createElement('div');
  notification.className = `notification ${type}`;
  notification.innerHTML = `
    <div class="notification-content">
      <h4>${title}</h4>
      <p>${message}</p>
      <button class="notification-close">&times;</button>
    </div>
  `;
  
  document.body.appendChild(notification);
  
  notification.querySelector('.notification-close').addEventListener('click', () => {
    notification.remove();
  });
  
  setTimeout(() => {
    if (notification.parentNode) {
      notification.remove();
    }
  }, 5000);
}