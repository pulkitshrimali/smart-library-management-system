class AllReviewsManager {
  constructor() {
    this.currentIsbn = null;
    this.currentBookId = null;
    this.currentUser = null;
    this.isAdmin = false;
    this.init();
  }

  async init() {
    this.getIsbnFromUrl();
    await this.checkUserSession();
    this.loadBookInfo();
  }

  async checkUserSession() {
    try {
      const response = await fetch('/auth/me');
      if (response.ok) {
        const data = await response.json();
        if (data.status === 'ok') {
          this.currentUser = data.user;
          this.isAdmin = data.user.role === 'ADMIN';
        }
      }
    } catch (error) {
      console.log('User not logged in');
      this.isAdmin = false;
    }
  }

  getIsbnFromUrl() {
    const params = new URLSearchParams(window.location.search);
    this.currentIsbn = params.get('isbn');
  }

  async loadBookInfo() {
    if (!this.currentIsbn) {
      document.getElementById('bookTitle').textContent = 'All Reviews';
      document.getElementById('allReviewsList').innerHTML = '<p>No book specified.</p>';
      return;
    }

    try {
      const response = await fetch(`/bookdetails/isbn/${encodeURIComponent(this.currentIsbn)}`);
      if (!response.ok) throw new Error('Failed to fetch book data');
      
      const book = await response.json();
      this.currentBookId = book.bookId;
      
      document.getElementById('bookTitle').textContent = `All Reviews for "${book.title}"`;
      
      // Load reviews immediately after getting book info
      await this.loadAllReviews();
    } catch (error) {
      console.error('Error loading book info:', error);
      document.getElementById('bookTitle').textContent = 'Error Loading Book';
      document.getElementById('allReviewsList').innerHTML = '<p>Error loading book information.</p>';
    }
  }

  async loadAllReviews() {
    if (!this.currentBookId) {
      document.getElementById('allReviewsList').innerHTML = '<p>Book ID not found.</p>';
      return;
    }

    try {
      const response = await fetch(`/api/reviews/book/${this.currentBookId}`);
      if (!response.ok) throw new Error('Failed to load reviews');
      
      const reviews = await response.json();
      this.displayAllReviews(reviews);
      this.updateReviewsSummary(reviews);
    } catch (error) {
      console.error('Error loading reviews:', error);
      document.getElementById('allReviewsList').innerHTML = '<p>Error loading reviews.</p>';
    }
  }

  displayAllReviews(reviews) {
    const container = document.getElementById('allReviewsList');
    
    if (reviews.length === 0) {
      container.innerHTML = '<p class="no-reviews">No reviews yet for this book.</p>';
      return;
    }

    container.innerHTML = reviews.map(review => `
      <div class="review-card" data-review-id="${review.reviewId}">
        <div class="reviewer-header">
          <div class="reviewer-name">${review.userName || 'Unknown User'}</div>
          <div class="review-stars">${'★'.repeat(review.rating)}${'☆'.repeat(5 - review.rating)}</div>
        </div>
        <div class="review-text">${this.escapeHtml(review.reviewText || 'No comment provided.')}</div>
        <div class="review-footer">
          <div class="review-date">${new Date(review.createdAt).toLocaleDateString()}</div>
          <div class="review-actions">
            <button class="reply-btn" onclick="window.location.href='Review.html?id=${review.reviewId}'">💬 Comment</button>
            ${this.isAdmin ? `<button class="delete-btn" onclick="allReviewsManager.deleteReview('${review.reviewId}')">🗑️ Delete</button>` : ''}
          </div>
        </div>
      </div>
    `).join('');
  }

  async deleteReview(reviewId) {
    if (!this.isAdmin) {
      alert('Unauthorized: Admin access required');
      return;
    }

    if (!confirm('Are you sure you want to delete this review?')) {
      return;
    }

    try {
      const response = await fetch(`/api/reviews/${reviewId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        // Remove the review card from DOM
        const reviewCard = document.querySelector(`[data-review-id="${reviewId}"]`);
        if (reviewCard) {
          reviewCard.remove();
        }
        // Reload reviews to update summary
        await this.loadAllReviews();
      } else if (response.status === 403) {
        alert('Unauthorized: Admin access required');
      } else {
        alert('Failed to delete review');
      }
    } catch (error) {
      console.error('Error deleting review:', error);
      alert('Error deleting review');
    }
  }

  updateReviewsSummary(reviews) {
    if (reviews.length === 0) {
      document.getElementById('totalReviews').textContent = 'No reviews yet';
      document.getElementById('overallRating').textContent = '☆☆☆☆☆';
      document.getElementById('ratingText').textContent = 'No ratings yet';
      return;
    }

    const totalReviews = reviews.length;
    const averageRating = reviews.reduce((sum, review) => sum + review.rating, 0) / totalReviews;
    const roundedRating = Math.round(averageRating * 10) / 10;

    document.getElementById('totalReviews').textContent = `${totalReviews} review${totalReviews !== 1 ? 's' : ''}`;
    document.getElementById('overallRating').innerHTML = '★'.repeat(Math.floor(averageRating)) + '☆'.repeat(5 - Math.floor(averageRating));
    document.getElementById('ratingText').textContent = `${roundedRating} out of 5 stars`;
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}

// Initialize when DOM is ready
let allReviewsManager;
document.addEventListener('DOMContentLoaded', () => {
  allReviewsManager = new AllReviewsManager();
});