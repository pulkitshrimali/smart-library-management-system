const KEY_ROLE = "lh.role";
const KEY_USER = "lh.user";

const btn = document.getElementById("logoutBtn");
if (btn) {
  btn.addEventListener("click", () => {
    try {
      localStorage.removeItem(KEY_ROLE);
      localStorage.removeItem(KEY_USER);
    } catch (err) {
      console.warn("Failed to clear stored session", err);
    }
    openDialog({
      type: 'success',
      message: 'Successfully logged out. See ya next time!',
      redirect: 'Login.html',
      autoCloseMs: 2000
    });
  });
}
