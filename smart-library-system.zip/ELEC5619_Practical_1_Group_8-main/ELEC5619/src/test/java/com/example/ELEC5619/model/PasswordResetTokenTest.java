package com.example.ELEC5619.model;

import com.example.ELEC5619.Model.PasswordResetToken;
import org.junit.jupiter.api.Test;
import java.time.OffsetDateTime;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class PasswordResetTokenTest {

    @Test
    void testGettersAndSetters() {
        PasswordResetToken token = new PasswordResetToken();
        UUID id = UUID.randomUUID();
        UUID userId = UUID.randomUUID();
        OffsetDateTime expiresAt = OffsetDateTime.now().plusHours(1);
        
        token.setId(id);
        token.setUserId(userId);
        token.setToken("reset-token-123");
        token.setExpiresAt(expiresAt);
        token.setUsed(true);
        
        assertEquals(id, token.getId());
        assertEquals(userId, token.getUserId());
        assertEquals("reset-token-123", token.getToken());
        assertEquals(expiresAt, token.getExpiresAt());
        assertTrue(token.isUsed());
    }
}