package com.example.ELEC5619.service;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.ELEC5619.Model.Book;
import com.example.ELEC5619.Repository.BookRepository;
import com.example.ELEC5619.Service.BookService;

@ExtendWith(MockitoExtension.class)
class BookServiceTest {

    @Mock
    private BookRepository bookRepository;

    @InjectMocks
    private BookService bookService;

    private Book testBook;

    @BeforeEach
    void setUp() {
        // Initialise a test book object for use in all test cases
        testBook = new Book();
        testBook.setBookId(UUID.randomUUID());
        testBook.setTitle("Test Book");
        testBook.setIsbn("978-0123456789");
        testBook.setPublicationDate(LocalDate.of(2020, 1, 1));
        testBook.setTotalCopies(5);
        testBook.setAvailableCopies(3);
    }

    /**
     * Tests that getAllBooks() returns all books from the repository.
     */
    @Test
    void getAllBooks_ShouldReturnAllBooks() {
        List<Book> mockBooks = Arrays.asList(testBook);
        when(bookRepository.findAll()).thenReturn(mockBooks);

        List<Book> result = bookService.getAllBooks();

        assertEquals(1, result.size());
        assertEquals(testBook, result.get(0));
        verify(bookRepository).findAll();
    }

    /**
     * Tests that searchBooks() with a query string
     * calls the repository with the query pattern.
     */
    @Test
    void searchBooks_WithQuery_ShouldCallRepositoryWithPattern() {
        String query = "test";
        List<Book> mockBooks = Arrays.asList(testBook);
        when(bookRepository.searchBooks(eq("%test%"), isNull(), isNull(), isNull(), isNull(), isNull()))
                .thenReturn(mockBooks);

        List<Book> result = bookService.searchBooks(query, null, null, null, null);

        assertEquals(1, result.size());
        verify(bookRepository).searchBooks("%test%", null, null, null, null, null);
    }

    /**
     * Tests that searchBooks() with a filter for books published
     * on or before 1950 sets the correct end date for the query.
     */
    @Test
    void searchBooks_WithYearFilter_1950_ShouldSetEndDate() {
        List<Book> mockBooks = Arrays.asList(testBook);
        when(bookRepository.searchBooks(isNull(), isNull(), isNull(), isNull(), isNull(), eq(LocalDate.of(1950, 12, 31))))
                .thenReturn(mockBooks);

        List<Book> result = bookService.searchBooks(null, null, null, null, "<=1950");

        assertEquals(1, result.size());
        verify(bookRepository).searchBooks(null, null, null, null, null, LocalDate.of(1950, 12, 31));
    }

    /**
     * Tests that searchBooks() with a filter for books published
     * between 1951 and 2000 sets the correct start and end dates.
     */
    @Test
    void searchBooks_WithYearFilter_1951_2000_ShouldSetDateRange() {
        List<Book> mockBooks = Arrays.asList(testBook);
        when(bookRepository.searchBooks(isNull(), isNull(), isNull(), isNull(),
                eq(LocalDate.of(1951, 1, 1)), eq(LocalDate.of(2000, 12, 31))))
                .thenReturn(mockBooks);

        List<Book> result = bookService.searchBooks(null, null, null, null, "1951-2000");

        assertEquals(1, result.size());
        verify(bookRepository).searchBooks(null, null, null, null,
                LocalDate.of(1951, 1, 1), LocalDate.of(2000, 12, 31));
    }

    /**
     * Tests that searchBooks() with a filter for books published after 2000
     * sets the correct start date for the query.
     */
    @Test
    void searchBooks_WithYearFilter_After2000_ShouldSetStartDate() {
        List<Book> mockBooks = Arrays.asList(testBook);
        when(bookRepository.searchBooks(isNull(), isNull(), isNull(), isNull(), eq(LocalDate.of(2001, 1, 1)), isNull()))
                .thenReturn(mockBooks);

        List<Book> result = bookService.searchBooks(null, null, null, null, ">2000");

        assertEquals(1, result.size());
        verify(bookRepository).searchBooks(null, null, null, null, LocalDate.of(2001, 1, 1), null);
    }

    /**
     * Tests that searchBooks() with all filters provided
     * passes the correct parameters to the repository.
     */
    @Test
    void searchBooks_WithAllFilters_ShouldPassAllParameters() {
        List<Book> mockBooks = Arrays.asList(testBook);
        when(bookRepository.searchBooks(eq("%java%"), eq("available"), eq("Programming"), isNull(), isNull(), isNull()))
                .thenReturn(mockBooks);

        List<Book> result = bookService.searchBooks("java", "available", "Programming", null, null);

        assertEquals(1, result.size());
        verify(bookRepository).searchBooks("%java%", "available", "Programming", null, null, null);
    }

    /**
     * Tests that searchBooks() with an empty query
     * passes null as the search pattern to the repository.
     */
    @Test
    void searchBooks_WithEmptyQuery_ShouldPassNullPattern() {
        List<Book> mockBooks = Arrays.asList(testBook);
        when(bookRepository.searchBooks(isNull(), isNull(), isNull(), isNull(), isNull(), isNull()))
                .thenReturn(mockBooks);

        List<Book> result = bookService.searchBooks("", null, null, null, null);

        assertEquals(1, result.size());
        verify(bookRepository).searchBooks(null, null, null, null, null, null);
    }
}