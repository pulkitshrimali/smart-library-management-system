package com.example.ELEC5619.model;

import com.example.ELEC5619.Model.Book;
import com.example.ELEC5619.Model.Author;
import com.example.ELEC5619.Model.Genre;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class BookTest {

    private Book book;
    private UUID testBookId;

    @BeforeEach
    void setUp() {
        book = new Book();
        testBookId = UUID.randomUUID();
    }

    @Test
    void setAndGetBookId_ShouldWorkCorrectly() {
        // When
        book.setBookId(testBookId);

        // Then
        assertEquals(testBookId, book.getBookId());
    }

    @Test
    void setAndGetTitle_ShouldWorkCorrectly() {
        // Given
        String title = "The Great Gatsby";

        // When
        book.setTitle(title);

        // Then
        assertEquals(title, book.getTitle());
    }

    @Test
    void setAndGetIsbn_ShouldWorkCorrectly() {
        // Given
        String isbn = "978-0123456789";

        // When
        book.setIsbn(isbn);

        // Then
        assertEquals(isbn, book.getIsbn());
    }

    @Test
    void setAndGetBlurb_ShouldWorkCorrectly() {
        // Given
        String blurb = "A classic American novel";

        // When
        book.setBlurb(blurb);

        // Then
        assertEquals(blurb, book.getBlurb());
    }

    @Test
    void setAndGetPublicationDate_ShouldWorkCorrectly() {
        // Given
        LocalDate date = LocalDate.of(1925, 4, 10);

        // When
        book.setPublicationDate(date);

        // Then
        assertEquals(date, book.getPublicationDate());
    }

    @Test
    void setAndGetPublisher_ShouldWorkCorrectly() {
        // Given
        String publisher = "Scribner";

        // When
        book.setPublisher(publisher);

        // Then
        assertEquals(publisher, book.getPublisher());
    }

    @Test
    void setAndGetTotalCopies_ShouldWorkCorrectly() {
        // Given
        Integer totalCopies = 10;

        // When
        book.setTotalCopies(totalCopies);

        // Then
        assertEquals(totalCopies, book.getTotalCopies());
    }

    @Test
    void setAndGetAvailableCopies_ShouldWorkCorrectly() {
        // Given
        Integer availableCopies = 5;

        // When
        book.setAvailableCopies(availableCopies);

        // Then
        assertEquals(availableCopies, book.getAvailableCopies());
    }

    @Test
    void setAndGetCoverImageUrl_ShouldWorkCorrectly() {
        // Given
        String imageUrl = "https://example.com/cover.jpg";

        // When
        book.setCoverImageUrl(imageUrl);

        // Then
        assertEquals(imageUrl, book.getCoverImageUrl());
    }

    @Test
    void setAndGetAuthors_ShouldWorkCorrectly() {
        // Given
        Author author1 = new Author();
        author1.setName("F. Scott Fitzgerald");
        Author author2 = new Author();
        author2.setName("Co-Author");

        // When
        book.setAuthors(Arrays.asList(author1, author2));

        // Then
        assertEquals(2, book.getAuthors().size());
        assertEquals("F. Scott Fitzgerald", book.getAuthors().get(0).getName());
    }

    @Test
    void setAndGetGenre_ShouldWorkCorrectly() {
        // Given
        Genre genre = new Genre();
        genre.setName("Fiction");

        // When
        book.setGenre(genre);

        // Then
        assertEquals(genre, book.getGenre());
        assertEquals("Fiction", book.getGenre().getName());
    }

    @Test
    void bookCreation_WithAllFields_ShouldSetCorrectly() {
        // Given
        UUID bookId = UUID.randomUUID();
        String title = "Test Book";
        String isbn = "978-0123456789";
        String blurb = "Test blurb";
        LocalDate pubDate = LocalDate.of(2020, 1, 1);
        String publisher = "Test Publisher";
        Integer totalCopies = 10;
        Integer availableCopies = 7;
        String coverUrl = "https://example.com/cover.jpg";

        // When
        book.setBookId(bookId);
        book.setTitle(title);
        book.setIsbn(isbn);
        book.setBlurb(blurb);
        book.setPublicationDate(pubDate);
        book.setPublisher(publisher);
        book.setTotalCopies(totalCopies);
        book.setAvailableCopies(availableCopies);
        book.setCoverImageUrl(coverUrl);

        // Then
        assertEquals(bookId, book.getBookId());
        assertEquals(title, book.getTitle());
        assertEquals(isbn, book.getIsbn());
        assertEquals(blurb, book.getBlurb());
        assertEquals(pubDate, book.getPublicationDate());
        assertEquals(publisher, book.getPublisher());
        assertEquals(totalCopies, book.getTotalCopies());
        assertEquals(availableCopies, book.getAvailableCopies());
        assertEquals(coverUrl, book.getCoverImageUrl());
    }
}