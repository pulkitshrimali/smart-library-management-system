package com.example.ELEC5619.model;

import com.example.ELEC5619.Model.Library;
import org.junit.jupiter.api.Test;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class LibraryTest {

    @Test
    void testGettersAndSetters() {
        Library library = new Library();
        UUID libraryId = UUID.randomUUID();
        
        library.setLibraryId(libraryId);
        library.setName("Central Library");
        library.setAddress("123 Main St");
        library.setPhoneNumber("555-0123");
        library.setEmail("info@library.com");
        
        assertEquals(libraryId, library.getLibraryId());
        assertEquals("Central Library", library.getName());
        assertEquals("123 Main St", library.getAddress());
        assertEquals("555-0123", library.getPhoneNumber());
        assertEquals("info@library.com", library.getEmail());
    }
}