package com.example.ELEC5619.service;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.ELEC5619.Model.ReviewComment;
import com.example.ELEC5619.Repository.ReviewCommentRepository;
import com.example.ELEC5619.Service.ReviewCommentService;
import com.example.ELEC5619.DTO.CommentWithUserDTO;

@ExtendWith(MockitoExtension.class)
class ReviewCommentServiceTest {

    @Mock
    private ReviewCommentRepository repository;

    @InjectMocks
    private ReviewCommentService service;

    private ReviewComment testComment;
    private CommentWithUserDTO testCommentDTO;
    private UUID testReviewId;
    private UUID testCommentId;
    private UUID testUserId;

    @BeforeEach
    void setUp() {
        // Initialise test data for each test case
        testReviewId = UUID.randomUUID();
        testCommentId = UUID.randomUUID();
        testUserId = UUID.randomUUID();
        
        testComment = new ReviewComment();
        testComment.setCommentId(testCommentId);
        testComment.setReviewId(testReviewId);
        testComment.setUserId(testUserId);
        testComment.setMessage("Great review!");
        testComment.setCreatedAt(LocalDateTime.now());
        
        testCommentDTO = new CommentWithUserDTO(
            testCommentId, testReviewId, testUserId, "Test User",
            null, "Great review!", LocalDateTime.now(), LocalDateTime.now()
        );
    }

    /**
     * Tests that getCommentsByReview() retrieves all comments associated with a given review,
     * ordered by creation time in ascending order.
     */
    @Test
    void getCommentsByReview_ShouldReturnCommentsList() {
        List<CommentWithUserDTO> mockComments = Arrays.asList(testCommentDTO);
        when(repository.findCommentsWithUserByReviewId(testReviewId)).thenReturn(mockComments);

        List<CommentWithUserDTO> result = service.getCommentsByReview(testReviewId);

        assertEquals(1, result.size());
        assertEquals(testCommentDTO.getCommentId(), result.get(0).getCommentId());
        verify(repository).findCommentsWithUserByReviewId(testReviewId);
    }

    /**
     * Tests that getRepliesByComment() retrieves all replies to a given comment,
     * ordered by creation time in ascending order.
     */
    @Test
    void getRepliesByComment_ShouldReturnRepliesList() {
        UUID parentId = UUID.randomUUID();
        ReviewComment reply = new ReviewComment();
        reply.setParentId(parentId);
        reply.setMessage("Reply to comment");
        
        List<ReviewComment> mockReplies = Arrays.asList(reply);
        when(repository.findByParentIdOrderByCreatedAtAsc(parentId)).thenReturn(mockReplies);

        List<ReviewComment> result = service.getRepliesByComment(parentId);

        assertEquals(1, result.size());
        assertEquals(reply, result.get(0));
        verify(repository).findByParentIdOrderByCreatedAtAsc(parentId);
    }

    /**
     * Tests that addComment() saves a new comment to the repository
     * and returns the saved comment object.
     */
    @Test
    void addComment_ShouldSaveAndReturnComment() {
        when(repository.save(any(ReviewComment.class))).thenReturn(testComment);

        ReviewComment result = service.addComment(testComment);

        assertEquals(testComment, result);
        verify(repository).save(testComment);
    }

    /**
     * Tests that deleteComment() calls the repository's deleteById() method
     * to remove a comment by its ID.
     */
    @Test
    void deleteComment_ShouldCallRepositoryDelete() {
        service.deleteComment(testCommentId);

        verify(repository).deleteById(testCommentId);
    }
}