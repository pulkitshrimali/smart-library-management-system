package com.example.ELEC5619.service;

import jakarta.annotation.Resource;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import com.example.ELEC5619.Service.EmailService;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;

/**
 * Unit test for {@link EmailService} verifying the default "from" address behaviour.
 * <p>
 * This test checks that when the {@code spring.mail.from} property is blank,
 * the {@link EmailService} correctly falls back to its built-in default sender address.
 */
@SuppressWarnings("removal")
@SpringJUnitConfig
@Import(EmailService.class)
@TestPropertySource(properties = "spring.mail.from=") // blank to trigger fallback
class EmailServiceDefaultTest {

    /** Mocked mail sender used to intercept outgoing emails. */
    @MockBean
    private JavaMailSender mailSender;

    /** Injected {@link EmailService} under test. */
    @Resource
    private EmailService emailService;

    /**
     * Tests that the {@link EmailService#send(String, String, String)} method uses
     * the default "from" address when the configured property {@code spring.mail.from}
     * is blank.
     * <p>
     * The test:
     * <ul>
     *   <li>Invokes {@code emailService.send(...)} with recipient, subject, and body.</li>
     *   <li>Captures the {@link SimpleMailMessage} sent through the mock mail sender.</li>
     *   <li>Asserts that:
     *     <ul>
     *       <li>The "from" field equals the default {@code Library.hub@example.com}.</li>
     *       <li>The "to", "subject", and "text" fields match the provided inputs.</li>
     *     </ul>
     *   </li>
     * </ul>
     */
    @Test
    void send_usesDefaultWhenPropertyBlank() {
        emailService.send("user@example.com", "S", "T");

        ArgumentCaptor<SimpleMailMessage> captor = ArgumentCaptor.forClass(SimpleMailMessage.class);
        verify(mailSender).send(captor.capture());

        SimpleMailMessage sent = captor.getValue();
        assertThat(sent.getFrom()).isEqualTo("Library.hub@example.com");
        assertThat(sent.getTo()).containsExactly("user@example.com");
        assertThat(sent.getSubject()).isEqualTo("S");
        assertThat(sent.getText()).isEqualTo("T");
    }
}
