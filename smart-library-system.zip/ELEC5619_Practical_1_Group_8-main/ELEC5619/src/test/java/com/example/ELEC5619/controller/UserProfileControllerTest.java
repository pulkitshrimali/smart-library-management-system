package com.example.ELEC5619.controller;

import com.example.ELEC5619.Model.User;
import com.example.ELEC5619.Repository.UserRepository;
import com.example.ELEC5619.Controller.UserProfileController;
import jakarta.servlet.http.Cookie;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Optional;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Unit tests for {@link UserProfileController}.
 * <p>
 * These tests verify the behavior of the user profile endpoints, including:
 * <ul>
 *   <li>Retrieving profile information via <code>GET /profile</code></li>
 *   <li>Updating user details via <code>PUT /profile</code></li>
 * </ul>
 * The tests use a mocked {@link UserRepository} and do not access a real database.
 */
@SuppressWarnings("removal")
@WebMvcTest(UserProfileController.class)
class UserProfileControllerTest {

    /** MockMvc used to perform simulated HTTP requests in tests. */
    @Autowired
    private MockMvc mockMvc;

    /** Mocked repository for user persistence operations. */
    @MockBean
    private UserRepository users;

    /** Sample user object reused across test cases. */
    private User user;

    /** Unique user ID for the mock user. */
    private UUID uid;

    /**
     * Initializes reusable mock user data before each test execution.
     * <p>
     * Creates a test user with valid attributes including name, email,
     * role, creation time, and birth date.
     */
    @BeforeEach
    void setUp() {
        uid = UUID.randomUUID();
        user = new User();
        user.setUserId(uid);
        user.setName("Alice");
        user.setEmail("alice@example.com");
        user.setRole("USER");
        // Removed: user.setNotificationPreferences(...)  (notifications no longer used)
        user.setPhoneNumber("0412345678"); // optional, controller can return it
        user.setCreatedAt(OffsetDateTime.now());
        user.setBirthDate(LocalDate.of(1998, 5, 14));
    }

    /**
     * Verifies that when no cookie is provided in the <code>GET /profile</code> request,
     * the controller responds with an error body indicating the user is not logged in.
     *
     * @throws Exception if the mock request fails
     */
    @Test
    void getProfile_withoutCookie_returns401Body() throws Exception {
        mockMvc.perform(get("/profile"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("error"))
                .andExpect(jsonPath("$.code").value(401))
                .andExpect(jsonPath("$.message").value("Not logged in"));
    }

    /**
     * Verifies that when the email from the cookie does not match any user record,
     * the controller responds with a 404-style JSON error.
     *
     * @throws Exception if the mock request fails
     */
    @Test
    void getProfile_userNotFound_returns404Body() throws Exception {
        when(users.findByEmailIgnoreCase("ghost@example.com")).thenReturn(Optional.empty());

        mockMvc.perform(get("/profile").cookie(new Cookie("userEmail", "ghost@example.com")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("error"))
                .andExpect(jsonPath("$.code").value(404))
                .andExpect(jsonPath("$.message").value("User not found"));
    }

    /**
     * Verifies that a valid cookie retrieves an existing user successfully,
     * returning a JSON response containing all profile fields.
     *
     * @throws Exception if the mock request fails
     */
    @Test
    void getProfile_success_returnsUser() throws Exception {
        when(users.findByEmailIgnoreCase("alice@example.com")).thenReturn(Optional.of(user));

        mockMvc.perform(get("/profile").cookie(new Cookie("userEmail", "alice@example.com")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("ok"))
                .andExpect(jsonPath("$.user.userId").value(uid.toString()))
                .andExpect(jsonPath("$.user.email").value("alice@example.com"))
                .andExpect(jsonPath("$.user.name").value("Alice"))
                .andExpect(jsonPath("$.user.role").value("USER"))
                .andExpect(jsonPath("$.user.birthDate").value("1998-05-14"));
    }

    /**
     * Verifies that submitting an invalid email address in the profile update request
     * (<code>PUT /profile</code>) results in a 400 Bad Request response.
     *
     * @throws Exception if the mock request fails
     */
    @Test
    void updateProfile_invalidEmail_returns400() throws Exception {
        String body = """
          {"email":"bad","phone":"0412345678","birth":"1998-05-14"}
        """;
        mockMvc.perform(put("/profile")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("Invalid email"));
    }

    /**
     * Verifies that an invalid phone number format in the update request
     * triggers a 400 Bad Request with the correct message.
     *
     * @throws Exception if the mock request fails
     */
    @Test
    void updateProfile_invalidPhone_returns400() throws Exception {
        String body = """
          {"email":"alice@example.com","phone":"12345","birth":"1998-05-14"}
        """;
        mockMvc.perform(put("/profile")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("Invalid phone number"));
    }

    /**
     * Verifies that a malformed birth date format in the update request
     * results in a 400 Bad Request response.
     *
     * @throws Exception if the mock request fails
     */
    @Test
    void updateProfile_invalidBirth_returns400() throws Exception {
        String body = """
          {"email":"alice@example.com","phone":"0412345678","birth":"14-05-1998"}
        """;
        mockMvc.perform(put("/profile")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("Invalid birth date"));
    }

    /**
     * Verifies that attempting to update a user that does not exist
     * returns a 404 Not Found response with the appropriate message.
     *
     * @throws Exception if the mock request fails
     */
    @Test
    void updateProfile_userNotFound_returns404() throws Exception {
        when(users.findByEmailIgnoreCase("alice@example.com")).thenReturn(Optional.empty());

        String body = """
          {"email":"alice@example.com","phone":"0412345678","birth":"1998-05-14"}
        """;
        mockMvc.perform(put("/profile")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isNotFound())
                .andExpect(content().string("User not found"));
    }

    /**
     * Verifies that a valid update request successfully updates user details
     * and returns a 200 OK response with a success message.
     *
     * @throws Exception if the mock request fails
     */
    @Test
    void updateProfile_success_updatesAndReturnsOk() throws Exception {
        when(users.findByEmailIgnoreCase("alice@example.com")).thenReturn(Optional.of(user));
        when(users.save(any(User.class))).thenAnswer(inv -> inv.getArgument(0));

        String body = """
          {"email":"alice@example.com","phone":"0411111111","birth":"1999-01-02"}
        """;

        mockMvc.perform(put("/profile")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Profile updated successfully"));
    }
}
