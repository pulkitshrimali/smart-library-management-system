package com.example.ELEC5619.controller;

import com.example.ELEC5619.Controller.WaitlistController;
import com.example.ELEC5619.Model.Library;
import com.example.ELEC5619.Model.User;
import com.example.ELEC5619.Model.Waitlist;
import com.example.ELEC5619.Repository.BookRepository;
import com.example.ELEC5619.Repository.LibraryRepository;
import com.example.ELEC5619.Repository.UserRepository;
import com.example.ELEC5619.Service.EmailService;
import com.example.ELEC5619.Service.WaitlistService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(WaitlistController.class)
class WaitlistControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private WaitlistService waitlistService;

    @MockBean
    private UserRepository userRepository;

    @MockBean
    private LibraryRepository libraryRepository;

    @MockBean
    private BookRepository bookRepository;

    @MockBean
    private EmailService emailService;

    @Autowired
    private ObjectMapper objectMapper;

    private User testUser;
    private Waitlist testWaitlist;
    private UUID bookId;
    private UUID libraryId;

    @BeforeEach
    void setUp() {
        // Initialise test data for each test case
        testUser = new User();
        testUser.setUserId(UUID.randomUUID());
        testUser.setEmail("test@example.com");

        bookId = UUID.randomUUID();
        libraryId = UUID.randomUUID();

        testWaitlist = new Waitlist();
        testWaitlist.setWaitlistId(UUID.randomUUID());
        testWaitlist.setUserId(testUser.getUserId());
        testWaitlist.setBookId(bookId);
        testWaitlist.setLibraryId(libraryId);
        testWaitlist.setPosition(1);
    }

    /**
     * Tests successful joining of a waitlist when user is authenticated and library exists
     */
    @Test
    void testJoinWaitlistSuccess() throws Exception {
        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        when(libraryRepository.findFirst()).thenReturn(Optional.of(createMockLibrary()));
        when(waitlistService.joinWaitlist(any(), any(), any())).thenReturn(testWaitlist);

        Map<String, String> request = Map.of("bookId", bookId.toString());

        mockMvc.perform(post("/api/waitlist/join")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));

        verify(waitlistService).joinWaitlist(any(), any(), any());
    }

    /**
     * Tests that joining waitlist returns unauthorized when user is not logged in
     */
    @Test
    void testJoinWaitlistNotLoggedIn() throws Exception {
        Map<String, String> request = Map.of("bookId", bookId.toString());

        mockMvc.perform(post("/api/waitlist/join")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.success").value(false));
    }

    /**
     * Tests successful leaving of a waitlist when user is authenticated and on the waitlist
     */
    @Test
    void testLeaveWaitlistSuccess() throws Exception {
        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        when(waitlistService.getUserWaitlistEntry(any(), any())).thenReturn(Optional.of(testWaitlist));
        doNothing().when(waitlistService).leaveWaitlist(any(), any());

        Map<String, String> request = Map.of("bookId", bookId.toString());

        mockMvc.perform(post("/api/waitlist/leave")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));

        verify(waitlistService).leaveWaitlist(any(), any());
    }

    /**
     * Tests getting waitlist status for a book when user is on the waitlist
     */
    @Test
    void testGetWaitlistStatus() throws Exception {
        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        when(waitlistService.getWaitlistCount(bookId)).thenReturn(5L);
        when(waitlistService.getUserWaitlistEntry(testUser.getUserId(), bookId)).thenReturn(Optional.of(testWaitlist));

        mockMvc.perform(get("/api/waitlist/status/" + bookId)
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.onWaitlist").value(true))
                .andExpect(jsonPath("$.position").value(1));

        verify(waitlistService).getWaitlistCount(bookId);
        verify(waitlistService).getUserWaitlistEntry(testUser.getUserId(), bookId);
    }

    /**
     * Tests getting all waitlist entries for an authenticated user
     */
    @Test
    void testGetUserWaitlist() throws Exception {
        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        when(waitlistService.getUserWaitlistWithBooks(testUser.getUserId())).thenReturn(Arrays.asList(testWaitlist));

        mockMvc.perform(get("/api/waitlist/user")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray());

        verify(waitlistService).getUserWaitlistWithBooks(testUser.getUserId());
    }

    /**
     * Tests that getting user waitlist returns unauthorized when user is not logged in
     */
    @Test
    void testGetUserWaitlistNotLoggedIn() throws Exception {
        mockMvc.perform(get("/api/waitlist/user"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Not logged in"));
    }

    /**
     * Tests that leaving waitlist triggers position update notifications for affected users
     */
    @Test
    void testLeaveWaitlistWithPositionUpdates() throws Exception {
        User affectedUser = new User();
        affectedUser.setUserId(UUID.randomUUID());
        affectedUser.setEmail("affected@example.com");
        
        Waitlist affectedWaitlist = new Waitlist();
        affectedWaitlist.setUserId(affectedUser.getUserId());
        affectedWaitlist.setPosition(2);
        
        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        when(userRepository.findById(affectedUser.getUserId())).thenReturn(Optional.of(affectedUser));
        when(waitlistService.getUserWaitlistEntry(testUser.getUserId(), bookId)).thenReturn(Optional.of(testWaitlist));
        when(waitlistService.getBookWaitlist(bookId)).thenReturn(Arrays.asList(affectedWaitlist));
        when(bookRepository.findById(bookId)).thenReturn(Optional.of(createMockBook()));
        doNothing().when(waitlistService).leaveWaitlist(any(), any());
        doNothing().when(emailService).send(anyString(), anyString(), anyString());

        Map<String, String> request = Map.of("bookId", bookId.toString());

        mockMvc.perform(post("/api/waitlist/leave")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));

        verify(waitlistService).leaveWaitlist(testUser.getUserId(), bookId);
    }

    /**
     * Tests leaving waitlist when affected user is not found in database
     */
    @Test
    void testLeaveWaitlistWithUserNotFound() throws Exception {
        UUID missingUserId = UUID.randomUUID();
        Waitlist affectedWaitlist = new Waitlist();
        affectedWaitlist.setUserId(missingUserId);
        affectedWaitlist.setPosition(2);
        
        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        when(userRepository.findById(missingUserId)).thenReturn(Optional.empty());
        when(waitlistService.getUserWaitlistEntry(testUser.getUserId(), bookId)).thenReturn(Optional.of(testWaitlist));
        when(waitlistService.getBookWaitlist(bookId)).thenReturn(Arrays.asList(affectedWaitlist));
        when(bookRepository.findById(bookId)).thenReturn(Optional.of(createMockBook()));
        doNothing().when(waitlistService).leaveWaitlist(any(), any());

        Map<String, String> request = Map.of("bookId", bookId.toString());

        mockMvc.perform(post("/api/waitlist/leave")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    /**
     * Tests leaving waitlist when affected user has no email address
     */
    @Test
    void testLeaveWaitlistWithUserNoEmail() throws Exception {
        User userWithoutEmail = new User();
        userWithoutEmail.setUserId(UUID.randomUUID());
        userWithoutEmail.setEmail(null);
        
        Waitlist affectedWaitlist = new Waitlist();
        affectedWaitlist.setUserId(userWithoutEmail.getUserId());
        affectedWaitlist.setPosition(2);
        
        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        when(userRepository.findById(userWithoutEmail.getUserId())).thenReturn(Optional.of(userWithoutEmail));
        when(waitlistService.getUserWaitlistEntry(testUser.getUserId(), bookId)).thenReturn(Optional.of(testWaitlist));
        when(waitlistService.getBookWaitlist(bookId)).thenReturn(Arrays.asList(affectedWaitlist));
        when(bookRepository.findById(bookId)).thenReturn(Optional.of(createMockBook()));
        doNothing().when(waitlistService).leaveWaitlist(any(), any());

        Map<String, String> request = Map.of("bookId", bookId.toString());

        mockMvc.perform(post("/api/waitlist/leave")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    /**
     * Tests leaving waitlist when email notification fails for affected users
     */
    @Test
    void testLeaveWaitlistEmailException() throws Exception {
        User affectedUser = new User();
        affectedUser.setUserId(UUID.randomUUID());
        affectedUser.setEmail("affected@example.com");
        
        Waitlist affectedWaitlist = new Waitlist();
        affectedWaitlist.setUserId(affectedUser.getUserId());
        affectedWaitlist.setPosition(2);
        
        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        when(userRepository.findById(affectedUser.getUserId())).thenReturn(Optional.of(affectedUser));
        when(waitlistService.getUserWaitlistEntry(testUser.getUserId(), bookId)).thenReturn(Optional.of(testWaitlist));
        when(waitlistService.getBookWaitlist(bookId)).thenReturn(Arrays.asList(affectedWaitlist));
        when(bookRepository.findById(bookId)).thenReturn(Optional.of(createMockBook()));
        doNothing().when(waitlistService).leaveWaitlist(any(), any());
        doThrow(new RuntimeException("Email failed")).when(emailService).send(eq("affected@example.com"), anyString(), anyString());

        Map<String, String> request = Map.of("bookId", bookId.toString());

        mockMvc.perform(post("/api/waitlist/leave")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    /**
     * Tests that joining waitlist handles database exceptions gracefully
     */
    @Test
    void testJoinWaitlistUserNotFoundThrowsRuntimeException() throws Exception {
        // Mock that repository throws RuntimeException inside joinWaitlist()
        when(userRepository.findByEmailIgnoreCase("test@example.com"))
            .thenThrow(new RuntimeException("Database failure"));

        Map<String, String> request = Map.of("bookId", bookId.toString());

        mockMvc.perform(post("/api/waitlist/join")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Database failure"));
    }

    /**
     * Tests that leaving waitlist handles runtime exceptions gracefully
     */
    @Test
    void testLeaveWaitlistRuntimeException() throws Exception {
        when(userRepository.findByEmailIgnoreCase("test@example.com"))
            .thenThrow(new RuntimeException("Unexpected error"));

        Map<String, String> request = Map.of("bookId", bookId.toString());

        mockMvc.perform(post("/api/waitlist/leave")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Unexpected error"));
    }

    /**
     * Tests that getting waitlist status handles service exceptions gracefully
     */
    @Test
    void testGetWaitlistStatusException() throws Exception {
        when(waitlistService.getWaitlistCount(bookId))
            .thenThrow(new RuntimeException("Service unavailable"));

        mockMvc.perform(get("/api/waitlist/status/" + bookId)
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("Error checking waitlist status"));
    }

    /**
     * Tests that getting user waitlist handles database fetch exceptions gracefully
     */
    @Test
    void testGetUserWaitlistRuntimeException() throws Exception {
        when(userRepository.findByEmailIgnoreCase("test@example.com"))
            .thenReturn(Optional.of(testUser));
        when(waitlistService.getUserWaitlistWithBooks(testUser.getUserId()))
            .thenThrow(new RuntimeException("DB fetch failed"));

        mockMvc.perform(get("/api/waitlist/user")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("DB fetch failed"));
    }
    /**
     * Tests that leaving waitlist sends position update emails to affected users
     */
    @Test
    void testLeaveWaitlistSendsPositionUpdateEmails() throws Exception {
        when(userRepository.findByEmailIgnoreCase("test@example.com"))
            .thenReturn(Optional.of(testUser));
        
        Waitlist leavingUserWaitlist = new Waitlist();
        leavingUserWaitlist.setUserId(testUser.getUserId());
        leavingUserWaitlist.setBookId(bookId);
        leavingUserWaitlist.setPosition(2);

        when(waitlistService.getUserWaitlistEntry(testUser.getUserId(), bookId))
            .thenReturn(Optional.of(leavingUserWaitlist));

        // Mock getBookWaitlist() to return users after the leaving position
        Waitlist w1 = new Waitlist();
        w1.setUserId(UUID.randomUUID());
        w1.setBookId(bookId);
        w1.setPosition(2);

        Waitlist w2 = new Waitlist();
        w2.setUserId(UUID.randomUUID());
        w2.setBookId(bookId);
        w2.setPosition(3);

        List<Waitlist> updatedList = List.of(w1, w2);

        when(waitlistService.getBookWaitlist(bookId)).thenReturn(updatedList);

        // Mock userRepository.findById() for those affected users
        User u1 = new User();
        u1.setUserId(w1.getUserId());
        u1.setEmail("affected1@example.com");

        User u2 = new User();
        u2.setUserId(w2.getUserId());
        u2.setEmail("affected2@example.com");

        when(userRepository.findById(w1.getUserId())).thenReturn(Optional.of(u1));
        when(userRepository.findById(w2.getUserId())).thenReturn(Optional.of(u2));

        // Spy on emailService to verify send() was called
        doNothing().when(emailService).send(anyString(), anyString(), anyString());

        Map<String, String> request = Map.of("bookId", bookId.toString());

        mockMvc.perform(post("/api/waitlist/leave")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));

        // Give the background thread some time to run
        Thread.sleep(500);

        verify(emailService, atLeastOnce()).send(
            anyString(),
            eq("Waitlist Position Update"),
            contains("Your position for")
        );
    }

    /**
     * Tests that joining waitlist returns error when user is not found
     */
    @Test
    void testJoinWaitlistUserNotFound() throws Exception {
        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.empty());
        Map<String, String> request = Map.of("bookId", bookId.toString());

        mockMvc.perform(post("/api/waitlist/join")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("User not found"));
    }

    /**
     * Tests that joining waitlist returns error when no library is found
     */
    @Test
    void testJoinWaitlistNoLibraryFound() throws Exception {
        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        when(libraryRepository.findFirst()).thenReturn(Optional.empty());

        Map<String, String> request = Map.of("bookId", bookId.toString());

        mockMvc.perform(post("/api/waitlist/join")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("No library found"));
    }

    /**
     * Tests that joining waitlist handles service exceptions gracefully
     */
    @Test
    void testJoinWaitlistServiceThrowsException() throws Exception {
        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        when(libraryRepository.findFirst()).thenReturn(Optional.of(createMockLibrary()));
        when(waitlistService.joinWaitlist(any(), any(), any())).thenThrow(new RuntimeException("Join failed"));

        Map<String, String> request = Map.of("bookId", bookId.toString());

        mockMvc.perform(post("/api/waitlist/join")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Join failed"));
    }

    /**
     * Tests getting waitlist status when user is not found in database
     */
    @Test
    void testGetWaitlistStatusUserNotOnWaitlist() throws Exception {
        when(waitlistService.getWaitlistCount(bookId)).thenReturn(3L);
        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/waitlist/status/" + bookId)
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.onWaitlist").value(false))
                .andExpect(jsonPath("$.totalWaiting").value(3));
    }

    /**
     * Tests getting waitlist status when no user authentication cookie is provided
     */
    @Test
    void testGetWaitlistStatusNoCookie() throws Exception {
        when(waitlistService.getWaitlistCount(bookId)).thenReturn(5L);

        mockMvc.perform(get("/api/waitlist/status/" + bookId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.onWaitlist").value(false))
                .andExpect(jsonPath("$.totalWaiting").value(5));
    }

    /**
     * Tests getting waitlist status when user is not on the specific books waitlist
     */
    @Test
    void testGetWaitlistStatusUserNotOnBookWaitlist() throws Exception {
        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        when(waitlistService.getWaitlistCount(bookId)).thenReturn(7L);
        when(waitlistService.getUserWaitlistEntry(testUser.getUserId(), bookId)).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/waitlist/status/" + bookId)
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.onWaitlist").value(false))
                .andExpect(jsonPath("$.totalWaiting").value(7));
    }

    /**
     * Creates a mock Book object for testing purposes.
     * @return Book object with test data
     */
    private com.example.ELEC5619.Model.Book createMockBook() {
        com.example.ELEC5619.Model.Book book = new com.example.ELEC5619.Model.Book();
        book.setBookId(bookId);
        book.setTitle("Test Book");
        return book;
    }

    /**
     * Tests getUserWaitlist when service returns empty list
     */
    @Test
    void testGetUserWaitlistEmptyList() throws Exception {
        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        when(waitlistService.getUserWaitlistWithBooks(testUser.getUserId())).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/waitlist/user")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$").isEmpty());
    }

    /**
     * Tests leaveWaitlist when book is not found (covers lambda$leaveWaitlist$6)
     */
    @Test
    void testLeaveWaitlistBookNotFound() throws Exception {
        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        when(waitlistService.getUserWaitlistEntry(testUser.getUserId(), bookId)).thenReturn(Optional.of(testWaitlist));
        when(bookRepository.findById(bookId)).thenReturn(Optional.empty());
        doNothing().when(waitlistService).leaveWaitlist(any(), any());

        Map<String, String> request = Map.of("bookId", bookId.toString());

        mockMvc.perform(post("/api/waitlist/leave")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@example.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    /**
     * Creates a mock Library object for testing purposes.
     * @return Library object with test data
     */
    private Library createMockLibrary() {
        Library library = new Library();
        library.setLibraryId(libraryId);
        library.setName("Test Library");
        return library;
    }
}