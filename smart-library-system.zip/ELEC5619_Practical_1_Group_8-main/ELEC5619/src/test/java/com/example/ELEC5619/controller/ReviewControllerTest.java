package com.example.ELEC5619.controller;

import com.example.ELEC5619.Controller.ReviewController;
import com.example.ELEC5619.Model.Review;
import com.example.ELEC5619.Model.User;
import com.example.ELEC5619.Service.ReviewService;
import com.example.ELEC5619.Repository.UserRepository;

import jakarta.servlet.http.Cookie;
import java.util.Optional;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ReviewController.class)
class ReviewControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ReviewService reviewService;
    
    @MockBean
    private UserRepository userRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private Review testReview;
    private UUID testBookId;
    private UUID testReviewId;
    private UUID testUserId;
    private User testUser;

    @BeforeEach
    void setUp() {
        testBookId = UUID.randomUUID();
        testReviewId = UUID.randomUUID();
        testUserId = UUID.randomUUID();

        testReview = new Review();
        testReview.setReviewId(testReviewId);
        testReview.setBookId(testBookId);
        testReview.setUserId(testUserId);
        testReview.setRating(4);
        testReview.setReviewText("Great book!");
        testReview.setCreatedAt(LocalDateTime.now());
        testReview.setUserName("John Doe");
        
        testUser = new User();
        testUser.setUserId(testUserId);
        testUser.setEmail("test@example.com");
        testUser.setName("Test User");
    }

    /**
     * Test retrieving reviews for a specific book
     * Should return a list of reviews with user names
     */
    @Test
    void getReviewsByBook_ShouldReturnReviewsList() throws Exception {
        List<Review> reviews = Arrays.asList(testReview);
        when(reviewService.getReviewsByBook(testBookId)).thenReturn(reviews);

        mockMvc.perform(get("/api/reviews/book/{bookId}", testBookId))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[0].reviewId").value(testReviewId.toString()))
                .andExpect(jsonPath("$[0].rating").value(4))
                .andExpect(jsonPath("$[0].reviewText").value("Great book!"))
                .andExpect(jsonPath("$[0].userName").value("John Doe"));

        verify(reviewService).getReviewsByBook(testBookId);
    }

    /**
     * Test retrieving a review by its ID
     * Should return the review object with the correct fields
     */
    @Test
    void getReviewById_ShouldReturnReview() throws Exception {
        when(reviewService.getReviewById(testReviewId)).thenReturn(testReview);

        mockMvc.perform(get("/api/reviews/{reviewId}", testReviewId))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.reviewId").value(testReviewId.toString()))
                .andExpect(jsonPath("$.rating").value(4))
                .andExpect(jsonPath("$.reviewText").value("Great book!"));

        verify(reviewService).getReviewById(testReviewId);
    }

    /**
     * Test adding a new review
     * Should create and return the review object
     */
    @Test
    void addReview_ShouldCreateAndReturnReview() throws Exception {
        when(reviewService.addReview(any(Review.class))).thenReturn(testReview);

        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        
        mockMvc.perform(post("/api/reviews")
                .cookie(new Cookie("userEmail", "test@example.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testReview)))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.reviewId").value(testReviewId.toString()))
                .andExpect(jsonPath("$.rating").value(4));

        verify(reviewService).addReview(any(Review.class));
    }

    /**
     * Test updating an existing review
     * Should return the updated review object
     */
    @Test
    void updateReview_ShouldUpdateAndReturnReview() throws Exception {
        Review updatedReview = new Review();
        updatedReview.setRating(5);
        updatedReview.setReviewText("Amazing book!");

        when(reviewService.updateReview(eq(testReviewId), any(Review.class), eq(testUserId))).thenReturn(testReview);

        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        
        mockMvc.perform(put("/api/reviews/{reviewId}", testReviewId)
                .cookie(new Cookie("userEmail", "test@example.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updatedReview)))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON));

        verify(reviewService).updateReview(eq(testReviewId), any(Review.class), eq(testUserId));
    }

    /**
     * Test deleting a review by its ID (admin only)
     * Should call the service delete method and return OK
     */
    @Test
    void deleteReview_ShouldDeleteReview() throws Exception {
        testUser.setRole("ADMIN"); // Set user as admin
        doNothing().when(reviewService).deleteReviewAsAdmin(testReviewId);

        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        
        mockMvc.perform(delete("/api/reviews/{reviewId}", testReviewId)
                .cookie(new Cookie("userEmail", "test@example.com")))
                .andExpect(status().isOk());

        verify(reviewService).deleteReviewAsAdmin(testReviewId);
    }

    @Test
    void addReview_ShouldReturn401_WhenNotAuthenticated() throws Exception {
        mockMvc.perform(post("/api/reviews")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testReview)))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void addReview_ShouldReturn400_WhenServiceThrowsException() throws Exception {
        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        when(reviewService.addReview(any(Review.class))).thenThrow(new RuntimeException("Service error"));
        
        mockMvc.perform(post("/api/reviews")
                .cookie(new Cookie("userEmail", "test@example.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testReview)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void updateReview_ShouldReturn401_WhenNotAuthenticated() throws Exception {
        mockMvc.perform(put("/api/reviews/{reviewId}", testReviewId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testReview)))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void updateReview_ShouldReturn400_WhenServiceThrowsException() throws Exception {
        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        when(reviewService.updateReview(eq(testReviewId), any(Review.class), eq(testUserId)))
            .thenThrow(new RuntimeException("Service error"));
        
        mockMvc.perform(put("/api/reviews/{reviewId}", testReviewId)
                .cookie(new Cookie("userEmail", "test@example.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testReview)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void deleteReview_ShouldReturn401_WhenNotAuthenticated() throws Exception {
        mockMvc.perform(delete("/api/reviews/{reviewId}", testReviewId))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void deleteReview_ShouldReturn403_WhenNotAdmin() throws Exception {
        testUser.setRole("USER"); // Regular user, not admin
        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        
        mockMvc.perform(delete("/api/reviews/{reviewId}", testReviewId)
                .cookie(new Cookie("userEmail", "test@example.com")))
                .andExpect(status().isForbidden());
    }

    @Test
    void deleteReview_ShouldReturn400_WhenServiceThrowsException() throws Exception {
        testUser.setRole("ADMIN"); // Set user as admin
        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        doThrow(new RuntimeException("Service error")).when(reviewService).deleteReviewAsAdmin(testReviewId);
        
        mockMvc.perform(delete("/api/reviews/{reviewId}", testReviewId)
                .cookie(new Cookie("userEmail", "test@example.com")))
                .andExpect(status().isBadRequest());
    }
}