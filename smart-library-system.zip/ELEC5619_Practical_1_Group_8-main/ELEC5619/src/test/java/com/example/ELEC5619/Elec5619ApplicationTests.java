package com.example.ELEC5619;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Elec5619ApplicationTests {

	@Test
	void contextLoads() {
	}

}
