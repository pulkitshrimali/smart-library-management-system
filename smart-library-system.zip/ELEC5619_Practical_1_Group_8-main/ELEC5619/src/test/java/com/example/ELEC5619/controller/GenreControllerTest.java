package com.example.ELEC5619.controller;

import com.example.ELEC5619.Controller.GenreController;
import com.example.ELEC5619.Model.Genre;
import com.example.ELEC5619.Service.GenreService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.UUID;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(GenreController.class)
class GenreControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private GenreService genreService;

    @Test
    void getAllGenres_Success() throws Exception {
        Genre genre = new Genre();
        genre.setGenreId(UUID.randomUUID());
        genre.setName("Fiction");
        
        when(genreService.getAllGenres()).thenReturn(Arrays.asList(genre));

        mockMvc.perform(get("/genres"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$[0].name").value("Fiction"));
    }
}