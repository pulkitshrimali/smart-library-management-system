package com.example.ELEC5619.controller;

import com.example.ELEC5619.Controller.ReviewCommentController;
import com.example.ELEC5619.Model.ReviewComment;
import com.example.ELEC5619.Model.User;
import com.example.ELEC5619.Service.ReviewCommentService;
import com.example.ELEC5619.DTO.CommentWithUserDTO;
import com.example.ELEC5619.Repository.UserRepository;

import jakarta.servlet.http.Cookie;
import java.util.Optional;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ReviewCommentController.class)
class ReviewCommentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ReviewCommentService service;
    
    @MockBean
    private UserRepository userRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private ReviewComment testComment;
    private CommentWithUserDTO testCommentDTO;
    private UUID testReviewId;
    private UUID testCommentId;
    private UUID testUserId;
    private User testUser;

    @BeforeEach
    void setUp() {
        testReviewId = UUID.randomUUID();
        testCommentId = UUID.randomUUID();
        testUserId = UUID.randomUUID();

        testComment = new ReviewComment();
        testComment.setCommentId(testCommentId);
        testComment.setReviewId(testReviewId);
        testComment.setUserId(testUserId);
        testComment.setMessage("Great review!");
        testComment.setCreatedAt(LocalDateTime.now());
        
        testCommentDTO = new CommentWithUserDTO(
            testCommentId, testReviewId, testUserId, "Test User", 
            null, "Great review!", LocalDateTime.now(), LocalDateTime.now()
        );
        
        testUser = new User();
        testUser.setUserId(testUserId);
        testUser.setEmail("test@example.com");
        testUser.setName("Test User");
    }

    /**
     * Test retrieving comments for a review
     * Should return a list of comments with correct fields
     */
    @Test
    void getComments_ShouldReturnCommentsList() throws Exception {
        List<CommentWithUserDTO> comments = Arrays.asList(testCommentDTO);
        when(service.getCommentsByReview(testReviewId)).thenReturn(comments);

        mockMvc.perform(get("/api/reviews/{reviewId}/comments", testReviewId))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[0].commentId").value(testCommentId.toString()))
                .andExpect(jsonPath("$[0].message").value("Great review!"));

        verify(service).getCommentsByReview(testReviewId);
    }

    /**
     * Test retrieving replies for a comment
     * Should return a list of replies for the parent comment
     */
    @Test
    void getReplies_ShouldReturnRepliesList() throws Exception {
        UUID parentId = UUID.randomUUID();
        ReviewComment reply = new ReviewComment();
        reply.setParentId(parentId);
        reply.setMessage("Reply message");

        List<ReviewComment> replies = Arrays.asList(reply);
        when(service.getRepliesByComment(parentId)).thenReturn(replies);

        mockMvc.perform(get("/api/reviews/{reviewId}/comments/{commentId}/replies", testReviewId, parentId))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[0].message").value("Reply message"));

        verify(service).getRepliesByComment(parentId);
    }

    /**
     * Test adding a new comment to a review
     * Should create and return the comment object
     */
    @Test
    void addComment_ShouldCreateAndReturnComment() throws Exception {
        ReviewComment newComment = new ReviewComment();
        newComment.setMessage("New comment");
        newComment.setUserId(UUID.randomUUID());

        when(service.addComment(any(ReviewComment.class))).thenReturn(testComment);

        when(userRepository.findByEmailIgnoreCase("test@example.com")).thenReturn(Optional.of(testUser));
        
        mockMvc.perform(post("/api/reviews/{reviewId}/comments", testReviewId)
                .cookie(new Cookie("userEmail", "test@example.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(newComment)))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.commentId").value(testCommentId.toString()));

        verify(service).addComment(any(ReviewComment.class));
    }

    /**
     * Test deleting a comment by its ID
     * Should call service delete method and return OK
     */
    @Test
    void deleteComment_ShouldDeleteComment() throws Exception {
        doNothing().when(service).deleteComment(testCommentId);

        mockMvc.perform(delete("/api/reviews/{reviewId}/comments/{commentId}", testReviewId, testCommentId))
                .andExpect(status().isOk());

        verify(service).deleteComment(testCommentId);
    }
}