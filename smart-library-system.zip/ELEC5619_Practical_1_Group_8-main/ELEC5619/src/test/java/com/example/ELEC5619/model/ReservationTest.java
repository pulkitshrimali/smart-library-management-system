package com.example.ELEC5619.model;

import com.example.ELEC5619.Model.Reservation;
import com.example.ELEC5619.Model.ReservationStatus;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class ReservationTest {

    @Test
    void testGetStartDate() {
        Reservation reservation = new Reservation();
        LocalDate startDate = LocalDate.now();
        reservation.setStartDate(startDate);
        assertEquals(startDate, reservation.getStartDate());
    }
}