package com.example.ELEC5619.service;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.ELEC5619.Model.Book;
import com.example.ELEC5619.Model.BookCopy;
import com.example.ELEC5619.Model.Reservation;
import com.example.ELEC5619.Model.ReservationStatus;
import com.example.ELEC5619.Model.ReservationWithBook;
import com.example.ELEC5619.Repository.BookCopyRepository;
import com.example.ELEC5619.Repository.BookRepository;
import com.example.ELEC5619.Repository.ReservationRepository;
import com.example.ELEC5619.Repository.UserRepository;
import com.example.ELEC5619.Service.EmailService;
import com.example.ELEC5619.Service.ReservationService;
import com.example.ELEC5619.Model.User;

@ExtendWith(MockitoExtension.class)
class ReservationServiceTest {

    @Mock
    private ReservationRepository reservationRepository;
    
    @Mock
    private BookCopyRepository bookCopyRepository;
    
    @Mock
    private BookRepository bookRepository;
    
    @Mock
    private EmailService emailService;
    
    @Mock
    private com.example.ELEC5619.Service.WaitlistService waitlistService;
    
    @Mock
    private UserRepository userRepository;
    
    @InjectMocks
    private ReservationService reservationService;
    
    private UUID userId;
    private UUID bookId;
    private UUID copyId;
    private UUID reservationId;
    private BookCopy bookCopy;
    private Reservation reservation;

    @BeforeEach
    void setUp() {
        // Initialise test data for each test case
        userId = UUID.randomUUID();
        bookId = UUID.randomUUID();
        copyId = UUID.randomUUID();
        reservationId = UUID.randomUUID();
        
        bookCopy = new BookCopy();
        bookCopy.setCopyId(copyId);
        bookCopy.setBookId(bookId);
        
        reservation = new Reservation();
        reservation.setReservationId(reservationId);
        reservation.setUserId(userId);
        reservation.setCopyId(copyId);
        reservation.setStartDate(LocalDate.now());
        reservation.setEndDate(LocalDate.now().plusDays(14));
        reservation.setStatus(ReservationStatus.PENDING);
    }

    /**
     * Tests that createReservation() successfully creates a reservation
     * when the user has no active reservations and copies are available.
     */
    @Test
    void createReservation_Success() {
        when(reservationRepository.hasActiveReservationForBook(userId, bookId)).thenReturn(false);
        when(bookCopyRepository.findFirstAvailableCopyByBookId(bookId)).thenReturn(Optional.of(bookCopy));
        when(bookRepository.findById(bookId)).thenReturn(Optional.of(new Book()));
        
        Reservation result = reservationService.createReservation(userId, bookId, "test@demo.com");
        
        assertNotNull(result);
        assertEquals(userId, result.getUserId());
        assertEquals(copyId, result.getCopyId());
        assertEquals(ReservationStatus.PENDING, result.getStatus());
        verify(bookCopyRepository).updateCopyStatusWithCast(copyId, "RESERVED");
        verify(bookRepository).decrementAvailableCopies(bookId);
        verify(reservationRepository).insertReservationWithCast(any(), eq(userId), eq(copyId), any(), any(), eq("PENDING"), any(), any());
    }

    /**
     * Tests that createReservation() throws an exception
     * if the user already has an active reservation for the same book.
     */
    @Test
    void createReservation_AlreadyHasActiveReservation() {
        when(reservationRepository.hasActiveReservationForBook(userId, bookId)).thenReturn(true);
        
        RuntimeException exception = assertThrows(RuntimeException.class, 
            () -> reservationService.createReservation(userId, bookId, "test@demo.com"));
        
        assertEquals("You already have an active reservation for this book", exception.getMessage());
        verify(bookCopyRepository, never()).findFirstAvailableCopyByBookId(any());
    }

    /**
     * Tests that createReservation() throws an exception
     * if no copies are available for reservation.
     */
    @Test
    void createReservation_NoCopiesAvailable() {
        when(reservationRepository.hasActiveReservationForBook(userId, bookId)).thenReturn(false);
        when(bookCopyRepository.findFirstAvailableCopyByBookId(bookId)).thenReturn(Optional.empty());
        
        RuntimeException exception = assertThrows(RuntimeException.class, 
            () -> reservationService.createReservation(userId, bookId, "test@demo.com"));
        
        assertEquals("No copies available for reservation", exception.getMessage());
        verify(reservationRepository, never()).insertReservationWithCast(any(), any(), any(), any(), any(), any(), any(), any());
    }

    /**
     * Tests that getUserReservations() returns all reservations
     * for a given user.
     */
    @Test
    void getUserReservations_Success() {
        List<Reservation> expectedReservations = Arrays.asList(reservation);
        when(reservationRepository.findByUserId(userId)).thenReturn(expectedReservations);
        
        List<Reservation> result = reservationService.getUserReservations(userId);
        
        assertEquals(expectedReservations, result);
        verify(reservationRepository).findByUserId(userId);
    }

    /**
     * Tests that getUserReservationsWithBooks() returns reservation data
     * including book details for a given user.
     */
    @Test
    void getUserReservationsWithBooks_Success() {
        Object[] row = {
            reservationId, userId, copyId, 
            java.sql.Date.valueOf(LocalDate.now()), 
            java.sql.Date.valueOf(LocalDate.now().plusDays(14)),
            "PENDING", "Test Book", "123456789", "cover.jpg", 2023, "Test Author",
            java.sql.Date.valueOf(LocalDate.now()),
            java.sql.Date.valueOf(LocalDate.now().plusDays(5)),
            "Test Library"
        };
        List<Object[]> mockResults = Arrays.asList(new Object[][]{row});
        when(reservationRepository.findReservationsWithBooksByUserId(userId)).thenReturn(mockResults);
        
        List<ReservationWithBook> result = reservationService.getUserReservationsWithBooks(userId);
        
        assertEquals(1, result.size());
        ReservationWithBook reservation = result.get(0);
        assertEquals(reservationId, reservation.getReservationId());
        assertEquals("Test Book", reservation.getTitle());
        assertEquals("Test Author", reservation.getAuthor());
    }

    /**
     * Tests that cancelReservation() successfully cancels a reservation
     * with status PENDING or CONFIRMED, updating copy and book availability.
     */
    @Test
    void cancelReservation_Success() {
        reservation.setStatus(ReservationStatus.PENDING);
        when(reservationRepository.findById(reservationId)).thenReturn(Optional.of(reservation));
        when(bookCopyRepository.findById(copyId)).thenReturn(Optional.of(bookCopy));
        
        reservationService.cancelReservation(reservationId, "test@demo.com");
        
        verify(reservationRepository).updateReservationStatusWithCast(reservationId, "CANCELLED");
        verify(bookCopyRepository).updateCopyStatusWithCast(copyId, "AVAILABLE");
        verify(bookRepository).incrementAvailableCopies(bookId);
    }

    /**
     * Tests that cancelReservation() throws an exception
     * if the reservation is not found.
     */
    @Test
    void cancelReservation_NotFound() {
        when(reservationRepository.findById(reservationId)).thenReturn(Optional.empty());
        
        RuntimeException exception = assertThrows(RuntimeException.class, 
            () -> reservationService.cancelReservation(reservationId, "test@demo.com"));
        
        assertEquals("Reservation not found", exception.getMessage());
    }

    /**
     * Tests that cancelReservation() throws an exception
     * if the reservation has a status that cannot be cancelled.
     */
    @Test
    void cancelReservation_InvalidStatus() {
        reservation.setStatus(ReservationStatus.COMPLETED);
        when(reservationRepository.findById(reservationId)).thenReturn(Optional.of(reservation));
        
        RuntimeException exception = assertThrows(RuntimeException.class, 
            () -> reservationService.cancelReservation(reservationId, "test@demo.com"));
        
        assertTrue(exception.getMessage().contains("Only pending or confirmed reservations can be cancelled"));
    }

    /**
     * Tests that canReserveBook() returns true
     * if the user has no active reservations and copies are available.
     */
    @Test
    void canReserveBook_True() {
        when(reservationRepository.hasActiveReservationForBook(userId, bookId)).thenReturn(false);
        Book book = new Book();
        book.setAvailableCopies(1);
        when(bookRepository.findById(bookId)).thenReturn(Optional.of(book));
        
        boolean result = reservationService.canReserveBook(userId, bookId);
        
        assertTrue(result);
    }

    /**
     * Tests that canReserveBook() returns false
     * if the user already has an active reservation.
     */
    @Test
    void canReserveBook_HasActiveReservation() {
        when(reservationRepository.hasActiveReservationForBook(userId, bookId)).thenReturn(true);
        
        boolean result = reservationService.canReserveBook(userId, bookId);
        
        assertFalse(result);
        verify(bookCopyRepository, never()).findAvailableCopiesByBookId(any());
    }

    /**
     * Tests that canReserveBook() returns false
     * if no copies are available for the book.
     */
    @Test
    void canReserveBook_NoCopiesAvailable() {
        when(reservationRepository.hasActiveReservationForBook(userId, bookId)).thenReturn(false);
        Book book = new Book();
        book.setAvailableCopies(0);
        when(bookRepository.findById(bookId)).thenReturn(Optional.of(book));
        
        boolean result = reservationService.canReserveBook(userId, bookId);
        
        assertFalse(result);
    }

    /**
     * Tests that getAllPendingPickups() returns all pending reservations.
     */
    @Test
    void getAllPendingPickups_Success() {
        Object[] row = {
            reservationId, userId, copyId, 
            java.sql.Date.valueOf(LocalDate.now()), 
            java.sql.Date.valueOf(LocalDate.now().plusDays(14)),
            "PENDING", "Test Book", "123456789", "cover.jpg", 2023, "Test Author",
            java.sql.Date.valueOf(LocalDate.now()),
            java.sql.Date.valueOf(LocalDate.now().plusDays(5)),
            "Test Library", "Test User"
        };
        List<Object[]> mockResults = Arrays.asList(new Object[][]{row});
        when(reservationRepository.findAllPendingPickups()).thenReturn(mockResults);
        
        List<ReservationWithBook> result = reservationService.getAllPendingPickups();
        
        assertEquals(1, result.size());
        assertEquals("PENDING", result.get(0).getStatus());
        assertEquals("Test User", result.get(0).getUserName());
    }

    /**
     * Tests that getAllCheckedOutBooks() returns all confirmed reservations.
     */
    @Test
    void getAllCheckedOutBooks_Success() {
        Object[] row = {
            reservationId, userId, copyId, 
            java.sql.Date.valueOf(LocalDate.now()), 
            java.sql.Date.valueOf(LocalDate.now().plusDays(14)),
            "CONFIRMED", "Test Book", "123456789", "cover.jpg", 2023, "Test Author",
            java.sql.Date.valueOf(LocalDate.now()),
            java.sql.Date.valueOf(LocalDate.now().plusDays(5)),
            "Test Library", "Test User"
        };
        List<Object[]> mockResults = Arrays.asList(new Object[][]{row});
        when(reservationRepository.findAllCheckedOutBooks()).thenReturn(mockResults);
        
        List<ReservationWithBook> result = reservationService.getAllCheckedOutBooks();
        
        assertEquals(1, result.size());
        assertEquals("CONFIRMED", result.get(0).getStatus());
        assertEquals("Test User", result.get(0).getUserName());
    }

    /**
     * Tests that markAsPickedUp() successfully updates status from PENDING to CONFIRMED.
     */
    @Test
    void markAsPickedUp_Success() {
        reservation.setStatus(ReservationStatus.PENDING);
        User user = new User();
        user.setEmail("test@demo.com");
        Book book = new Book();
        book.setTitle("Test Book");
        
        when(reservationRepository.findById(reservationId)).thenReturn(Optional.of(reservation));
        when(userRepository.findById(userId)).thenReturn(Optional.of(user));
        when(bookCopyRepository.findById(copyId)).thenReturn(Optional.of(bookCopy));
        when(bookRepository.findById(bookId)).thenReturn(Optional.of(book));
        
        reservationService.markAsPickedUp(reservationId);
        
        verify(reservationRepository).updateReservationStatusWithCast(reservationId, "CONFIRMED");
        verify(emailService).send(eq("test@demo.com"), eq("Book Pickup Confirmed"), any());
    }

    /**
     * Tests that markAsPickedUp() throws exception for non-PENDING reservations.
     */
    @Test
    void markAsPickedUp_InvalidStatus() {
        reservation.setStatus(ReservationStatus.CONFIRMED);
        when(reservationRepository.findById(reservationId)).thenReturn(Optional.of(reservation));
        
        RuntimeException exception = assertThrows(RuntimeException.class, 
            () -> reservationService.markAsPickedUp(reservationId));
        
        assertEquals("Only pending reservations can be marked as picked up", exception.getMessage());
    }

    /**
     * Tests that markAsReturned() successfully updates status from CONFIRMED to COMPLETED.
     */
    @Test
    void markAsReturned_Success() {
        reservation.setStatus(ReservationStatus.CONFIRMED);
        User user = new User();
        user.setEmail("test@demo.com");
        Book book = new Book();
        book.setTitle("Test Book");
        
        when(reservationRepository.findById(reservationId)).thenReturn(Optional.of(reservation));
        when(bookCopyRepository.findById(copyId)).thenReturn(Optional.of(bookCopy));
        when(userRepository.findById(userId)).thenReturn(Optional.of(user));
        when(bookRepository.findById(bookId)).thenReturn(Optional.of(book));
        
        reservationService.markAsReturned(reservationId);
        
        verify(reservationRepository).updateReservationStatusWithCast(reservationId, "COMPLETED");
        verify(bookCopyRepository).updateCopyStatusWithCast(copyId, "AVAILABLE");
        verify(bookRepository).incrementAvailableCopies(bookId);
        verify(emailService).send(eq("test@demo.com"), eq("Book Return Confirmed"), any());
    }

    /**
     * Tests that markAsReturned() throws exception for non-CONFIRMED reservations.
     */
    @Test
    void markAsReturned_InvalidStatus() {
        reservation.setStatus(ReservationStatus.PENDING);
        when(reservationRepository.findById(reservationId)).thenReturn(Optional.of(reservation));
        
        RuntimeException exception = assertThrows(RuntimeException.class, 
            () -> reservationService.markAsReturned(reservationId));
        
        assertEquals("Only confirmed reservations can be marked as returned", exception.getMessage());
    }

    /**
     * Tests that hasActiveReservationForBook() returns correct boolean value.
     */
    @Test
    void hasActiveReservationForBook_Success() {
        when(reservationRepository.hasActiveReservationForBook(userId, bookId)).thenReturn(true);
        
        boolean result = reservationService.hasActiveReservationForBook(userId, bookId);
        
        assertTrue(result);
        verify(reservationRepository).hasActiveReservationForBook(userId, bookId);
    }
}