package com.example.ELEC5619.controller;

import com.example.ELEC5619.Model.Book;
import com.example.ELEC5619.Service.BookDetailsService;
import com.example.ELEC5619.Controller.BookDetailsController;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(BookDetailsController.class)
class BookDetailsControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BookDetailsService service;

    private Book testBook;
    private String testIsbn;

    @BeforeEach
    void setUp() {
        testIsbn = "978-0123456789";
        testBook = new Book();
        testBook.setBookId(UUID.randomUUID());
        testBook.setTitle("Test Book");
        testBook.setIsbn(testIsbn);
    }

    /**
     * Test fetching a book by ISBN via path variable when the book exists
     * Expects HTTP 200 OK and JSON containing book details
     */
    @Test
    void getByIsbnPath_ShouldReturnBook_WhenExists() throws Exception {
        when(service.getByIsbn(testIsbn)).thenReturn(Optional.of(testBook));

        mockMvc.perform(get("/bookdetails/isbn/{isbn}", testIsbn))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.title").value("Test Book"))
                .andExpect(jsonPath("$.isbn").value(testIsbn));

        verify(service, times(2)).getByIsbn(testIsbn);
    }

    /**
     * Test fetching a book by ISBN via path variable when the book does not exist
     * Expects HTTP 404 Not Found
     */
    @Test
    void getByIsbnPath_ShouldReturn404_WhenNotFound() throws Exception {
        when(service.getByIsbn(testIsbn)).thenReturn(Optional.empty());

        mockMvc.perform(get("/bookdetails/isbn/{isbn}", testIsbn))
                .andExpect(status().isNotFound());

        verify(service, times(2)).getByIsbn(testIsbn);
    }

    /**
     * Test resolving a book by ISBN via query parameter when the book exists
     * Expects JSON list containing one book
     */
    @Test
    void resolveByIsbn_ShouldReturnBookInList_WhenExists() throws Exception {
        when(service.getByIsbn(testIsbn)).thenReturn(Optional.of(testBook));

        mockMvc.perform(get("/bookdetails").param("isbn", testIsbn))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.total").value(1))
                .andExpect(jsonPath("$.items[0].title").value("Test Book"))
                .andExpect(jsonPath("$.items[0].isbn").value(testIsbn));

        verify(service).getByIsbn(testIsbn);
    }

    /**
     * Test resolving a book by ISBN via query parameter when the book does not exist
     * Expects empty JSON list
     */
    @Test
    void resolveByIsbn_ShouldReturnEmptyList_WhenNotFound() throws Exception {
        when(service.getByIsbn(testIsbn)).thenReturn(Optional.empty());

        mockMvc.perform(get("/bookdetails").param("isbn", testIsbn))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.total").value(0))
                .andExpect(jsonPath("$.items").isEmpty());

        verify(service).getByIsbn(testIsbn);
    }

    /**
     * Test fetching related books by ISBN when related books exist
     * Expects JSON arrays for both byGenre and byAuthor containing books
     */
    @Test
    void related_ShouldReturnRelatedBooks() throws Exception {
        List<Book> genreBooks = Arrays.asList(testBook);
        List<Book> authorBooks = Arrays.asList(testBook);
        when(service.find5BySameGenre(testIsbn)).thenReturn(genreBooks);
        when(service.find5BySameAuthor(testIsbn)).thenReturn(authorBooks);

        mockMvc.perform(get("/bookdetails/isbn/{isbn}/related", testIsbn))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.byGenre").isArray())
                .andExpect(jsonPath("$.byAuthor").isArray())
                .andExpect(jsonPath("$.byGenre[0].title").value("Test Book"))
                .andExpect(jsonPath("$.byAuthor[0].title").value("Test Book"));

        verify(service).find5BySameGenre(testIsbn);
        verify(service).find5BySameAuthor(testIsbn);
    }

    /**
     * Test fetching related books by ISBN when no related books exist
     * Expects empty JSON arrays for both byGenre and byAuthor
     */
    @Test
    void related_ShouldReturnEmptyArrays_WhenNoRelatedBooks() throws Exception {
        when(service.find5BySameGenre(testIsbn)).thenReturn(Arrays.asList());
        when(service.find5BySameAuthor(testIsbn)).thenReturn(Arrays.asList());

        mockMvc.perform(get("/bookdetails/isbn/{isbn}/related", testIsbn))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.byGenre").isEmpty())
                .andExpect(jsonPath("$.byAuthor").isEmpty());

        verify(service).find5BySameGenre(testIsbn);
        verify(service).find5BySameAuthor(testIsbn);
    }
}