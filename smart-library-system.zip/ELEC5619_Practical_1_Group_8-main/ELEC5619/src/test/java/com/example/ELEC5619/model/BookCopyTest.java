package com.example.ELEC5619.model;

import com.example.ELEC5619.Model.BookCopy;
import org.junit.jupiter.api.Test;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class BookCopyTest {

    @Test
    void testGettersAndSetters() {
        BookCopy bookCopy = new BookCopy();
        UUID copyId = UUID.randomUUID();
        UUID libraryId = UUID.randomUUID();
        UUID bookId = UUID.randomUUID();
        
        bookCopy.setCopyId(copyId);
        bookCopy.setLibraryId(libraryId);
        bookCopy.setBookId(bookId);
        bookCopy.setStatus("RESERVED");
        
        assertEquals(copyId, bookCopy.getCopyId());
        assertEquals(libraryId, bookCopy.getLibraryId());
        assertEquals(bookId, bookCopy.getBookId());
        assertEquals("RESERVED", bookCopy.getStatus());
    }
}