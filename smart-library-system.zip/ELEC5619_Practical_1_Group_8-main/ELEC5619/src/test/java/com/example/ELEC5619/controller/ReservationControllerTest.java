package com.example.ELEC5619.controller;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.time.LocalDate;
import java.util.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.example.ELEC5619.Controller.ReservationController;
import com.example.ELEC5619.Model.*;
import com.example.ELEC5619.Service.ReservationService;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Optional;

@WebMvcTest(ReservationController.class)
class ReservationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ReservationService reservationService;
    
    @MockBean
    private com.example.ELEC5619.Repository.UserRepository userRepository;
    
    @MockBean
    private com.example.ELEC5619.Repository.ReservationRepository reservationRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private UUID userId;
    private UUID bookId;
    private UUID reservationId;
    private Reservation reservation;
    private ReservationWithBook reservationWithBook;

    @BeforeEach
    void setUp() {
        userId = UUID.fromString("b65f01be-72af-43b9-9864-715f92707952");
        bookId = UUID.randomUUID();
        reservationId = UUID.randomUUID();

        reservation = new Reservation();
        reservation.setReservationId(reservationId);
        reservation.setUserId(userId);
        reservation.setStartDate(LocalDate.now());
        reservation.setEndDate(LocalDate.now().plusDays(14));
        reservation.setStatus(ReservationStatus.PENDING);

        reservationWithBook = new ReservationWithBook();
        reservationWithBook.setReservationId(reservationId);
        reservationWithBook.setUserId(userId);
        reservationWithBook.setTitle("Test Book");
        reservationWithBook.setAuthor("Test Author");
        reservationWithBook.setStatus("PENDING");
        
        // Mock user lookup
        User testUser = new User();
        testUser.setUserId(userId);
        testUser.setEmail("test@demo.com");
        testUser.setRole("USER");
        when(userRepository.findByEmailIgnoreCase("test@demo.com")).thenReturn(Optional.of(testUser));
        
        // Mock admin user
        User adminUser = new User();
        adminUser.setUserId(UUID.randomUUID());
        adminUser.setEmail("admin@demo.com");
        adminUser.setRole("ADMIN");
        when(userRepository.findByEmailIgnoreCase("admin@demo.com")).thenReturn(Optional.of(adminUser));
    }

    /**
     * Test successful reservation of a book
     * Expects JSON response indicating success and reservation ID
     */
    @Test
    void reserveBook_Success() throws Exception {
        when(reservationService.createReservation(any(UUID.class), eq(bookId), anyString())).thenReturn(reservation);

        Map<String, String> request = Map.of("bookId", bookId.toString());

        mockMvc.perform(post("/api/reservations/reserve")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@demo.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Book reserved successfully!"))
                .andExpect(jsonPath("$.reservationId").value(reservationId.toString()));

        verify(reservationService).createReservation(userId, bookId, "test@demo.com");
    }

    /**
     * Test attempting to reserve a book already reserved by the user
     * Expects JSON response indicating failure with appropriate message
     */
    @Test
    void reserveBook_AlreadyReserved() throws Exception {
        when(reservationService.createReservation(any(UUID.class), eq(bookId), anyString()))
                .thenThrow(new RuntimeException("You already have an active reservation for this book"));

        Map<String, String> request = Map.of("bookId", bookId.toString());

        mockMvc.perform(post("/api/reservations/reserve")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@demo.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("You already have an active reservation for this book"));
    }

    /**
     * Test reservation request with invalid book ID format
     * Expects JSON response indicating failure with invalid UUID message
     */
    @Test
    void reserveBook_InvalidBookId() throws Exception {
        Map<String, String> request = Map.of("bookId", "invalid-uuid");

        mockMvc.perform(post("/api/reservations/reserve")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@demo.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Invalid UUID string: invalid-uuid"));
    }

    /**
     * Test checking availability of a book that can be reserved
     * Expects JSON response indicating canReserve true
     */
    @Test
    void checkAvailability_CanReserve() throws Exception {
        when(reservationService.canReserveBook(userId, bookId)).thenReturn(true);

        mockMvc.perform(get("/api/reservations/check-availability/{bookId}", bookId)
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@demo.com")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.canReserve").value(true))
                .andExpect(jsonPath("$.message").value("Available for reservation"));

        verify(reservationService).canReserveBook(userId, bookId);
        verify(reservationService, never()).hasActiveReservationForBook(userId, bookId);
    }

    /**
     * Test checking availability of a book that cannot be reserved
     * Expects JSON response indicating canReserve false
     */
    @Test
    void checkAvailability_CannotReserve() throws Exception {
        when(reservationService.canReserveBook(userId, bookId)).thenReturn(false);

        mockMvc.perform(get("/api/reservations/check-availability/{bookId}", bookId)
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@demo.com")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.canReserve").value(false))
                .andExpect(jsonPath("$.message").value("No copies available - join waitlist"));
    }

    /**
     * Test exception when checking availability of a book
     * Expects JSON response indicating error
     */
    @Test
    void checkAvailability_Exception() throws Exception {
        when(reservationService.canReserveBook(userId, bookId)).thenThrow(new RuntimeException("Database error"));

        mockMvc.perform(get("/api/reservations/check-availability/{bookId}", bookId)
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@demo.com")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.canReserve").value(false))
                .andExpect(jsonPath("$.message").value("Error checking availability"));
    }

    /**
     * Test fetching user reservations when they exist
     * Expects JSON array with reservation details
     */
    @Test
    void getUserReservations_Success() throws Exception {
        List<ReservationWithBook> reservations = Arrays.asList(reservationWithBook);
        when(reservationService.getUserReservationsWithBooks(userId)).thenReturn(reservations);

        mockMvc.perform(get("/api/reservations/user")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@demo.com")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$[0].reservationId").value(reservationId.toString()))
                .andExpect(jsonPath("$[0].title").value("Test Book"))
                .andExpect(jsonPath("$[0].author").value("Test Author"));

        verify(reservationService).getUserReservationsWithBooks(userId);
    }

    /**
     * Test fetching user reservations when no reservations exist
     * Expects empty JSON array
     */
    @Test
    void getUserReservations_EmptyList() throws Exception {
        when(reservationService.getUserReservationsWithBooks(userId)).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/reservations/user")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@demo.com")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$").isEmpty());
    }

    /**
     * Test successful cancellation of a reservation
     * Expects JSON response indicating success
     */
    @Test
    void cancelReservation_Success() throws Exception {
        doNothing().when(reservationService).cancelReservation(reservationId, "test@demo.com");

        mockMvc.perform(post("/api/reservations/cancel/{reservationId}", reservationId)
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@demo.com")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Reservation cancelled successfully"));

        verify(reservationService).cancelReservation(reservationId, "test@demo.com");
    }

    /**
     * Test cancelling a reservation that does not exist
     * Expects JSON response indicating failure
     */
    @Test
    void cancelReservation_NotFound() throws Exception {
        doThrow(new RuntimeException("Reservation not found"))
                .when(reservationService).cancelReservation(reservationId, "test@demo.com");

        mockMvc.perform(post("/api/reservations/cancel/{reservationId}", reservationId)
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@demo.com")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Reservation not found"));
    }

    /**
     * Test cancelling a reservation with invalid status
     * Expects JSON response indicating failure
     */
    @Test
    void cancelReservation_InvalidStatus() throws Exception {
        doThrow(new RuntimeException("Only pending or confirmed reservations can be cancelled"))
                .when(reservationService).cancelReservation(reservationId, "test@demo.com");

        mockMvc.perform(post("/api/reservations/cancel/{reservationId}", reservationId)
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@demo.com")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Only pending or confirmed reservations can be cancelled"));
    }

    /**
     * Test reserving a book when not logged in
     * Expects JSON response indicating unauthorised
     */
    @Test
    void reserveBook_NotLoggedIn() throws Exception {
        Map<String, String> request = Map.of("bookId", bookId.toString());

        mockMvc.perform(post("/api/reservations/reserve")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Not logged in"));
    }

    /**
     * Test checking availability when not logged in
     * Expects JSON response indicating cannot reserve
     */
    @Test
    void checkAvailability_NotLoggedIn() throws Exception {
        mockMvc.perform(get("/api/reservations/check-availability/{bookId}", bookId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.canReserve").value(false))
                .andExpect(jsonPath("$.message").value("Please log in to check availability"));
    }

    /**
     * Test checking availability for unknown user
     * Expects JSON response indicating user not found
     */
    @Test
    void checkAvailability_UserNotFound() throws Exception {
        when(userRepository.findByEmailIgnoreCase("unknown@demo.com")).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/reservations/check-availability/{bookId}", bookId)
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "unknown@demo.com")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.canReserve").value(false))
                .andExpect(jsonPath("$.message").value("User not found"));
    }

    /**
     * Test fetching user reservations when not logged in
     * Expects JSON response indicating unauthorised
     */
    @Test
    void getUserReservations_NotLoggedIn() throws Exception {
        mockMvc.perform(get("/api/reservations/user"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Not logged in"));
    }

    /**
     * Test cancelling reservation when not logged in
     * Expects JSON response indicating unauthorised
     */
    @Test
    void cancelReservation_NotLoggedIn() throws Exception {
        mockMvc.perform(post("/api/reservations/cancel/{reservationId}", reservationId))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Not logged in"));
    }

    /**
     * Test checking availability when user already has an active reservation
     * Expects JSON response indicating hasReservation true
     */
    @Test
    void checkAvailability_HasActiveReservation() throws Exception {
        when(reservationService.canReserveBook(userId, bookId)).thenReturn(false);
        when(reservationService.hasActiveReservationForBook(userId, bookId)).thenReturn(true);

        mockMvc.perform(get("/api/reservations/check-availability/{bookId}", bookId)
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@demo.com")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.canReserve").value(false))
                .andExpect(jsonPath("$.hasReservation").value(true))
                .andExpect(jsonPath("$.message").value("You have already reserved a copy of this book"));

        verify(reservationService).canReserveBook(userId, bookId);
        verify(reservationService).hasActiveReservationForBook(userId, bookId);
    }

    /**
     * Test fetching user reservations with service exception
     * Expects JSON response indicating failure and error message
     */
    @Test
    void getUserReservations_ServiceException() throws Exception {
        when(reservationService.getUserReservationsWithBooks(userId)).thenThrow(new RuntimeException("Database connection failed"));

        mockMvc.perform(get("/api/reservations/user")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@demo.com")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Database connection failed"));
    }

    /**
     * Test admin getting pending pickups successfully
     */
    @Test
    void getPendingPickups_Success() throws Exception {
        List<ReservationWithBook> pendingPickups = Arrays.asList(reservationWithBook);
        when(reservationService.getAllPendingPickups()).thenReturn(pendingPickups);

        mockMvc.perform(get("/api/reservations/admin/pending-pickups")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "admin@demo.com")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$[0].reservationId").value(reservationId.toString()));

        verify(reservationService).getAllPendingPickups();
    }

    /**
     * Test non-admin user trying to access pending pickups
     */
    @Test
    void getPendingPickups_NotAdmin() throws Exception {
        mockMvc.perform(get("/api/reservations/admin/pending-pickups")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@demo.com")))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Admin access required"));
    }

    /**
     * Test admin getting checked out books successfully
     */
    @Test
    void getCheckedOutBooks_Success() throws Exception {
        List<ReservationWithBook> checkedOutBooks = Arrays.asList(reservationWithBook);
        when(reservationService.getAllCheckedOutBooks()).thenReturn(checkedOutBooks);

        mockMvc.perform(get("/api/reservations/admin/checked-out")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "admin@demo.com")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$[0].reservationId").value(reservationId.toString()));

        verify(reservationService).getAllCheckedOutBooks();
    }

    /**
     * Test non-admin user trying to access checked out books
     */
    @Test
    void getCheckedOutBooks_NotAdmin() throws Exception {
        mockMvc.perform(get("/api/reservations/admin/checked-out")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@demo.com")))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Admin access required"));
    }

    /**
     * Test admin marking book as picked up successfully
     */
    @Test
    void markAsPickedUp_Success() throws Exception {
        doNothing().when(reservationService).markAsPickedUp(reservationId);

        mockMvc.perform(post("/api/reservations/admin/mark-picked-up/{reservationId}", reservationId)
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "admin@demo.com")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Book marked as picked up"));

        verify(reservationService).markAsPickedUp(reservationId);
    }

    /**
     * Test non-admin user trying to mark book as picked up
     */
    @Test
    void markAsPickedUp_NotAdmin() throws Exception {
        mockMvc.perform(post("/api/reservations/admin/mark-picked-up/{reservationId}", reservationId)
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@demo.com")))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Admin access required"));
    }

    /**
     * Test admin marking book as returned successfully
     */
    @Test
    void markAsReturned_Success() throws Exception {
        doNothing().when(reservationService).markAsReturned(reservationId);

        mockMvc.perform(post("/api/reservations/admin/mark-returned/{reservationId}", reservationId)
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "admin@demo.com")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Book marked as returned"));

        verify(reservationService).markAsReturned(reservationId);
    }

    /**
     * Test non-admin user trying to mark book as returned
     */
    @Test
    void markAsReturned_NotAdmin() throws Exception {
        mockMvc.perform(post("/api/reservations/admin/mark-returned/{reservationId}", reservationId)
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@demo.com")))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Admin access required"));
    }

    /**
     * Test admin endpoints when not logged in
     */
    @Test
    void adminEndpoints_NotLoggedIn() throws Exception {
        mockMvc.perform(get("/api/reservations/admin/pending-pickups"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Not logged in"));

        mockMvc.perform(get("/api/reservations/admin/checked-out"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Not logged in"));

        mockMvc.perform(post("/api/reservations/admin/mark-picked-up/{reservationId}", reservationId))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Not logged in"));

        mockMvc.perform(post("/api/reservations/admin/mark-returned/{reservationId}", reservationId))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Not logged in"));
    }

    /**
     * Test admin endpoints with service exceptions
     */
    @Test
    void markAsPickedUp_ServiceException() throws Exception {
        doThrow(new RuntimeException("Only pending reservations can be marked as picked up"))
                .when(reservationService).markAsPickedUp(reservationId);

        mockMvc.perform(post("/api/reservations/admin/mark-picked-up/{reservationId}", reservationId)
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "admin@demo.com")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Only pending reservations can be marked as picked up"));
    }

    /**
     * Test mark as returned with service exception
     */
    @Test
    void markAsReturned_ServiceException() throws Exception {
        doThrow(new RuntimeException("Only confirmed reservations can be marked as returned"))
                .when(reservationService).markAsReturned(reservationId);

        mockMvc.perform(post("/api/reservations/admin/mark-returned/{reservationId}", reservationId)
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "admin@demo.com")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Only confirmed reservations can be marked as returned"));
    }

    /**
     * Test getPendingPickups with service exception
     */
    @Test
    void getPendingPickups_ServiceException() throws Exception {
        when(reservationService.getAllPendingPickups())
                .thenThrow(new RuntimeException("Database error"));

        mockMvc.perform(get("/api/reservations/admin/pending-pickups")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "admin@demo.com")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Database error"));
    }

    /**
     * Test getCheckedOutBooks with service exception
     */
    @Test
    void getCheckedOutBooks_ServiceException() throws Exception {
        when(reservationService.getAllCheckedOutBooks())
                .thenThrow(new RuntimeException("Service unavailable"));

        mockMvc.perform(get("/api/reservations/admin/checked-out")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "admin@demo.com")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Service unavailable"));
    }

    /**
     * Test reserveBook with missing bookId field (covers RuntimeException catch)
     */
    @Test
    void reserveBook_MissingBookId() throws Exception {
        Map<String, String> request = Map.of("wrongField", "value");

        mockMvc.perform(post("/api/reservations/reserve")
                .cookie(new jakarta.servlet.http.Cookie("userEmail", "test@demo.com"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").exists());
    }
}