package com.example.ELEC5619.controller;

import com.example.ELEC5619.Model.PasswordResetToken;
import com.example.ELEC5619.Model.User;
import com.example.ELEC5619.Repository.PasswordResetTokenRepository;
import com.example.ELEC5619.Repository.UserRepository;
import com.example.ELEC5619.Service.EmailService;
import com.example.ELEC5619.Controller.AuthController;
import jakarta.servlet.http.Cookie;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Base64;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Web MVC slice tests for {@link AuthController}.
 * <p>
 * These tests verify request/response behaviour for authentication-related endpoints,
 * including signup, login, identity lookup, password reset, and logout. Repositories
 * and services are mocked to isolate controller logic from persistence/email layers.
 */
@SuppressWarnings("removal")
@WebMvcTest(AuthController.class)
class AuthControllerTest {

    /** Mock MVC client used to perform HTTP requests against the controller under test. */
    @Autowired
    private MockMvc mockMvc;

    /** Mocked repository for user persistence operations. */
    @MockBean private UserRepository users;

    /** Mocked encoder used to hash/verify passwords. */
    @MockBean private PasswordEncoder encoder;

    /** Mocked repository for password reset tokens. */
    @MockBean private PasswordResetTokenRepository resetTokens;

    /** Mocked service used for sending password reset emails. */
    @MockBean private EmailService emailService;

    /** Reusable user instance seeded before each test. */
    private User user;

    /** Fixed user identifier associated with {@link #user}. */
    private UUID userId;

    /**
     * Seeds a valid {@link User} object and common defaults before each test.
     * <ul>
     *     <li>Ensures consistent identifiers and baseline profile data</li>
     *     <li>Reflects the current domain change from notifications → phoneNumber</li>
     * </ul>
     */
    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        user = new User();
        user.setUserId(userId);
        user.setName("Alice");
        user.setEmail("alice@example.com");
        user.setPassword("$2a$10$hash");
        user.setRole("USER");
        user.setPhoneNumber("0412345678"); // phone now used instead of notifications
        user.setCreatedAt(OffsetDateTime.now());
        user.setBirthDate(LocalDate.of(1998, 5, 14));
    }

    /**
     * Verifies that signup succeeds when required fields are valid.
     * <p><b>Given</b> a unique email and valid phone format,
     * <b>when</b> /auth/signup is called,
     * <b>then</b> the user is created and an HttpOnly cookie is set.</p>
     */
    @Test
    void signup_success_shouldCreateUser_andSetHttpOnlyCookie() throws Exception {
        given(users.existsByEmailIgnoreCase("alice@example.com")).willReturn(false);
        given(encoder.encode("AlicePass123")).willReturn("hashed");
        given(users.save(any(User.class))).willAnswer(inv -> {
            User u = inv.getArgument(0);
            u.setUserId(userId);
            return u;
        });

        String body = """
          {
            "name":"Alice",
            "email":"alice@example.com",
            "password":"AlicePass123",
            "birthDate":"1998-05-14",
            "role":"USER",
            "phoneNumber":"0412345678"
          }
        """;

        mockMvc.perform(post("/auth/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status").value("ok"))
            .andExpect(jsonPath("$.user.userId").value(userId.toString()))
            .andExpect(jsonPath("$.user.email").value("alice@example.com"))
            .andExpect(jsonPath("$.user.phoneNumber").value("0412345678"))
            .andExpect(header().string("Set-Cookie", org.hamcrest.Matchers.containsString("userEmail=alice@example.com")))
            .andExpect(header().string("Set-Cookie", org.hamcrest.Matchers.containsString("HttpOnly")));

        verify(users).save(any(User.class));
    }

    /**
     * Validates phone number format at signup.
     * <p><b>Given</b> an invalid phone (not 10 digits starting with 0),
     * <b>when</b> /auth/signup is called,
     * <b>then</b> the API responds with HTTP 400 and a validation message.</p>
     */
@Test
void signup_invalidPhone_should400() throws Exception {
    given(users.existsByEmailIgnoreCase("bob@example.com")).willReturn(false);

    String body = """
      {
        "name":"Bob",
        "email":"bob@example.com",
        "password":"Secret123",
        "phoneNumber":"12345"
      }
    """;

    mockMvc.perform(post("/auth/signup")
            .contentType(MediaType.APPLICATION_JSON)
            .content(body))
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.status").value("error"))
        .andExpect(jsonPath("$.code").value(400))
        .andExpect(jsonPath("$.message").value("Phone must be 10 digits starting with 0."));
}


    /**
     * Ensures the API guards against missing email/password at signup.
     * <p>Returns HTTP 400 with an error payload.</p>
     */
    @Test
    void signup_missingEmailOrPassword_should400() throws Exception {
        String body = "{\"email\":\"\",\"password\":\"\"}";
        mockMvc.perform(post("/auth/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.status").value("error"))
            .andExpect(jsonPath("$.code").value(400));
    }

    /**
     * Prevents duplicate registration with an existing email.
     * <p>Returns HTTP 409 Conflict.</p>
     */
    @Test
    void signup_emailExists_should409() throws Exception {
        given(users.existsByEmailIgnoreCase("alice@example.com")).willReturn(true);

        String body = """
          {"email":"alice@example.com","password":"x"}
        """;
        mockMvc.perform(post("/auth/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
            .andExpect(status().isConflict())
            .andExpect(jsonPath("$.status").value("error"))
            .andExpect(jsonPath("$.code").value(409));
    }

    /**
     * Verifies successful login flow.
     * <p>Returns user payload and sets HttpOnly session cookie.</p>
     */
    @Test
    void login_success_shouldSetCookie_andReturnUser() throws Exception {
        given(users.findByEmailIgnoreCase("alice@example.com")).willReturn(Optional.of(user));
        given(encoder.matches("AlicePass123", user.getPassword())).willReturn(true);

        String body = """
          {"email":"alice@example.com","password":"AlicePass123"}
        """;

        mockMvc.perform(post("/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status").value("ok"))
            .andExpect(jsonPath("$.user.email").value("alice@example.com"))
            .andExpect(jsonPath("$.user.phoneNumber").value("0412345678"))
            .andExpect(header().string("Set-Cookie", org.hamcrest.Matchers.containsString("HttpOnly")));
    }

    /**
     * Validates presence of required login fields.
     * <p>Missing email/password should produce HTTP 400.</p>
     */
    @Test
    void login_missingFields_should400() throws Exception {
        mockMvc.perform(post("/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}"))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.code").value(400));
    }

    /**
     * Returns HTTP 401 when attempting to log in with a non-existent account.
     */
    @Test
    void login_nonExistentUser_should401() throws Exception {
        given(users.findByEmailIgnoreCase("nouser@example.com")).willReturn(Optional.empty());

        mockMvc.perform(post("/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"nouser@example.com\",\"password\":\"x\"}"))
            .andExpect(status().isUnauthorized())
            .andExpect(jsonPath("$.code").value(401));
    }

    /**
     * Returns HTTP 401 when the supplied password is incorrect.
     */
    @Test
    void login_wrongPassword_should401() throws Exception {
        given(users.findByEmailIgnoreCase("alice@example.com")).willReturn(Optional.of(user));
        given(encoder.matches("bad", user.getPassword())).willReturn(false);

        mockMvc.perform(post("/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"alice@example.com\",\"password\":\"bad\"}"))
            .andExpect(status().isUnauthorized())
            .andExpect(jsonPath("$.code").value(401));
    }

    /**
     * Verifies unauthenticated access to /auth/me is reported as 401 in the payload.
     */
    @Test
    void me_withoutCookie_should401() throws Exception {
        mockMvc.perform(get("/auth/me"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status").value("error"))
            .andExpect(jsonPath("$.code").value(401));
    }

    /**
     * Verifies /auth/me returns 404 when the cookie email does not match a user.
     */
    @Test
    void me_withCookie_userNotFound_should404() throws Exception {
        given(users.findByEmailIgnoreCase("ghost@example.com")).willReturn(Optional.empty());

        mockMvc.perform(get("/auth/me")
                .cookie(new Cookie("userEmail", "ghost@example.com")))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.code").value(404));
    }

    /**
     * Verifies /auth/me returns the current user when a valid cookie is present.
     */
    @Test
    void me_withCookie_success() throws Exception {
        given(users.findByEmailIgnoreCase("alice@example.com")).willReturn(Optional.of(user));

        mockMvc.perform(get("/auth/me")
                .cookie(new Cookie("userEmail", "alice@example.com")))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status").value("ok"))
            .andExpect(jsonPath("$.user.email").value("alice@example.com"))
            .andExpect(jsonPath("$.user.phoneNumber").value("0412345678"));
    }

    /**
     * Verifies /auth/users/{id} returns the user payload when found.
     */
    @Test
    void getById_found() throws Exception {
        given(users.findById(userId)).willReturn(Optional.of(user));

        mockMvc.perform(get("/auth/users/{id}", userId))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status").value("ok"))
            .andExpect(jsonPath("$.user.userId").value(userId.toString()));
    }

    /**
     * Verifies /auth/users/{id} returns a 404-style payload when not found.
     */
    @Test
    void getById_notFound() throws Exception {
        given(users.findById(userId)).willReturn(Optional.empty());

        mockMvc.perform(get("/auth/users/{id}", userId))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.code").value(404));
    }

    /**
     * Ensures /auth/users/by-email returns the user when the email exists.
     */
    @Test
    void getByEmail_found() throws Exception {
        given(users.findByEmailIgnoreCase("alice@example.com")).willReturn(Optional.of(user));

        mockMvc.perform(get("/auth/users/by-email").param("email", "alice@example.com"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.user.email").value("alice@example.com"));
    }

    /**
     * Ensures /auth/users/by-email returns a 404-style payload when the email does not exist.
     */
    @Test
    void getByEmail_notFound() throws Exception {
        given(users.findByEmailIgnoreCase("nope@example.com")).willReturn(Optional.empty());

        mockMvc.perform(get("/auth/users/by-email").param("email", "nope@example.com"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.code").value(404));
    }

    /**
     * Verifies the forgot-password flow for an existing user:
     * <ul>
     *   <li>Old tokens are invalidated</li>
     *   <li>A new token is created</li>
     *   <li>An email is sent with reset instructions</li>
     * </ul>
     */
    @Test
    void forgot_withExistingUser_shouldSendEmail_andInvalidateOldTokens() throws Exception {
        given(users.findByEmailIgnoreCase("alice@example.com")).willReturn(Optional.of(user));
        given(resetTokens.save(any(PasswordResetToken.class))).willAnswer(inv -> inv.getArgument(0));

        mockMvc.perform(post("/auth/forgot")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"alice@example.com\"}"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status").value("ok"));

        verify(resetTokens).deleteByUserId(eq(userId));
        verify(emailService).send(eq("alice@example.com"), eq("Password Reset"), anyString());
    }

    /**
     * Verifies the forgot-password endpoint is silent for unknown emails
     * (still returns OK, but no email is sent).
     */
    @Test
    void forgot_withUnknownUser_shouldStillReturnOk_butNoEmail() throws Exception {
        given(users.findByEmailIgnoreCase("ghost@example.com")).willReturn(Optional.empty());

        mockMvc.perform(post("/auth/forgot")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"ghost@example.com\"}"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status").value("ok"));

        verify(emailService, never()).send(anyString(), anyString(), anyString());
    }

    /**
     * Validates forgot-password request body: email is required.
     * <p>Returns HTTP 400 on missing field.</p>
     */
    @Test
    void forgot_missingEmail_should400() throws Exception {
        mockMvc.perform(post("/auth/forgot")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}"))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.code").value(400));
    }

    /**
     * Validates reset-password request body: both token and newPassword are required.
     * <p>Returns HTTP 400 on missing fields.</p>
     */
    @Test
    void reset_missingFields_should400() throws Exception {
        mockMvc.perform(post("/auth/reset")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}"))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.code").value(400));
    }

    /**
     * Returns HTTP 400 when an invalid reset token is supplied.
     */
    @Test
    void reset_invalidToken_should400() throws Exception {
        given(resetTokens.findByToken("bad")).willReturn(Optional.empty());

        mockMvc.perform(post("/auth/reset")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"token\":\"bad\",\"newPassword\":\"X\"}"))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.message").value("Invalid token"));
    }

    /**
     * Returns HTTP 400 when a reset token is expired or already used.
     */
    @Test
    void reset_expiredOrUsedToken_should400() throws Exception {
        PasswordResetToken t = new PasswordResetToken();
        t.setToken("tok");
        t.setUserId(userId);
        t.setUsed(true);
        t.setExpiresAt(OffsetDateTime.now().minusMinutes(1));

        given(resetTokens.findByToken("tok")).willReturn(Optional.of(t));

        mockMvc.perform(post("/auth/reset")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"token\":\"tok\",\"newPassword\":\"X\"}"))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.code").value(400));
    }

    /**
     * Verifies successful password reset:
     * <ul>
     *   <li>User password is updated (encoded)</li>
     *   <li>Reset token is marked as used</li>
     *   <li>HttpOnly cookie is issued</li>
     * </ul>
     */
    @Test
    void reset_success_shouldUpdatePassword_markTokenUsed_andSetCookie() throws Exception {
        PasswordResetToken t = new PasswordResetToken();
        t.setToken("tok");
        t.setUserId(userId);
        t.setUsed(false);
        t.setExpiresAt(OffsetDateTime.now().plusMinutes(30));

        given(resetTokens.findByToken("tok")).willReturn(Optional.of(t));
        given(users.findById(userId)).willReturn(Optional.of(user));
        given(encoder.encode("NewSecret123")).willReturn("new-hash");
        given(users.save(any(User.class))).willReturn(user);
        given(resetTokens.save(any(PasswordResetToken.class))).willAnswer(inv -> inv.getArgument(0));

        mockMvc.perform(post("/auth/reset")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"token\":\"tok\",\"newPassword\":\"NewSecret123\"}"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status").value("ok"))
            .andExpect(header().string("Set-Cookie", org.hamcrest.Matchers.containsString("HttpOnly")));

        ArgumentCaptor<User> userCaptor = ArgumentCaptor.forClass(User.class);
        verify(users, atLeastOnce()).save(userCaptor.capture());
        assertThat(userCaptor.getValue().getPassword()).isEqualTo("new-hash");

        ArgumentCaptor<PasswordResetToken> tokenCaptor = ArgumentCaptor.forClass(PasswordResetToken.class);
        verify(resetTokens, atLeastOnce()).save(tokenCaptor.capture());
        assertThat(tokenCaptor.getValue().isUsed()).isTrue();
    }

    /**
     * Verifies logout behaviour:
     * <p>Returns success payload and issues a cookie with Max-Age=0 (deletes session).</p>
     */
    @Test
    void logout_shouldClearCookie_andReturnOk() throws Exception {
        mockMvc.perform(post("/auth/logout"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.message").value("Logged out successfully"))
            .andExpect(header().string("Set-Cookie", org.hamcrest.Matchers.containsString("Max-Age=0")));
    }

    /**
     * Utility used by controller code paths to generate random URL-safe tokens.
     * <p><b>Note:</b> Not directly exercised by these tests; included for completeness.</p>
     *
     * @return a random Base64 URL-safe token without padding
     */
    @SuppressWarnings("unused")
    private static String randomUrlToken() {
        byte[] b = new byte[32];
        new java.security.SecureRandom().nextBytes(b);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(b);
    }
}
