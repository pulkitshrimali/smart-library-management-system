package com.example.ELEC5619.model;

import com.example.ELEC5619.Model.Author;
import org.junit.jupiter.api.Test;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class AuthorTest {

    @Test
    void testGettersAndSetters() {
        Author author = new Author();
        UUID authorId = UUID.randomUUID();
        
        author.setAuthorId(authorId);
        author.setName("Isaac Asimov");
        
        assertEquals(authorId, author.getAuthorId());
        assertEquals("Isaac Asimov", author.getName());
    }
}