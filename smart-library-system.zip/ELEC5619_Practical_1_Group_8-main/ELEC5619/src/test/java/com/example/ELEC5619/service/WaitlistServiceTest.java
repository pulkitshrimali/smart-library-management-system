package com.example.ELEC5619.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.ELEC5619.Model.Waitlist;
import com.example.ELEC5619.Repository.BookRepository;
import com.example.ELEC5619.Repository.WaitlistRepository;
import com.example.ELEC5619.Service.WaitlistService;

@ExtendWith(MockitoExtension.class)
class WaitlistServiceTest {

    @Mock
    private WaitlistRepository waitlistRepository;

    @Mock
    private BookRepository bookRepository;

    @InjectMocks
    private WaitlistService waitlistService;

    private UUID userId;
    private UUID bookId;
    private UUID libraryId;
    private Waitlist waitlist;

    @BeforeEach
    void setUp() {
        // Initialise test data for each test case
        userId = UUID.randomUUID();
        bookId = UUID.randomUUID();
        libraryId = UUID.randomUUID();

        waitlist = new Waitlist();
        waitlist.setWaitlistId(UUID.randomUUID());
        waitlist.setUserId(userId);
        waitlist.setBookId(bookId);
        waitlist.setLibraryId(libraryId);
        waitlist.setPosition(1);
    }

    /**
     * Test that a user can successfully join the waitlist when they are not already on it.
     */
    @Test
    void testJoinWaitlist() {
        when(waitlistRepository.findByUserIdAndBookId(userId, bookId)).thenReturn(Optional.empty());
        when(waitlistRepository.save(any(Waitlist.class))).thenReturn(waitlist);

        Waitlist result = waitlistService.joinWaitlist(userId, bookId, libraryId);

        assertNotNull(result);
        assertEquals(userId, result.getUserId());
        assertEquals(bookId, result.getBookId());
        assertEquals(libraryId, result.getLibraryId());
        verify(waitlistRepository).save(any(Waitlist.class));
    }

    /**
     * Test that attempting to join the waitlist again when already on it throws an exception.
     */
    @Test
    void testJoinWaitlistAlreadyExists() {
        when(waitlistRepository.findByUserIdAndBookId(userId, bookId)).thenReturn(Optional.of(waitlist));

        RuntimeException exception = assertThrows(RuntimeException.class, 
            () -> waitlistService.joinWaitlist(userId, bookId, libraryId));

        assertEquals("You are already on the waitlist for this book", exception.getMessage());
        verify(waitlistRepository, never()).save(any());
    }

    /**
     * Test that a user can successfully leave the waitlist.
     */
    @Test
    void testLeaveWaitlist() {
        when(waitlistRepository.findByUserIdAndBookId(userId, bookId)).thenReturn(Optional.of(waitlist));

        waitlistService.leaveWaitlist(userId, bookId);

        verify(waitlistRepository).delete(waitlist);
    }

    /**
     * Test that attempting to leave the waitlist when not on it throws an exception.
     */
    @Test
    void testLeaveWaitlistNotFound() {
        when(waitlistRepository.findByUserIdAndBookId(userId, bookId)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class,
            () -> waitlistService.leaveWaitlist(userId, bookId));

        assertEquals("You are not on the waitlist for this book", exception.getMessage());
        verify(waitlistRepository, never()).delete(any());
    }

    /**
     * Test that the waitlist count for a book is returned correctly.
     */
    @Test
    void testGetWaitlistCount() {
        when(waitlistRepository.countByBookId(bookId)).thenReturn(5L);

        Long count = waitlistService.getWaitlistCount(bookId);

        assertEquals(5L, count);
        verify(waitlistRepository).countByBookId(bookId);
    }

    /**
     * Test retrieving a specific user's waitlist entry for a book.
     */
    @Test
    void testGetUserWaitlistEntry() {
        when(waitlistRepository.findByUserIdAndBookId(userId, bookId)).thenReturn(Optional.of(waitlist));

        Optional<Waitlist> result = waitlistService.getUserWaitlistEntry(userId, bookId);

        assertTrue(result.isPresent());
        assertEquals(waitlist, result.get());
        verify(waitlistRepository).findByUserIdAndBookId(userId, bookId);
    }

    /**
     * Test retrieving the complete waitlist for a book in the correct order.
     */
    @Test
    void testGetBookWaitlist() {
        List<Waitlist> waitlists = Arrays.asList(waitlist);
        when(waitlistRepository.findByBookIdOrderByPosition(bookId)).thenReturn(waitlists);

        List<Waitlist> result = waitlistService.getBookWaitlist(bookId);

        assertEquals(1, result.size());
        assertEquals(waitlist, result.get(0));
        verify(waitlistRepository).findByBookIdOrderByPosition(bookId);
    }

    /**
     * Test retrieving all waitlist entries for a specific user.
     */
    @Test
    void testGetUserWaitlist() {
        List<Waitlist> waitlists = Arrays.asList(waitlist);
        when(waitlistRepository.findByUserId(userId)).thenReturn(waitlists);

        List<Waitlist> result = waitlistService.getUserWaitlist(userId);

        assertEquals(1, result.size());
        assertEquals(waitlist, result.get(0));
        verify(waitlistRepository).findByUserId(userId);
    }

    /**
     * Test retrieving a user's waitlist entries including book information.
     */
    @Test
    void testGetUserWaitlistWithBooks() {
        List<Waitlist> waitlists = Arrays.asList(waitlist);
        when(waitlistRepository.findByUserId(userId)).thenReturn(waitlists);

        List<Waitlist> result = waitlistService.getUserWaitlistWithBooks(userId);

        assertEquals(1, result.size());
        assertEquals(waitlist, result.get(0));
        verify(waitlistRepository).findByUserId(userId);
    }

    /**
     * Test promoting the next user in the waitlist for a book.
     */
    @Test
    void testPromoteNextUser() {
        when(waitlistRepository.findFirstInQueue(bookId)).thenReturn(Optional.of(waitlist));

        Optional<Waitlist> result = waitlistService.promoteNextUser(bookId);

        assertTrue(result.isPresent());
        assertEquals(waitlist, result.get());
        verify(waitlistRepository).findFirstInQueue(bookId);
    }

    /**
     * Test removing a waitlist entry by its ID.
     */
    @Test
    void testRemoveFromWaitlist() {
        UUID waitlistId = waitlist.getWaitlistId();

        waitlistService.removeFromWaitlist(waitlistId);

        verify(waitlistRepository).deleteById(waitlistId);
    }

    /**
     * Test promoting the next user when the waitlist is empty.
     */
    @Test
    void testPromoteNextUserEmpty() {
        when(waitlistRepository.findFirstInQueue(bookId)).thenReturn(Optional.empty());

        Optional<Waitlist> result = waitlistService.promoteNextUser(bookId);

        assertFalse(result.isPresent());
    }
}