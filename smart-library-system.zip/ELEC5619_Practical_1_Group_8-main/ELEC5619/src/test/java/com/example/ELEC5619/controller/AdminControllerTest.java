package com.example.ELEC5619.controller;

import com.example.ELEC5619.Model.Author;
import com.example.ELEC5619.Model.Book;
import com.example.ELEC5619.Model.Genre;
import com.example.ELEC5619.Repository.AuthorRepository;
import com.example.ELEC5619.Repository.BookRepository;
import com.example.ELEC5619.Repository.GenreRepository;
import com.example.ELEC5619.Controller.AdminController;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.*;
import java.time.LocalDate;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Unit tests for {@link AdminController} using Spring's {@link WebMvcTest}.
 * <p>
 * This test class focuses on verifying REST API behavior for book management
 * (create, update, delete) in the admin context. It uses mock repositories
 * to simulate data layer interactions without touching the actual database.
 */
@SuppressWarnings("removal")
@WebMvcTest(AdminController.class)
class AdminControllerTest {

    /** MockMvc instance used for performing HTTP requests in tests */
    @Autowired
    private MockMvc mockMvc;

    /** Mocked Book repository */
    @MockBean private BookRepository books;

    /** Mocked Author repository */
    @MockBean private AuthorRepository authors;

    /** Mocked Genre repository */
    @MockBean private GenreRepository genres;

    /** Test data: unique book ID */
    private UUID bookId;

    /** Existing book used in update and delete tests */
    private Book existing;

    /** Sample genre used across tests */
    private Genre genre;

    /**
     * Initializes reusable test objects before each test run.
     * <p>
     * Creates a sample book and genre with default values.
     */
    @BeforeEach
    void setup() {
        bookId = UUID.randomUUID();

        existing = new Book();
        existing.setBookId(bookId);
        existing.setTitle("Old Title");
        existing.setIsbn("111-1111111111");
        existing.setTotalCopies(2);
        existing.setAvailableCopies(2);

        genre = new Genre();
        genre.setGenreId(UUID.randomUUID());
        genre.setName("Fiction");
    }


    // CREATE TESTS 

    /**
     * Verifies that attempting to create a book with missing title or ISBN
     * returns HTTP 400 with an appropriate error message.
     */
    @Test
    void create_missingTitleOrIsbn_returns400() throws Exception {
        String body = """
          {"title":"","isbn":""}
        """;

        mockMvc.perform(post("/admin/books")
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.status").value(400))
            .andExpect(jsonPath("$.message").value("Title and ISBN are required"));
    }

    /**
     * Verifies that creating a book with an existing ISBN
     * results in HTTP 409 Conflict and prevents saving.
     */
    @Test
    void create_isbnAlreadyExists_returns409() throws Exception {
        when(books.findByIsbn("978-0000000000")).thenReturn(Optional.of(new Book()));

        String body = """
          {"title":"New Book","isbn":"978-0000000000"}
        """;

        mockMvc.perform(post("/admin/books")
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
            .andExpect(status().isConflict())
            .andExpect(jsonPath("$.status").value(409))
            .andExpect(jsonPath("$.message").value("ISBN already exists"));

        verify(books, never()).save(any());
    }

    /**
     * Tests a successful book creation scenario:
     * <ul>
     *     <li>New authors and genre are created if not existing</li>
     *     <li>Total and available copies are equal</li>
     *     <li>All fields are properly mapped in the JSON response</li>
     * </ul>
     */
    @Test
    void create_success_createsAuthorsAndGenre_andSetsAvailableEqualsTotal() throws Exception {
        // Mock non-existing ISBN
        when(books.findByIsbn("978-1234567890")).thenReturn(Optional.empty());

        // Mock non-existing authors, simulate save behavior
        when(authors.findByNameIgnoreCase("Alice")).thenReturn(Optional.empty());
        when(authors.findByNameIgnoreCase("Bob")).thenReturn(Optional.empty());
        when(authors.save(any(Author.class))).thenAnswer(inv -> {
            Author a = inv.getArgument(0);
            if (a.getAuthorId() == null) a.setAuthorId(UUID.randomUUID());
            return a;
        });

        // Mock non-existing genre
        when(genres.findByNameIgnoreCase("Fiction")).thenReturn(Optional.empty());
        when(genres.save(any(Genre.class))).thenAnswer(inv -> {
            Genre g = inv.getArgument(0);
            if (g.getGenreId() == null) g.setGenreId(UUID.randomUUID());
            return g;
        });

        // Mock book save
        when(books.save(any(Book.class))).thenAnswer(inv -> {
            Book b = inv.getArgument(0);
            if (b.getBookId() == null) b.setBookId(UUID.randomUUID());
            return b;
        });

        String body = """
          {
            "title":"Clean Architecture",
            "isbn":"978-1234567890",
            "totalCopies": 3,
            "authors":"Alice, Bob",
            "genre":"Fiction",
            "publicationDate":"2020-05-01"
          }
        """;

        mockMvc.perform(post("/admin/books")
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.title").value("Clean Architecture"))
            .andExpect(jsonPath("$.isbn").value("978-1234567890"))
            .andExpect(jsonPath("$.totalCopies").value(3))
            .andExpect(jsonPath("$.availableCopies").value(3))
            .andExpect(jsonPath("$.authors[0].name").value("Alice"))
            .andExpect(jsonPath("$.authors[1].name").value("Bob"))
            .andExpect(jsonPath("$.genre.name").value("Fiction"))
            .andExpect(jsonPath("$.publicationDate").value("2020-05-01"));

        verify(books).save(any(Book.class));
        verify(authors, times(2)).save(any(Author.class));
        verify(genres).save(any(Genre.class));
    }

    /**
     * Verifies that when total copies are not provided,
     * both totalCopies and availableCopies default to 1.
     */
    @Test
    void create_withoutTotalCopies_defaultsTo1_andAvailableEquals1() throws Exception {
        when(books.findByIsbn("978-9999999999")).thenReturn(Optional.empty());
        when(books.save(any(Book.class))).thenAnswer(inv -> {
            Book b = inv.getArgument(0);
            if (b.getBookId() == null) b.setBookId(UUID.randomUUID());
            return b;
        });

        String body = """
          {"title":"No Total Provided","isbn":"978-9999999999"}
        """;

        mockMvc.perform(post("/admin/books")
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.title").value("No Total Provided"))
            .andExpect(jsonPath("$.totalCopies").value(1))
            .andExpect(jsonPath("$.availableCopies").value(1));
    }


    // UPDATE TESTS 

    /**
     * Verifies that updating a non-existent book returns
     * HTTP 404 Not Found with an error message.
     */
    @Test
    void update_notFound_returns404() throws Exception {
        when(books.findByIsbn("111-1111111111")).thenReturn(Optional.empty());

        mockMvc.perform(put("/admin/books/{isbn}", "111-1111111111")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"title\":\"New\"}"))
            .andExpect(status().isNotFound())
            .andExpect(jsonPath("$.status").value(404))
            .andExpect(jsonPath("$.message").value("Book not found"));
    }

    /**
     * Tests a successful update:
     * <ul>
     *     <li>Book fields are updated correctly</li>
     *     <li>Available copies remain equal to total copies</li>
     * </ul>
     */
    @Test
    void update_success_updatesFields_keepsAvailableEqualsTotal() throws Exception {
        when(books.findByIsbn("111-1111111111")).thenReturn(Optional.of(existing));
        when(genres.findByNameIgnoreCase("Fiction")).thenReturn(Optional.of(genre));
        when(books.save(any(Book.class))).thenAnswer(inv -> inv.getArgument(0));

        String body = """
          {
            "title":"Updated Title",
            "totalCopies": 7,
            "genre":"Fiction",
            "publicationDate":"2022-01-15"
          }
        """;

        mockMvc.perform(put("/admin/books/{isbn}", "111-1111111111")
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.title").value("Updated Title"))
            .andExpect(jsonPath("$.totalCopies").value(7))
            .andExpect(jsonPath("$.availableCopies").value(7))
            .andExpect(jsonPath("$.genre.name").value("Fiction"))
            .andExpect(jsonPath("$.publicationDate").value("2022-01-15"));

        verify(books).save(any(Book.class));
    }

    /**
     * Verifies that changing ISBN to a unique value succeeds
     * and updates all relevant fields.
     */
    @Test
    void update_changeIsbn_toUnique_allGood() throws Exception {
        when(books.findByIsbn("111-1111111111")).thenReturn(Optional.of(existing));
        when(books.findByIsbn("222-2222222222")).thenReturn(Optional.empty());
        when(books.save(any(Book.class))).thenAnswer(inv -> inv.getArgument(0));

        String body = """
          {"isbn":"222-2222222222","totalCopies":4}
        """;

        mockMvc.perform(put("/admin/books/{isbn}", "111-1111111111")
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.isbn").value("222-2222222222"))
            .andExpect(jsonPath("$.totalCopies").value(4))
            .andExpect(jsonPath("$.availableCopies").value(4));
    }

    /**
     * Verifies that attempting to change a book's ISBN
     * to an already existing one returns HTTP 409 Conflict.
     */
    @Test
    void update_changeIsbn_conflict_returns409_withErrorPayload() throws Exception {
        when(books.findByIsbn("111-1111111111")).thenReturn(Optional.of(existing));

        Book other = new Book();
        other.setBookId(UUID.randomUUID());
        other.setIsbn("333-3333333333");
        when(books.findByIsbn("333-3333333333")).thenReturn(Optional.of(other));

        String body = "{\"isbn\":\"333-3333333333\"}";

        mockMvc.perform(put("/admin/books/{isbn}", "111-1111111111")
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
            .andExpect(status().isConflict())
            .andExpect(jsonPath("$.status").value(409))
            .andExpect(jsonPath("$.message").value("ISBN already exists"));
    }


    //  DELETE TESTS 


    /**
     * Verifies that deleting a non-existent book returns
     * HTTP 404 Not Found with a descriptive message.
     */
    @Test
    void delete_notFound_returns404() throws Exception {
        when(books.findByIsbn("nope")).thenReturn(Optional.empty());

        mockMvc.perform(delete("/admin/books/{isbn}", "nope"))
            .andExpect(status().isNotFound())
            .andExpect(jsonPath("$.status").value(404))
            .andExpect(jsonPath("$.message").value("Book not found"));
    }

    /**
     * Tests successful book deletion:
     * <ul>
     *     <li>Removes book-author links first</li>
     *     <li>Deletes the book record</li>
     *     <li>Returns JSON with confirmation</li>
     * </ul>
     */
    @Test
    void delete_success_deletesLinksThenBook_andReturnsOk() throws Exception {
        when(books.findByIsbn("111-1111111111")).thenReturn(Optional.of(existing));

        mockMvc.perform(delete("/admin/books/{isbn}", "111-1111111111"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.deleted").value(true));

        verify(books).deleteBookAuthorLinks(existing.getBookId());
        verify(books).delete(existing);
    }
}
