package com.example.ELEC5619.service;

import jakarta.annotation.Resource;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import com.example.ELEC5619.Service.EmailService;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;

/**
 * Integration-style unit test for {@link EmailService} verifying that
 * the configured "from" address is used when sending an email.
 * <p>
 * This test uses {@link SpringJUnitConfig} to bootstrap a minimal Spring context
 * with the {@link EmailService} bean imported and a mocked {@link JavaMailSender}.
 * The "from" property is injected through {@link TestPropertySource}.
 */
@SuppressWarnings("removal")
@SpringJUnitConfig
@Import(EmailService.class)
@TestPropertySource(properties = "spring.mail.from=LibraryHub <noreply@libraryhub.test>")
class EmailServiceConfiguredTest {

    /** Mocked {@link JavaMailSender} used to verify email sending behavior. */
    @MockBean
    private JavaMailSender mailSender;

    /** Injected instance of {@link EmailService} under test. */
    @Resource
    private EmailService emailService;

    /**
     * Verifies that the {@link EmailService#send(String, String, String)} method
     * populates the outgoing {@link SimpleMailMessage} with the correct fields,
     * including the configured "from" address from application properties.
     * <p>
     * Steps verified:
     * <ul>
     *   <li>The "from" field matches the configured property value.</li>
     *   <li>The "to" recipient matches the provided argument.</li>
     *   <li>The subject and message body are set correctly.</li>
     * </ul>
     */
    @Test
    void send_usesConfiguredAddress() {
        emailService.send("user@example.com", "Subject", "Hello body");

        ArgumentCaptor<SimpleMailMessage> captor = ArgumentCaptor.forClass(SimpleMailMessage.class);
        verify(mailSender).send(captor.capture());

        SimpleMailMessage sent = captor.getValue();
        assertThat(sent.getFrom()).isEqualTo("LibraryHub <noreply@libraryhub.test>");
        assertThat(sent.getTo()).containsExactly("user@example.com");
        assertThat(sent.getSubject()).isEqualTo("Subject");
        assertThat(sent.getText()).isEqualTo("Hello body");
    }
}
