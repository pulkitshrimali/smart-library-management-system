package com.example.ELEC5619.controller;

import com.example.ELEC5619.Controller.LibraryStatsController;
import com.example.ELEC5619.Service.LibraryStatsService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(LibraryStatsController.class)
class LibraryStatsControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private LibraryStatsService statsService;

    @Test
    void getStats_Success() throws Exception {
        LibraryStatsService.LibraryStats stats = new LibraryStatsService.LibraryStats(100, 50, 25, 10);
        
        when(statsService.getStats()).thenReturn(stats);

        mockMvc.perform(get("/api/stats"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.titlesCatalogued").value(100))
                .andExpect(jsonPath("$.booksAvailable").value(50))
                .andExpect(jsonPath("$.activeReaders").value(25))
                .andExpect(jsonPath("$.totalGenres").value(10));
    }
}