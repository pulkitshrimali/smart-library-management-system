package com.example.ELEC5619.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.ArgumentMatchers.anyString;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.ELEC5619.Model.Book;
import com.example.ELEC5619.Repository.BookRepository;
import com.example.ELEC5619.Service.BookDetailsService;

@ExtendWith(MockitoExtension.class)
class BookDetailsServiceTest {

    @Mock
    private BookRepository bookRepository;

    @InjectMocks
    private BookDetailsService service;

    private Book testBook;
    private UUID testBookId;

    @BeforeEach
    void setUp() {
        // Initialise a test book object for use in all test cases
        testBookId = UUID.randomUUID();
        testBook = new Book();
        testBook.setBookId(testBookId);
        testBook.setTitle("Test Book");
        testBook.setIsbn("978-0123456789");
    }

    /**
     * Tests that getById() returns the book when it exists in the repository.
     */
    @Test
    void getById_ShouldReturnBook_WhenExists() {
        when(bookRepository.findById(testBookId)).thenReturn(Optional.of(testBook));

        Optional<Book> result = service.getById(testBookId);

        assertTrue(result.isPresent());
        assertEquals(testBook, result.get());
        verify(bookRepository).findById(testBookId);
    }

    /**
     * Tests that getById() returns an empty Optional when the book does not exist.
     */
    @Test
    void getById_ShouldReturnEmpty_WhenNotExists() {
        when(bookRepository.findById(testBookId)).thenReturn(Optional.empty());

        Optional<Book> result = service.getById(testBookId);

        assertFalse(result.isPresent());
    }

    /**
     * Tests that getByIsbn() returns the book when it exists in the repository.
     */
    @Test
    void getByIsbn_ShouldReturnBook_WhenExists() {
        String isbn = "978-0123456789";
        when(bookRepository.findByIsbn(isbn)).thenReturn(Optional.of(testBook));

        Optional<Book> result = service.getByIsbn(isbn);

        assertTrue(result.isPresent());
        assertEquals(testBook, result.get());
    }

    /**
     * Tests that getByIsbn() returns empty when the ISBN is null.
     */
    @Test
    void getByIsbn_ShouldReturnEmpty_WhenIsbnIsNull() {
        Optional<Book> result = service.getByIsbn(null);

        assertFalse(result.isPresent());
        verifyNoInteractions(bookRepository);
    }

    /**
     * Tests that getByIsbn() returns empty when the ISBN is blank.
     */
    @Test
    void getByIsbn_ShouldReturnEmpty_WhenIsbnIsBlank() {
        Optional<Book> result = service.getByIsbn("   ");

        assertFalse(result.isPresent());
        verifyNoInteractions(bookRepository);
    }

    /**
     * Tests that getByExactTitle() returns the book when it exists in the repository.
     */
    @Test
    void getByExactTitle_ShouldReturnBook_WhenExists() {
        String title = "Test Book";
        when(bookRepository.findFirstByTitleIgnoreCase(title)).thenReturn(Optional.of(testBook));

        Optional<Book> result = service.getByExactTitle(title);

        assertTrue(result.isPresent());
        assertEquals(testBook, result.get());
    }

    /**
     * Tests that getByExactTitle() returns empty when the title is null.
     */
    @Test
    void getByExactTitle_ShouldReturnEmpty_WhenTitleIsNull() {
        Optional<Book> result = service.getByExactTitle(null);

        assertFalse(result.isPresent());
        verifyNoInteractions(bookRepository);
    }

    /**
     * Tests that getByTitleContains() returns the first matching book when it exists.
     */
    @Test
    void getByTitleContains_ShouldReturnFirstMatch_WhenExists() {
        String titleLike = "Test";
        List<Book> matches = Arrays.asList(testBook);
        when(bookRepository.findByTitleContainingIgnoreCase(titleLike)).thenReturn(matches);

        Optional<Book> result = service.getByTitleContains(titleLike);

        assertTrue(result.isPresent());
        assertEquals(testBook, result.get());
    }

    /**
     * Tests that getByTitleContains() returns empty when there are no matches.
     */
    @Test
    void getByTitleContains_ShouldReturnEmpty_WhenNoMatches() {
        String titleLike = "Nonexistent";
        when(bookRepository.findByTitleContainingIgnoreCase(titleLike)).thenReturn(Arrays.asList());

        Optional<Book> result = service.getByTitleContains(titleLike);

        assertFalse(result.isPresent());
    }

    /**
     * Tests that resolveOne() returns the book by UUID when provided a valid ID.
     */
    @Test
    void resolveOne_ShouldReturnById_WhenValidUUID() {
        String id = testBookId.toString();
        when(bookRepository.findById(testBookId)).thenReturn(Optional.of(testBook));

        Optional<Book> result = service.resolveOne(id, null, null);

        assertTrue(result.isPresent());
        assertEquals(testBook, result.get());
        verify(bookRepository).findById(testBookId);
    }

    /**
     * Tests that resolveOne() falls back to ISBN if the ID is not found.
     */
    @Test
    void resolveOne_ShouldFallbackToIsbn_WhenIdNotFound() {
        String id = testBookId.toString();
        String isbn = "978-0123456789";
        when(bookRepository.findById(testBookId)).thenReturn(Optional.empty());
        when(bookRepository.findByIsbn(isbn)).thenReturn(Optional.of(testBook));

        Optional<Book> result = service.resolveOne(id, isbn, null);

        assertTrue(result.isPresent());
        assertEquals(testBook, result.get());
        verify(bookRepository).findByIsbn(isbn);
    }

    /**
     * Tests that resolveOne() falls back to exact title if ISBN is not found.
     */
    @Test
    void resolveOne_ShouldFallbackToExactTitle_WhenIsbnNotFound() {
        String title = "Test Book";
        when(bookRepository.findByIsbn(anyString())).thenReturn(Optional.empty());
        when(bookRepository.findFirstByTitleIgnoreCase(title)).thenReturn(Optional.of(testBook));

        Optional<Book> result = service.resolveOne(null, "invalid-isbn", title);

        assertTrue(result.isPresent());
        assertEquals(testBook, result.get());
    }

    /**
     * Tests that find5BySameGenre() returns a list of books related by genre.
     */
    @Test
    void find5BySameGenre_ShouldReturnBooks() {
        String isbn = "978-0123456789";
        List<Book> relatedBooks = Arrays.asList(testBook);
        when(bookRepository.findTop5BySameGenre(isbn)).thenReturn(relatedBooks);

        List<Book> result = service.find5BySameGenre(isbn);

        assertEquals(1, result.size());
        assertEquals(testBook, result.get(0));
        verify(bookRepository).findTop5BySameGenre(isbn);
    }

    /**
     * Tests that find5BySameAuthor() returns a list of books related by the same author.
     */
    @Test
    void find5BySameAuthor_ShouldReturnBooks() {
        String isbn = "978-0123456789";
        List<Book> relatedBooks = Arrays.asList(testBook);
        when(bookRepository.findTop5BySameAuthor(isbn)).thenReturn(relatedBooks);

        List<Book> result = service.find5BySameAuthor(isbn);

        assertEquals(1, result.size());
        assertEquals(testBook, result.get(0));
        verify(bookRepository).findTop5BySameAuthor(isbn);
    }

    /**
     * Tests that getReviewsForBook() returns an empty list (placeholder behaviour).
     */
    @Test
    void getReviewsForBook_ShouldReturnEmptyList() {
        List result = service.getReviewsForBook(testBookId);

        assertTrue(result.isEmpty());
    }
}