package com.example.ELEC5619.model;

import com.example.ELEC5619.Model.Genre;
import org.junit.jupiter.api.Test;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class GenreTest {

    @Test
    void testGettersAndSetters() {
        Genre genre = new Genre();
        UUID genreId = UUID.randomUUID();
        
        genre.setGenreId(genreId);
        genre.setName("Science Fiction");
        
        assertEquals(genreId, genre.getGenreId());
        assertEquals("Science Fiction", genre.getName());
    }
}