package com.example.ELEC5619.controller;

import com.example.ELEC5619.Model.Book;
import com.example.ELEC5619.Service.BookService;
import com.example.ELEC5619.Controller.BookController;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SuppressWarnings("removal")
@WebMvcTest(BookController.class)
class BookControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BookService bookService;

    private Book testBook;

    @BeforeEach
    void setUp() {
        testBook = new Book();
        testBook.setBookId(UUID.randomUUID());
        testBook.setTitle("Test Book");
        testBook.setIsbn("978-0123456789");
        testBook.setPublicationDate(LocalDate.of(2020, 1, 1));
        testBook.setTotalCopies(5);
        testBook.setAvailableCopies(3);
    }

    /**
     * Test searching books with no parameters
     * Expects all books to be returned
     */
    @Test
    void searchBooks_WithNoParameters_ShouldReturnAllBooks() throws Exception {
        List<Book> books = Arrays.asList(testBook);
        when(bookService.searchBooks(null, null, null, null, null)).thenReturn(books);

        mockMvc.perform(get("/books"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.total").value(1))
                .andExpect(jsonPath("$.items[0].title").value("Test Book"))
                .andExpect(jsonPath("$.items[0].isbn").value("978-0123456789"));

        verify(bookService).searchBooks(null, null, null, null, null);
    }

    /**
     * Test searching books with a query string
     * Expects query to be passed to service and matched books returned
     */
    @Test
    void searchBooks_WithQuery_ShouldPassQueryToService() throws Exception {
        List<Book> books = Arrays.asList(testBook);
        when(bookService.searchBooks("java", null, null, null, null)).thenReturn(books);

        mockMvc.perform(get("/books").param("q", "java"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.total").value(1))
                .andExpect(jsonPath("$.items[0].title").value("Test Book"));

        verify(bookService).searchBooks("java", null, null, null, null);
    }

    /**
     * Test searching books with availability filter
     * Expects availability filter to be applied in service
     */
    @Test
    void searchBooks_WithAvailabilityFilter_ShouldPassToService() throws Exception {
        List<Book> books = Arrays.asList(testBook);
        when(bookService.searchBooks(null, "available", null, null, null)).thenReturn(books);

        mockMvc.perform(get("/books").param("availability", "available"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.total").value(1));

        verify(bookService).searchBooks(null, "available", null, null, null);
    }

    /**
     * Test searching books with genre filter
     * Expects genre to be passed to service
     */
    @Test
    void searchBooks_WithGenreFilter_ShouldPassToService() throws Exception {
        List<Book> books = Arrays.asList(testBook);
        when(bookService.searchBooks(null, null, "Fiction", null, null)).thenReturn(books);

        mockMvc.perform(get("/books").param("genre", "Fiction"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.total").value(1));

        verify(bookService).searchBooks(null, null, "Fiction", null, null);
    }

    /**
     * Test searching books with year filter
     * Expects year filter to be applied
     */
    @Test
    void searchBooks_WithYearFilter_ShouldPassToService() throws Exception {
        List<Book> books = Arrays.asList(testBook);
        when(bookService.searchBooks(null, null, null, null, ">2000")).thenReturn(books);

        mockMvc.perform(get("/books").param("year", ">2000"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.total").value(1));

        verify(bookService).searchBooks(null, null, null, null, ">2000");
    }

    /**
     * Test searching books with all parameters applied
     * Expects all parameters to be passed to service
     */
    @Test
    void searchBooks_WithAllParameters_ShouldPassAllToService() throws Exception {
        List<Book> books = Arrays.asList(testBook);
        when(bookService.searchBooks("spring", "available", "Programming", null, "1951-2000")).thenReturn(books);

        mockMvc.perform(get("/books")
                .param("q", "spring")
                .param("availability", "available")
                .param("genre", "Programming")
                .param("year", "1951-2000"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.total").value(1))
                .andExpect(jsonPath("$.items[0].title").value("Test Book"));

        verify(bookService).searchBooks("spring", "available", "Programming", null, "1951-2000");
    }

    /**
     * Test searching books with query that returns no results
     * Expects empty list in response
     */
    @Test
    void searchBooks_WithEmptyResults_ShouldReturnEmptyList() throws Exception {
        when(bookService.searchBooks("nonexistent", null, null, null, null)).thenReturn(Arrays.asList());

        mockMvc.perform(get("/books").param("q", "nonexistent"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.total").value(0))
                .andExpect(jsonPath("$.items").isEmpty());

        verify(bookService).searchBooks("nonexistent", null, null, null, null);
    }

    /**
     * Test fetching a random book
     * Expects one book to be returned
     */
    @Test
    void getRandomBook_ShouldReturnRandomBook() throws Exception {
        when(bookService.getRandomBook()).thenReturn(java.util.Optional.of(testBook));

        mockMvc.perform(get("/books/random"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Test Book"))
                .andExpect(jsonPath("$.isbn").value("978-0123456789"));

        verify(bookService).getRandomBook();
    }

    /**
     * Test fetching a random book when no books are available
     * Expects HTTP 404 Not Found
     */
    @Test
    void getRandomBook_NoBooksAvailable_ShouldReturn404() throws Exception {
        when(bookService.getRandomBook()).thenReturn(java.util.Optional.empty());

        mockMvc.perform(get("/books/random"))
                .andExpect(status().isNotFound());

        verify(bookService).getRandomBook();
    }
}