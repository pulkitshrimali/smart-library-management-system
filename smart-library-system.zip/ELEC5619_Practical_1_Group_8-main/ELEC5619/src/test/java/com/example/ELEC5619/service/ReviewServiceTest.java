package com.example.ELEC5619.service;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.doNothing;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.ELEC5619.Model.Review;
import com.example.ELEC5619.Repository.ReviewRepository;
import com.example.ELEC5619.Service.ReviewService;

@ExtendWith(MockitoExtension.class)
class ReviewServiceTest {

    @Mock
    private ReviewRepository reviewRepository;

    @InjectMocks
    private ReviewService reviewService;

    private Review testReview;
    private UUID testBookId;
    private UUID testUserId;
    private UUID testReviewId;

    @BeforeEach
    void setUp() {
        // Initialise test data for each test case
        testBookId = UUID.randomUUID();
        testUserId = UUID.randomUUID();
        testReviewId = UUID.randomUUID();
        
        testReview = new Review();
        testReview.setReviewId(testReviewId);
        testReview.setBookId(testBookId);
        testReview.setUserId(testUserId);
        testReview.setRating(4);
        testReview.setReviewText("Great book!");
        testReview.setCreatedAt(LocalDateTime.now());
    }

    /**
     * Tests that getReviewsByBook() correctly fetches all reviews for a book
     * and populates each review with the corresponding user's name.
     */
    @Test
    void getReviewsByBook_ShouldReturnReviewsWithUserNames() {
        List<Review> mockReviews = Arrays.asList(testReview);
        when(reviewRepository.findByBookId(testBookId)).thenReturn(mockReviews);
        when(reviewRepository.findUserNameById(testUserId)).thenReturn("John Doe");

        List<Review> result = reviewService.getReviewsByBook(testBookId);

        assertEquals(1, result.size());
        assertEquals("John Doe", result.get(0).getUserName());
        verify(reviewRepository).findByBookId(testBookId);
    }

    /**
     * Tests that getReviewById() returns the correct review
     * with the user's name correctly set.
     */
    @Test
    void getReviewById_ShouldReturnReviewWithUserName() {
        when(reviewRepository.findById(testReviewId)).thenReturn(Optional.of(testReview));
        when(reviewRepository.findUserNameById(testUserId)).thenReturn("Jane Smith");

        Review result = reviewService.getReviewById(testReviewId);

        assertEquals(testReviewId, result.getReviewId());
        assertEquals("Jane Smith", result.getUserName());
    }

    /**
     * Tests that getReviewById() throws a RuntimeException
     * when the review does not exist in the repository.
     */
    @Test
    void getReviewById_ShouldThrowException_WhenReviewNotFound() {
        when(reviewRepository.findById(testReviewId)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> reviewService.getReviewById(testReviewId));
    }

    /**
     * Tests that addReview() saves a new review to the repository
     * and returns the saved review object.
     */
    @Test
    void addReview_ShouldSaveAndReturnReview() {
        when(reviewRepository.save(any(Review.class))).thenReturn(testReview);

        Review result = reviewService.addReview(testReview);

        assertEquals(testReview, result);
        verify(reviewRepository).save(testReview);
    }

    /**
     * Tests that updateReview() correctly updates the fields of an existing review
     * and persists the changes via the repository.
     */
    @Test
    void updateReview_ShouldUpdateAndReturnReview() {
        Review updatedReview = new Review();
        updatedReview.setRating(5);
        updatedReview.setReviewText("Amazing book!");
        
        when(reviewRepository.findById(testReviewId)).thenReturn(Optional.of(testReview));
        when(reviewRepository.save(any(Review.class))).thenReturn(testReview);

        Review result = reviewService.updateReview(testReviewId, updatedReview, testUserId);

        assertEquals(5, result.getRating());
        assertEquals("Amazing book!", result.getReviewText());
        verify(reviewRepository).save(testReview);
    }

    /**
     * Tests that updateReview() throws a RuntimeException
     * when attempting to update a non-existent review.
     */
    @Test
    void updateReview_ShouldThrowException_WhenReviewNotFound() {
        when(reviewRepository.findById(testReviewId)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> 
            reviewService.updateReview(testReviewId, new Review(), testUserId));
    }

    /**
     * Tests that deleteReviewAsAdmin() calls the repository's deleteById() method
     * to remove a review by its ID.
     */
    @Test
    void deleteReviewAsAdmin_ShouldCallRepositoryDelete() {
        when(reviewRepository.existsById(testReviewId)).thenReturn(true);
        
        reviewService.deleteReviewAsAdmin(testReviewId);

        verify(reviewRepository).deleteById(testReviewId);
    }

    /**
     * Tests that deleteReview() throws exception for regular users
     */
    @Test
    void deleteReview_ShouldThrowException_ForRegularUsers() {
        assertThrows(RuntimeException.class, () -> 
            reviewService.deleteReview(testReviewId, testUserId));
    }
}