package com.example.ELEC5619.controller;

import com.example.ELEC5619.Controller.LibraryController;
import com.example.ELEC5619.Model.Library;
import com.example.ELEC5619.Repository.LibraryRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.UUID;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(LibraryController.class)
class LibraryControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private LibraryRepository libraryRepository;

    @Test
    void getAllLibraries_Success() throws Exception {
        Library library = new Library();
        library.setLibraryId(UUID.randomUUID());
        library.setName("Central Library");
        
        when(libraryRepository.findAll()).thenReturn(Arrays.asList(library));

        mockMvc.perform(get("/api/libraries"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$[0].name").value("Central Library"));
    }
}