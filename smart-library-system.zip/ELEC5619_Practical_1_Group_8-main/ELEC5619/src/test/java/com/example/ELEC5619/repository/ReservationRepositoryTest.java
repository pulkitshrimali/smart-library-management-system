package com.example.ELEC5619.repository;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.ELEC5619.Model.Reservation;
import com.example.ELEC5619.Repository.ReservationRepository;

@ExtendWith(MockitoExtension.class)
class ReservationRepositoryTest {

    @Mock
    private ReservationRepository reservationRepository;

    /**
     * Tests that findByUserId() returns a list of reservations for the given user
     */
    @Test
    void findByUserId_ReturnsUserReservations() {
        UUID userId = UUID.randomUUID();
        Reservation reservation = new Reservation();
        reservation.setUserId(userId);

        when(reservationRepository.findByUserId(userId)).thenReturn(Arrays.asList(reservation));

        List<Reservation> result = reservationRepository.findByUserId(userId);

        assertEquals(1, result.size());
        assertEquals(userId, result.get(0).getUserId());
    }

    /**
     * Tests that hasActiveReservationForBook() returns true when the user has an active reservation for the book
     */
    @Test
    void hasActiveReservationForBook_ReturnsTrue() {
        UUID userId = UUID.randomUUID();
        UUID bookId = UUID.randomUUID();

        when(reservationRepository.hasActiveReservationForBook(userId, bookId)).thenReturn(true);

        boolean result = reservationRepository.hasActiveReservationForBook(userId, bookId);

        assertTrue(result);
    }

    /**
     * Tests that hasActiveReservationForBook() returns false when the user does not have an active reservation for the book
     */
    @Test
    void hasActiveReservationForBook_ReturnsFalse() {
        UUID userId = UUID.randomUUID();
        UUID bookId = UUID.randomUUID();

        when(reservationRepository.hasActiveReservationForBook(userId, bookId)).thenReturn(false);

        boolean result = reservationRepository.hasActiveReservationForBook(userId, bookId);

        assertFalse(result);
    }

    /**
     * Tests that findReservationsWithBooksByUserId() returns reservation data including book details
     */
    @Test
    void findReservationsWithBooksByUserId_ReturnsData() {
        UUID userId = UUID.randomUUID();
        Object[] mockRow = {UUID.randomUUID(), userId, UUID.randomUUID(), null, null, "PENDING",
                "Test Book", "123", "cover.jpg", 2023, "Author", null, null};

        when(reservationRepository.findReservationsWithBooksByUserId(userId))
                .thenReturn(Arrays.asList(new Object[][]{mockRow}));

        List<Object[]> result = reservationRepository.findReservationsWithBooksByUserId(userId);

        assertEquals(1, result.size());
        assertEquals("Test Book", result.get(0)[6]);
    }
}