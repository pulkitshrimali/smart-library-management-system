package com.example.ELEC5619.model;

import com.example.ELEC5619.Model.Waitlist;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class WaitlistTest {

    /**
     * Tests that a Waitlist object can be created and all properties can be set and retrieved correctly.
     */
    @Test
    void testWaitlistCreation() {
        Waitlist waitlist = new Waitlist();
        UUID waitlistId = UUID.randomUUID();
        UUID userId = UUID.randomUUID();
        UUID bookId = UUID.randomUUID();
        UUID libraryId = UUID.randomUUID();
        Integer position = 1;
        LocalDateTime createdAt = LocalDateTime.now();

        waitlist.setWaitlistId(waitlistId);
        waitlist.setUserId(userId);
        waitlist.setBookId(bookId);
        waitlist.setLibraryId(libraryId);
        waitlist.setPosition(position);
        waitlist.setCreatedAt(createdAt);

        assertEquals(waitlistId, waitlist.getWaitlistId());
        assertEquals(userId, waitlist.getUserId());
        assertEquals(bookId, waitlist.getBookId());
        assertEquals(libraryId, waitlist.getLibraryId());
        assertEquals(position, waitlist.getPosition());
        assertEquals(createdAt, waitlist.getCreatedAt());
    }

    /**
     * Tests that a newly created Waitlist has the expected default values.
     */
    @Test
    void testWaitlistDefaultValues() {
        Waitlist waitlist = new Waitlist();
        assertNull(waitlist.getWaitlistId());
        assertNull(waitlist.getUserId());
        assertNull(waitlist.getBookId());
        assertNull(waitlist.getLibraryId());
        assertEquals(Integer.valueOf(0), waitlist.getPosition());
        assertNotNull(waitlist.getCreatedAt()); // Constructor sets this
    }

    /**
     * Tests that the waitlist position can be updated and retrieved correctly.
     */
    @Test
    void testWaitlistPositionUpdate() {
        Waitlist waitlist = new Waitlist();
        waitlist.setPosition(5);
        assertEquals(5, waitlist.getPosition());
        
        waitlist.setPosition(1);
        assertEquals(1, waitlist.getPosition());
    }

    /**
     * Tests that a User object can be set and retrieved from the Waitlist.
     */
    @Test
    void testSetUser() {
        Waitlist waitlist = new Waitlist();
        com.example.ELEC5619.Model.User user = new com.example.ELEC5619.Model.User();
        waitlist.setUser(user);
        assertEquals(user, waitlist.getUser());
    }

    /**
     * Tests that a Book object can be set and retrieved from the Waitlist.
     */
    @Test
    void testSetBook() {
        Waitlist waitlist = new Waitlist();
        com.example.ELEC5619.Model.Book book = new com.example.ELEC5619.Model.Book();
        waitlist.setBook(book);
        assertEquals(book, waitlist.getBook());
    }
}